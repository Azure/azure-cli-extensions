"""This module provides client factories for device operations."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------
from pathlib import Path
from typing import Optional

from azext_azure_sphere.helpers._gatewayd_version_checker import warn_if_deprecated_os
from azext_azure_sphere.helpers.capability_session import CAPABILITY_SESSION
from azext_azure_sphere.sdk.azure_sphere_gatewayd.azure.sphere.gatewayd._gateway_d_client import (
    GatewayDClient,
)
from azure.cli.core import AzCli
from requests import Session
from requests_toolbelt.adapters import host_header_ssl

CURRENT_DIR = Path(__file__).parent
_CERT_PATH = (CURRENT_DIR / "helpers/certs/gatewayd.pem").absolute()
DEFAULT_DEVICE_CONNECT_TIMEOUT = 30  # seconds
DEFAULT_DEVICE_READ_TIMEOUT = 30  # seconds


def should_use_capability_session(capability_session_warning: bool) -> bool:
    """Return True if gatewayd should use a capability session and False otherwise.

    If a capability session is started and is valid, the user is informed that a capability session
    is active. If the capability file is invalid (the capability file was erased before the call to
    this function), the capability session is stopped, cleared, and the user is informed that the
    session is no longer valid.
    """
    # if the capability session doesn't exist or isn't started
    if not CAPABILITY_SESSION or not CAPABILITY_SESSION.get_capability_session_started_status():
        return False

    if not CAPABILITY_SESSION.is_session_valid():
        CAPABILITY_SESSION.invalidate_session()
        return False

    if capability_session_warning:
        CAPABILITY_SESSION.print_active_capability_session_warning()

    return True


def cf_azure_sphere_gatewayd(
    _: AzCli, namespace: Optional[dict] = None, device_ip: Optional[str] = None, **kwargs
):
    """Return an GatewayDClient."""
    device_ip_address = (
        device_ip if device_ip else (namespace.pop("device_ip", None) if namespace else None)
    )

    # Raise an exception if no device_ip parameter has been provided.
    # This is likely cause by a developer mistake.
    if not device_ip_address:
        raise ValueError("The device_ip parameter must be provided")

    session = Session()
    session.mount("https://", host_header_ssl.HostHeaderSSLAdapter())
    gatewayd_headers = {"Host": "*.devices.sphere.azure.local"}

    # set the capability_session_warning to false; if a command uses multiple device clients
    # this avoids printing multiple times the warning message that the command is executed in a
    # capability session
    capability_session_warning = kwargs.pop("capability_session_warning", True)

    # if a capability session is active, each subsequent command should append the capability
    # content to the gatewayd request
    if should_use_capability_session(capability_session_warning):
        gatewayd_headers.update(
            {
                "AZSPHERE-CAPABILITIES": CAPABILITY_SESSION.get_selected_capability_file_base64encoded_str()
            }
        )

    # capability session for enable development mode
    if "enable_development_cap" in kwargs:
        gatewayd_headers.update({"AZSPHERE-CAPABILITIES": kwargs.get("enable_development_cap")})

    # Timeouts. Refer https://docs.python-requests.org/master/user/advanced/#timeouts for more info.
    connect_timeout_key = "connection_timeout"
    read_timeout_key = "read_timeout"

    # Set the connect timeout to the default device timeout.
    if connect_timeout_key not in kwargs:
        kwargs[connect_timeout_key] = DEFAULT_DEVICE_CONNECT_TIMEOUT
    else:
        if not isinstance(kwargs[connect_timeout_key], int):
            raise ValueError("The connect timeout value must be an integer.")

    # If not set in kwargs, set the read timeout to the default read timeout.
    if read_timeout_key not in kwargs:
        kwargs[read_timeout_key] = DEFAULT_DEVICE_READ_TIMEOUT
    else:
        if not isinstance(kwargs[read_timeout_key], int):
            raise ValueError("The read timeout value must be an integer.")

    return GatewayDClient(
        base_url="https://" + device_ip_address,
        connection_verify=_CERT_PATH,
        session=session,
        headers=gatewayd_headers,
        raw_response_hook=warn_if_deprecated_os,
        retry_status=0,
        **kwargs
    )


def cf_wifi_gatewayd(*args, **kwargs):
    """Return the wifi operation group (Device)."""
    return cf_azure_sphere_gatewayd(*args, **kwargs).wifi


def cf_network_gatewayd(*args, **kwargs):
    """Return the network operation group (Device)."""
    return cf_azure_sphere_gatewayd(*args, **kwargs).net


def cf_certificate_gatewayd(*args, **kwargs):
    """Return the certificate operation group (Device)."""
    return cf_azure_sphere_gatewayd(*args, **kwargs).cert


def cf_device_gatewayd(*args, **kwargs):
    """Return the device operation group (Device)."""
    return cf_azure_sphere_gatewayd(*args, **kwargs).device


def cf_diag_gatewayd(*args, **kwargs):
    """Return the diag operation group (Device)."""
    return cf_azure_sphere_gatewayd(*args, **kwargs).diag


def cf_application_gatewayd(*args, **kwargs):
    """Return the application operation group (Device)."""
    return cf_azure_sphere_gatewayd(*args, **kwargs).app


def cf_image_gatewayd(*args, **kwargs):
    """Return the image operation group (Device)."""
    return cf_azure_sphere_gatewayd(*args, **kwargs).images
