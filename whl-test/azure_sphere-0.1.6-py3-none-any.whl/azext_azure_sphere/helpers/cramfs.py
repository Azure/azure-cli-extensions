# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

# cramfs spec https://www.kernel.org/doc/readme/fs-cramfs-README

import os
import struct
from enum import Enum


class FileMode(Enum):
    # <summary>
    # regular file
    # </summary>
    S_ISREG = (0x8000,)

    # <summary>
    # directory
    # </summary>
    S_ISDIR = (0x4000,)


class ImagePackageReader:
    def GetAppManifestFromImagePackage(self, imagepackage):
        with open(imagepackage, "rb") as f:
            try:
                (
                    magic,
                    size,
                    flags,
                    future,
                    signature,
                    crc,
                    edition,
                    blocks,
                    files,
                    name,
                ) = self.read_cramfs_header(f)
            except:
                return None

            # validate magic number
            if magic != 0x28CD3D45:
                return None

            # make sure the imagepackage has files
            if files == 0:
                return None

            # validate signature
            if signature.decode() != "Compressed ROMFS":
                return None

            # validate name
            name_null_offset = name.find(b"\x00")
            name = name[0:name_null_offset]
            if name.decode() != "Compressed":
                return None

            # read root inode.
            inode = self.read_inode(f)

            # check we have a directory.
            if inode["mode"] & FileMode.S_ISDIR.value[0] == False:
                return None

            # root directory name should be empty
            if inode["namelen"] != 0:
                return None

            # Now read the files
            file_list = []

            for i in range(files):
                inode = self.read_inode(f)
                if inode["mode"] & FileMode.S_ISREG.value[0]:
                    if inode["namelen"] > 0:
                        name_len = inode["namelen"] * 4
                        if name_len % 4 != 0:
                            remain = 4 - (name_len % 4)

                        filename = self.read_string(f, name_len)
                        file_info = {}
                        file_info["name"] = filename
                        file_info["offset"] = inode["offset"] * 4
                        file_info["size"] = inode["size"] * 4
                        file_list.append(file_info)

            # look for app_manifest.json
            for file_info in file_list:
                if file_info["name"] == "app_manifest.json":
                    f.seek(file_info["offset"])
                    data = f.read(file_info["size"])
                    null_offset = data.find(b"\0")
                    data = data[0:null_offset]
                    return data.decode()

            return None

    # Helper functions

    def read_uint32(self, f):
        return struct.unpack("<I", f.read(4))[0]

    def read_uint16(self, f):
        return struct.unpack("<H", f.read(2))[0]

    def read_uint8(self, f):
        return struct.unpack("<B", f.read(1))[0]

    def read_uint24(self, f):
        return struct.unpack("<HB", f.read(3))[0]

    def read_string(self, f, size):
        return f.read(size).decode("utf-8").strip("\0")

    def read_namelen_and_offset(self, f):
        data = self.read_uint32(f)
        namelen = data & 0x3F
        offset = data >> 6
        return (namelen, offset)

    def read_inode(self, f):
        inode = {}
        inode["mode"] = self.read_uint16(f)
        inode["uid"] = self.read_uint16(f)
        inode["size"] = self.read_uint24(f)
        inode["gid"] = self.read_uint8(f)
        inode["namelen"], inode["offset"] = self.read_namelen_and_offset(f)
        return inode

    def read_cramfs_header(self, f):
        header = f.read(64)
        if len(header) != 64:
            return None

        magic, size, flags, future, signature, crc, edition, blocks, files, name = struct.unpack(
            "<IIII16sIIII16s", header
        )
        if magic != 0x28CD3D45:
            return None
        return (magic, size, flags, future, signature, crc, edition, blocks, files, name)
