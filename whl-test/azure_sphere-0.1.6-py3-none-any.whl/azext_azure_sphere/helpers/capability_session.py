# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

"""

This file implements the device capability session logic. It creates the necessary classes to
deal with the capability type. It creates the CAPABILITY_SESSION variable which is used by both
gatewayd and mammoth. We decided not to use this design to make it easier for both mammoth and
gatewayd (device commands) to reason about an active capability session.

"""

import base64
from pathlib import Path, os

import azure.cli.core._session as azure_core_session
from azure.cli.core._environment import get_config_dir
from knack.log import get_logger
from knack.util import CLIError

logger = get_logger(__name__)


class CapabilityFile:
    """Initialize a capability file."""

    def __init__(self, filepath: Path):
        """Initialize a capability file."""
        self.filepath = filepath

    def is_capability_path_valid(self):
        """Check if the capability path is still valid: if the capability wasn't erased/moved.

        :return: True if the path is still valid, false otherwise
        :rtype: bool
        """
        if not self.filepath or not self.filepath.is_file():
            logger.debug(f"Couldn't find a capability file at: {str(self.filepath)}.")
            return False
        return True

    def get_base64_encoded_str_capability_file_content(self):
        """Retrieve the encoded base64 capability content as a string.

        Returns an empty string if the path is invalid.

        :return: A base64 string representing the content of the capability file or an empty string
        :rtype: base64_encoded string
        """
        if not self.is_capability_path_valid():
            return ""

        bytes_base64 = self.filepath.read_bytes()
        bytes_base64_encoded = base64.standard_b64encode(bytes_base64)

        # convert to string
        return bytes_base64_encoded.decode()


class CapabilitySession:
    """Create a capability session."""

    def __init__(self):
        """Initialize a CapabilitySession."""
        self._session = azure_core_session.Session()
        self._selected_capability_file = None
        self._is_started = False
        self._refresh_capability_session()

    def get_capability_session_started_status(self):
        """Return True if the capability session has started and False otherwise."""
        return self._is_started

    def _refresh_capability_session(self):
        """Reload the selected capability information.

        The selected capability information is maintained in the capability_session.json file.
        This ensures that when the CLI is restarted, it starts in the same capability session as
        before.
        """
        capability_session_path = os.path.join(get_config_dir(), "capability_session.json")
        self._session.load(capability_session_path)

        capability_session = self._session.get("capability_path")

        if capability_session:
            self.start_capability_session(CapabilityFile(Path(capability_session)))

    def _persist_session_data(self, new_capability_file: CapabilityFile = None):
        """Set the selected capability to the new capability file or to none by default."""
        if not new_capability_file:
            self._session.data = {}
        else:
            self._session.data = {"capability_path": str(new_capability_file.filepath)}

        self._session.save_with_retry()
        self._selected_capability_file = new_capability_file

    def start_capability_session(self, capability_file: CapabilityFile):
        """Start a capability session."""
        self._persist_session_data(capability_file)
        self._is_started = True
        logger.debug(
            f"Capability session started using capability file: {str(capability_file.filepath)}"
        )

    def end_capability_session(self):
        """End a capability session."""
        self._persist_session_data()
        self._is_started = False
        logger.debug("Capability configuration has been successfully ended.")

    def get_selected_capability_file_base64encoded_str(self) -> str:
        """Return the base64 encoded capability file content as a string if the current session is valid."""
        if self.is_session_valid():
            return self._selected_capability_file.get_base64_encoded_str_capability_file_content()

        return ""

    def invalidate_session(self):
        """Output an warning message and clears the capability session. This method should be used only if there is a reason to invalidate the capability session. Otherwise, use end_capability_session()."""
        logger.warning(
            "The selected device capability configuration file "
            f"{self._selected_capability_file.filepath} is not valid or not found and that is why "
            "the selection will be cleared. Please try setting up your selected capability "
            "configuration again; if the issue persists, please refer to "
            "https://aka.ms/AzureSphereSDKHelp/Device for troubleshooting suggestions and support."
        )
        self._persist_session_data()
        self._is_started = False

    def is_session_valid(self) -> bool:
        """Check if the current capability session is still valid."""
        if (
            self._selected_capability_file
            and not self._selected_capability_file.is_capability_path_valid()
        ):
            return False

        return True

    def get_selected_capability_file_path(self):
        """Return the path used for the selected capability file if the session is valid."""
        if self.is_session_valid():
            return self._selected_capability_file.filepath

        return None

    def get_forbidden_access_message(self) -> str:
        """Return a specific error message based on the capability session status."""
        error_msg = (
            "Run 'az sphere device enable-development' or use 'az sphere device capability' to "
            "download and select a capability file for this device."
        )

        if self._is_started:
            error_msg = (
                "Your selected capability file does not enable this action. "
                "Please download and select a suitable capability file."
            )

        message = (
            f"Device access is forbidden. {error_msg} For further information, please refer to "
            "https://aka.ms/AzureSphereSDKHelp/Device."
        )

        return message

    def print_active_capability_session_warning(self):
        """Print a warning message to inform the user that they are in a capability session. Before calling this method, check that the session is still valid by calling the is_session_valid() method and by checking that get_capability_session_started_status() is True."""
        if not self.get_capability_session_started_status():
            raise CLIError("Capability session should be started before using this function")
        logger.warning(
            f"The current capability session uses capability file {str(self._selected_capability_file.filepath)}. "
            "To end the capability session, run 'az sphere "
            "device capability select --none' command."
        )


CAPABILITY_SESSION = CapabilitySession()
