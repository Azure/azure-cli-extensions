"""Provides helper functions for hardware definition commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

import io
import json
import os
from pathlib import Path, PureWindowsPath

from knack.log import get_logger
from knack.util import CLIError

logger = get_logger(__name__)


METADATAFIELD_TYPE_SUPPORTED = "Azure Sphere Hardware Definition"
METADATAFIELD_VERSION_SUPPORTED = 1


def count_peripheral(key, value, my_dictlist):
    """Count peripheral number."""
    count = 0
    for entry in my_dictlist:
        if entry[key] == value:
            count = count + 1
    return count


def import_and_generate_header(hardware_definition_file):
    """Import the hardware definition file and generates a header file."""
    definition = import_file(hardware_definition_file)
    header = generate_header(definition)

    # Create output directory
    output_file_directory = PureWindowsPath(
        os.path.join(Path(hardware_definition_file).parent, "inc", "hw")
    ).as_posix()
    if not os.path.exists(output_file_directory):
        os.makedirs(output_file_directory)

    # Write output header file
    output_header_file_path = PureWindowsPath(
        os.path.join(Path(output_file_directory, Path(hardware_definition_file).stem + ".h"))
    ).as_posix()
    with open(output_header_file_path, "w", encoding="UTF8") as file:
        file.write(header.getvalue())

    return output_header_file_path


def import_and_test_header(hardware_definition_file):
    """Import the hardware definition file and validates it against a header file."""
    definition = import_file(hardware_definition_file)
    header = generate_header(definition)

    output_file_directory = PureWindowsPath(
        os.path.join(Path(hardware_definition_file).parent, "inc", "hw")
    ).as_posix()
    output_header_file_path = PureWindowsPath(
        os.path.join(Path(output_file_directory, Path(hardware_definition_file).stem + ".h"))
    ).as_posix()
    if not os.path.exists(output_header_file_path):
        raise CLIError(f"No existing header found at {output_header_file_path}")

    with open(output_header_file_path, "r", encoding="UTF8") as file:
        existing_header = file.read()

        if existing_header != header.getvalue():
            raise CLIError(
                f"Existing header at {output_header_file_path} does not match header generated from json {hardware_definition_file}"
            )
    return output_header_file_path


def import_file(hardware_definition_file):
    """Import the hardware definition file."""
    with open(hardware_definition_file, "r", encoding="UTF8") as file:
        definition = json.load(file)
        definition["file_path"] = hardware_definition_file

        validate_json_definition(definition)
        return definition


def validate_json_definition(definition):
    """Validate the hardware definition."""
    if definition["Metadata"]["Type"] != METADATAFIELD_TYPE_SUPPORTED:
        raise CLIError(
            f"Error parsing hardware definition file '{definition['file_path']}': Metadata specifies"
            f"Type '{definition['Metadata']['Type']}' instead of mandatory Type"
            f"'{METADATAFIELD_TYPE_SUPPORTED}'"
        )

    if definition["Metadata"]["Version"] != METADATAFIELD_VERSION_SUPPORTED:
        raise CLIError(
            f"Error parsing hardware definition file '{definition['file_path']}': Metadata specifies Version {definition['Metadata']['Version']} but only version {METADATAFIELD_VERSION_SUPPORTED} is supported"
        )

    if "Imports" in definition:
        for import_def in definition["Imports"]:
            if os.path.isabs(import_def["Path"]):
                raise CLIError(
                    f"Error parsing hardware definition file '{definition['file_path']}': import '{import_def['Path']}' must be specified using a relative path, not an absolute path"
                )

    for peripheral in definition["Peripherals"]:
        if "MainCoreHeaderValue" not in peripheral and "AppManifestValue" in peripheral:
            raise CLIError(
                f"Error parsing hardware definition file '{definition['file_path']}': peripheral '{peripheral['Name']}' must not define 'AppManifestValue' without also defining 'MainCoreHeaderValue'"
            )

        if (
            "AppManifestValue" in peripheral
            and not isinstance(peripheral["AppManifestValue"], int)
            and not isinstance(peripheral["AppManifestValue"], str)
        ):
            raise CLIError(
                f"Error parsing hardware definition file '{definition['file_path']}': peripheral '{peripheral['Name']}' ManifestValue must be a string or an integer"
            )

        if "Mapping" in peripheral and "MainCoreHeaderValue" in peripheral:
            raise CLIError(
                f"Error parsing hardware definition file '{definition['file_path']}': peripheral '{peripheral['Name']}' must either include a Mapping or include a HeaderValue and ManifestValue but not both"
            )

        if "Mapping" not in peripheral and "Override" in peripheral:
            raise CLIError(
                f"Error parsing hardware definition file '{definition['file_path']}': peripheral '{peripheral['Name']}' cannot have the Override boolean set but not provide an underlying Mapping"
            )

        count = count_peripheral("Name", peripheral["Name"], definition["Peripherals"])
        if count > 1:
            raise CLIError(
                f"Error parsing hardware definition file '{definition['file_path']}': peripheral '{peripheral['Name']}' type '{peripheral['Type']}' is present more than once"
            )


def generate_header(definition) -> io.StringIO:
    """Generate the header based on input definition."""
    header = io.StringIO()

    for desc_line in definition["Description"]["MainCoreHeaderFileTopContent"]:
        header.write(desc_line)
        header.write("\n")

    header.write("\n")

    file_name = Path(definition["file_path"]).name
    # Join path and change slashes to unix
    relative_json_location = PureWindowsPath(os.path.join("..", "..", file_name)).as_posix()
    header.write(
        f"// This file is autogenerated from {relative_json_location}.  Do not edit it directly."
        + "\n\n"
    )

    header.write("#pragma once\n")

    # Write Imports
    if "Imports" in definition:
        for import_item in definition["Imports"]:
            import_header_path = import_item["Path"]

            # Deal with files in the same directory
            if not import_header_path.startswith("./") and not os.path.dirname(
                Path(import_header_path)
            ):
                import_header_path = PureWindowsPath(
                    os.path.join(Path(import_header_path).stem + ".h")
                ).as_posix()
            # Deal with parent/neighbour
            elif (
                ".." in import_header_path
                and not import_header_path.startswith(".././")
                and not import_header_path.startswith("./")
            ):
                import_header_path = PureWindowsPath(
                    os.path.join(
                        "..",
                        "..",
                        Path(import_header_path).parent,
                        "inc",
                        "hw",
                        Path(import_header_path).stem + ".h",
                    )
                ).as_posix()
            elif import_header_path.startswith("./"):
                import_header_path = os.path.join(
                    "..",
                    Path(import_header_path).parent,
                    "inc",
                    "hw",
                    Path(import_header_path).stem + ".h",
                ).replace("\\", "/")

            header.write(f'#include "{import_header_path}"')
            header.write("\n")
        header.write("\n")

    # Write Peripherals
    for peripheral in definition["Peripherals"]:
        if "Override" in peripheral:
            header.write(f"#undef {peripheral['Name']}" + "\n")

        if peripheral["Comment"]:
            header.write("// " + peripheral["Comment"] + "\n")

        if "MainCoreHeaderValue" in peripheral:
            header.write(f"#define {peripheral['Name']} {peripheral['MainCoreHeaderValue']}" + "\n")
        else:
            header.write(f"#define {peripheral['Name']} {peripheral['Mapping']}" + "\n")
        header.write("\n")
    return header
