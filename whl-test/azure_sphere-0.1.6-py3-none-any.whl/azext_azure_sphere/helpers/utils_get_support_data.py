"""Provides helper functions for get-support-data command."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------
import glob
import os
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from io import StringIO
from pathlib import Path

import psutil
from azext_azure_sphere._client_factory import cf_catalog, cf_device_group
from azext_azure_sphere._client_factory_device import (
    cf_device_gatewayd,
    cf_diag_gatewayd,
    cf_image_gatewayd,
    cf_network_gatewayd,
    cf_wifi_gatewayd,
)
from azext_azure_sphere.device.custom import DEFAULT_VALUE, show_deployment_status_device
from azext_azure_sphere.helpers.capability_types import get_support_data_capability_type_name
from azext_azure_sphere.helpers.utils import (
    get_config_value,
    get_sdk_version,
    get_value_from_arm_id,
)
from azext_azure_sphere.helpers.utils_images import get_image_type_name
from azure.cli.core._environment import get_config_dir
from azure.cli.core.commands import AzCliCommand
from azure.core.exceptions import ServiceRequestError
from knack.log import get_logger
from knack.util import CLIError

logger = get_logger(__name__)

AZURE_CLI_LOGS_FILE_NAME = "ActivityLogs_AzureCLI.txt"


def gather_catalogs_available(cmd: AzCliCommand, resource_group_name: str, cloud_content: StringIO):
    """Get catalogs available."""
    try:
        catalog_client = cf_catalog(cmd.cli_ctx)
        catalog_list = catalog_client.list_by_resource_group(
            resource_group_name=resource_group_name
        )

        is_empty = True
        for i, catalog in enumerate(catalog_list):
            cloud_content.write(f"\n -> {catalog.name}")
            is_empty = False
        if is_empty:
            cloud_content.write("\n -> ** NONE FOUND **")
    except Exception as ex:
        error_message = "Could not get available catalogs"
        logger.error(f"{error_message}: {ex}")
        cloud_content.write(f"\n -> {error_message}: {ex}")


def gather_device_configuration(
    cmd: AzCliCommand,
    resource_group_name: str,
    catalog_name: str,
    device_id: str,
    cloud_content: StringIO,
):
    """Get device configuration."""

    try:
        # get device details (product and device group)
        filter_condition = f"name eq '{device_id}'"
        catalog_client = cf_catalog(cmd.cli_ctx)
        response_device_details = catalog_client.list_devices(
            resource_group_name, catalog_name, filter=filter_condition
        )
        device_details = list(response_device_details)
        if len(device_details) == 1:
            device_product_name = get_value_from_arm_id(device_details[0].id, "products")
            device_device_group_name = get_value_from_arm_id(device_details[0].id, "deviceGroups")
            device_chip_sku = device_details[0].chip_sku
        else:
            raise Exception("No devices found.")

        cloud_content.write(f"\n -> Device ID: '{device_id}'")
        cloud_content.write(f"\n -> Device ChipSKU: {device_chip_sku}")
        cloud_content.write("\n -> Device Group: ")

        if device_device_group_name and device_device_group_name != DEFAULT_VALUE:
            try:
                device_group_details = get_device_group_details(
                    cmd,
                    resource_group_name,
                    catalog_name,
                    device_product_name,
                    device_device_group_name,
                )
                cloud_content.write(
                    f"\n'{device_group_details.name}' - Update policy: '{device_group_details.update_policy}'"
                )
            except Exception as ex:
                error_message = "Could not retrieve device group details"
                logger.error(f"{error_message}: {ex}")
                cloud_content.write(f"\n -> {error_message}: {ex}")
        else:
            cloud_content.write("\n** NOT DEFINED **")
    except Exception as ex:
        error_message = "Could not get device configuration"
        logger.error(f"{error_message}: {ex}")
        cloud_content.write(f"\n -> {error_message}: {ex}")


def get_device_group_details(
    cmd, resource_group_name, catalog_name, product_name, device_group_name
):
    """Getting device group details."""
    device_group_client = cf_device_group(cmd.cli_ctx)
    device_group_details = device_group_client.get(
        resource_group_name=resource_group_name,
        catalog_name=catalog_name,
        product_name=product_name,
        device_group_name=device_group_name,
    )

    return device_group_details


def gather_ota_status(
    cmd: AzCliCommand,
    resource_group_name: str,
    catalog_name: str,
    device_ip: str,
    cloud_content: StringIO,
):
    """Getting device configuration status."""
    try:
        response = show_deployment_status_device(
            cmd=cmd,
            resource_group_name=resource_group_name,
            catalog_name=catalog_name,
            device_ip=device_ip,
        )
        cloud_content.write("\n -> Device OS version(s): ")
        cloud_content.write(f"\n {response['deviceOsVersion']}")
        cloud_content.write("\n -> OTA update OS version: ")
        cloud_content.write(f"\n {response['targetedOsVersion']}")
    except Exception as ex:
        error_message = "Could not get device configuration status"
        logger.error(f"{error_message}: {ex}")
        cloud_content.write(f"\n -> {error_message}: {ex}")


def write_log_file(packaging_folder_name, device_connection_path, cloud_content):
    """Write log file in expected packaging folder."""
    try:
        filename = f"AzureSphere_SecurityService_{device_connection_path}.log"
        filepath = os.path.join(packaging_folder_name, filename)
        with open(filepath, "w") as cloud_file_log:
            cloud_file_log.write(cloud_content.getvalue())
    except Exception as ex:
        logger.error(f"Could not write the log file: {filename}. {ex}")


def create_zip_archive_file(output_file, packaging_folder_name):
    """Create zip archive file with logs file from temporary folder."""
    try:
        output_file_no_extension = os.path.splitext(output_file)[0]
        shutil.make_archive(output_file_no_extension, "zip", packaging_folder_name)
        logger.warning(f"Created the support log archive at '{output_file}'.")
    except Exception as ex:
        raise CLIError(f"Could not create the archive file: {ex}.")


def remove_temporary_folder(packaging_folder_name):
    """Remove temporary folder."""
    try:
        if os.path.exists(packaging_folder_name):
            shutil.rmtree(packaging_folder_name)
            logger.debug(f"Removed previous packaging folder: '{packaging_folder_name}'.")
    except Exception as ex:
        raise CLIError(f"Could not remove the temporary packaging folder: {ex}") from ex


def copy_attached_device_log(cmd, storage_path, output_log, device):
    """Retrieve the log file from the specified device and copy it to
    the temporary storgae path.
    """
    logger.debug(" -> Getting attached device's logs.")
    output_log.write("\n\nDEVICE LOGS:")

    try:
        response = cf_diag_gatewayd(cmd.cli_ctx, device_ip=device.ip_address).diag_get_log()
        # Format file name
        device_log_file_path = os.path.join(
            storage_path, f"AzureSphere_DeviceLog_{device.device_connection_path}.bin"
        )

        with open(device_log_file_path, "wb") as device_log_file:
            device_log_file.write(response.response.body())

        message = f"Log file saved as AzureSphere_DeviceLog_{device.device_connection_path}.bin"
        logger.debug(message)
        output_log.write(f"\n -> {message}")

    except Exception as err:
        log_error_message(
            err_msg=f"Unable to retrieve or save device log:\n{type(err).__name__} was raised: {err}",
            data_log=output_log,
        )


def copy_attached_device_tech_support_data(cmd, storage_path, output_log, device):
    """Retrieve the tech support data from the specified device and copy it to
    the temporary storgae path.
    """
    logger.debug(" -> Getting attached device's tech support data.")
    output_log.write("\n\nDEVICE TECH SUPPORT DATA:")

    try:
        response = cf_diag_gatewayd(
            cmd.cli_ctx, device_ip=device.ip_address
        ).diag_get_error_report_data()
        # Format file name
        tech_support_data_file_path = os.path.join(
            storage_path, f"AzureSphere_DeviceTechSupportData_{device.device_connection_path}.bin"
        )

        with open(tech_support_data_file_path, "wb") as device_log_file:
            device_log_file.write(response.response.body())

        message = f"Log file saved as AzureSphere_DeviceTechSupportData_{device.device_connection_path}.bin"
        logger.debug(message)
        output_log.write(f"\n -> {message}")

    except Exception as err:
        log_error_message(
            err_msg=f"Unable to retrieve or save device tech support data:\n{type(err).__name__} was raised: {err}",
            data_log=output_log,
        )


def log_error_message(err_msg, data_log):
    """Log error message to the data log and to the logger."""
    logger.error(err_msg)
    data_log.write(f"\n -> {err_msg}")


def log_attached_device_details(cmd: AzCliCommand, output_log, device):
    """Gather device details of the specified device."""
    logger.debug(" -> Getting attached device's details.")
    output_log.write("\nDEVICE DETAILS:")
    output_log.write(f"\nDevice Connection Path: {device.device_connection_path}")
    output_log.write(f"\nDevice URL:  https://{device.ip_address}/")

    is_unresponsive_device_found = False
    try:
        response = cf_device_gatewayd(
            cmd.cli_ctx, device_ip=device.ip_address
        ).device_get_device_security_state()
        if response.device_identifier:
            device_id = response.device_identifier
        else:
            device_id = response.device_identity_public_key

        output_log.write(f"\n -> Device ID: {device_id}")
        output_log.write(f"\n -> Is Responding: true")

    except Exception as ex:
        if isinstance(ex, (ServiceRequestError)):
            is_unresponsive_device_found = True

        responding_str = "true" if is_unresponsive_device_found else "false"
        output_log.write(f"\n -> Device ID: cannot get ID '{ex}'")
        output_log.write(f"\n -> Is Responding: {responding_str}")


def log_attached_device_installed_images(cmd: AzCliCommand, output_log, device_ip):
    """Gather information about the images installed on the specified device."""
    logger.debug(" -> Getting attached device's image list.")

    output_log.write("\n\nIMAGES STATUS:")

    images_client = cf_image_gatewayd(cmd.cli_ctx, device_ip=device_ip)
    # Get all images from the device.
    get_images_response = images_client.images_get_images()

    output_log.write(
        f"\n -> Is OTA update in progress: {get_images_response.is_ota_update_in_progress}"
    )
    output_log.write(f"\n -> Has staged updates: {get_images_response.has_staged_updates}")
    output_log.write(f"\n -> Restart required: {get_images_response.restart_required}")

    output_log.write(f"\n\nINSTALLED COMPONENTS:")
    if not get_images_response.components:
        output_log.write("\n -> ** NONE FOUND **")

    for component in get_images_response.components:
        output_log.write(f"\n -> [{component.uid}] '{component.name}'")
        image_type = get_image_type_name(component.image_type)
        output_log.write(f"\n   -> Type: '{image_type}'")
        output_log.write(f"\n   -> Images: {component.images[0].uid}")
        output_log.write(f"\n   -> Is update staged: {component.is_update_staged}")


def log_attached_device_capabilities(cmd: AzCliCommand, output_log, device_ip):
    """Gather information about the capabilities of the specified device."""
    logger.debug(" -> Getting attached device's capability list.")

    output_log.write("\n\nINSTALLED CAPABILITIES:")

    try:
        response = cf_device_gatewayd(
            cmd.cli_ctx, device_ip=device_ip
        ).device_get_device_capabilities()

        if not response.device_capabilities:
            output_log.write("\n -> ** NONE FOUND **")
            return

        for cap in response.device_capabilities:
            output_log.write(f"\n -> {get_support_data_capability_type_name(cap)}")
    except Exception as err:
        log_error_message(
            err_msg=f"Could not get attached device's capability list:\n{type(err).__name__} was raised: {err}",
            data_log=output_log,
        )

    return


def log_attached_device_network_state(cmd: AzCliCommand, output_log, device_ip):
    """Gather information about the networking state of the specified device."""
    logger.debug(" -> Getting attached device's networking status.")
    output_log.write("\n\nNETWORK STATUS:")

    try:
        response = cf_network_gatewayd(cmd.cli_ctx, device_ip=device_ip).net_get_network_status()
        output_log.write(
            f"\n -> Is device authentication ready: {response.device_authentication_is_ready}"
        )
        output_log.write(f"\n -> Network time sync status      : '{response.network_time_sync}'")

        logger.debug(" -> Getting attached device's network interface(s) status.")
        output_log.write("\n\nINTERFACE STATUS:")

        response = cf_network_gatewayd(
            cmd.cli_ctx, device_ip=device_ip
        ).net_get_all_network_interface_status()

        if not response.interfaces:
            output_log.write("\n -> ** NO INTERACES FOUND **")
            return

        for network_interface in response.interfaces:
            output_log.write(f"\n -> Interface name: [{network_interface.interface_name}]")
            output_log.write(
                f"\n   -> Network interface up               : {network_interface.interface_up}"
            )
            output_log.write(
                f"\n   -> Connected to network               : {network_interface.connected_to_network}"
            )
            output_log.write(
                f"\n   -> Interface has IP address assigned  : {network_interface.ip_acquired}"
            )
            output_log.write(
                f"\n   -> Connected to internet              : {network_interface.connected_to_internet}"
            )
    except Exception as err:
        log_error_message(
            err_msg=f"Could not get attached device's network status:\n{type(err).__name__} was raised: {err}",
            data_log=output_log,
        )


def log_attached_device_stored_wifi_networks(cmd: AzCliCommand, output_log, device_ip):
    """Gather information about the stored Wi-Fi networks of the specified device."""
    logger.debug(" -> Getting attached device's stored Wi-Fi networks.")
    output_log.write("\n\nWI-FI NETWORKS STORED ON DEVICE:")

    try:
        response = cf_wifi_gatewayd(
            cmd.cli_ctx, device_ip=device_ip
        ).wifi_get_configured_wifi_networks()

        if not response.values:
            output_log.write("\n -> ** NONE FOUND **")
            return

        for wifi_network in response.values:
            output_log.write(f"\n -> [{wifi_network.id}] '{wifi_network.ssid}'")
            output_log.write(f"\n   -> Connection state: {wifi_network.connection_state}")
            output_log.write(f"\n   -> Config state: {wifi_network.config_state}")
            output_log.write(f"\n   -> Security state: {wifi_network.security_state}")
    except Exception as err:
        log_error_message(
            err_msg=f"Could not get attached device's stored Wi-Fi networks:\n{type(err).__name__} was raised: {err}",
            data_log=output_log,
        )


def log_attached_device_visible_wifi_networks(cmd: AzCliCommand, output_log, device_ip):
    """Gather information about the visible Wi-Fi networks of the specified device."""
    logger.debug(" -> Getting attached device's Wi-Fi scan results.")
    output_log.write("\n\nWI-FI NETWORKS VISIBLE TO DEVICE:")

    try:
        response = cf_wifi_gatewayd(cmd.cli_ctx, device_ip=device_ip).wifi_get_wifi_scan_results()

        if not response.values:
            output_log.write("\n -> ** NONE FOUND **")
            return

        for wifi_network in response.values:
            output_log.write(f"\n -> SSID: '{wifi_network.ssid}'")
            output_log.write(f"\n   -> BSSID: '{wifi_network.bssid}'")
            output_log.write(f"\n   -> Security state: {wifi_network.security_state}")
            output_log.write(f"\n   -> Signal level: {wifi_network.signal_level}")
            output_log.write(f"\n   -> Frequency: {wifi_network.freq}")
    except Exception as err:
        log_error_message(
            err_msg=f"Could not get attached device's Wi-Fi scan results:\n{type(err).__name__} was raised: {err}",
            data_log=output_log,
        )


def log_attached_device_wifi_status(cmd: AzCliCommand, output_log, device_ip):
    """Gather information about the Wi-Fi connection status of the specified device."""
    logger.debug(" -> Getting attached device's Wi-Fi connection status.")
    output_log.write("\n\nWI-FI CONNECTION STATUS:")

    try:
        response = cf_wifi_gatewayd(
            cmd.cli_ctx, device_ip=device_ip
        ).wifi_get_wifi_interface_state()

        output_log.write(f"\n -> MAC address: '{response.address}'")
        output_log.write(f"\n -> Connection state: '{response.connection_state}'")
        output_log.write(f"\n -> WPA state: '{response.wpa_state}'")

        if response.connection_state != "disconnected":
            output_log.write(f"\n -> Configuration state: '{response.config_state}'")
            output_log.write(f"\n -> Security state: '{response.security_state}'")
            output_log.write(f"\n -> Security state: '{response.security_state}'")
            output_log.write(f"\n -> Key management: '{response.key_mgmt}'")
            output_log.write(f"\n -> SSID: '{response.ssid}'")
            output_log.write(f"\n -> IP address: '{response.ip_address}'")
            output_log.write(f"\n -> Frequency: '{response.freq}'")
            output_log.write(f"\n -> Mode: '{response.mode}'")
            output_log.write(f"\n -> ID: '{response.id}'")
            config_name = "" if response.config_name is None else response.config_name
            output_log.write(f"\n -> Configuration name: '{config_name}'")
    except Exception as err:
        err_msg = f"Could not get attached device's Wi-Fi connection status: {err}"
        logger.warning(err_msg)
        output_log.write(f"\n -> {err_msg}")


def log_attached_device_manufacturing_state(cmd: AzCliCommand, output_log, device_ip):
    """Gather information about the manufacturing state of the specified device."""
    logger.debug(" -> Getting attached device's manufacturing state.")
    output_log.write("\n\nMANUFACTURING STATE:")

    try:
        response = cf_device_gatewayd(
            cmd.cli_ctx, device_ip=device_ip
        ).device_get_device_manufacturing_state()
        output_log.write(f"\n -> State: {response.manufacturing_state}")
    except Exception as err:
        log_error_message(
            err_msg=f"Could not get attached device's manufacturing state:\n{type(err).__name__} was raised: {err}",
            data_log=output_log,
        )


def log_attached_device_network_firewall_rulesets_status(cmd: AzCliCommand, output_log, device_ip):
    """Gather information about the network firewall rulesets of the specified device."""
    logger.debug(" -> Getting attached device's Network Firewall rulesets.")
    output_log.write("\n\nFIREWALL RULESETS:")

    try:
        response = cf_network_gatewayd(
            cmd.cli_ctx, device_ip=device_ip
        ).net_get_all_network_firewall_rulesets()

        if not response.rulesets:
            output_log.write("\n -> ** NO FIREWALL RULESETS FOUND **")
            return

        for rule_set in response.rulesets:
            output_log.write(f"\n -> Firewall Ruleset Name: '{rule_set.hook}'")
            output_log.write(f"\n -> Is Ruleset Valid: {rule_set.is_valid}")
            output_log.write("\n -> Firewall Ruleset Rules:")

            if not rule_set.rules:
                output_log.write("\n     -> No rules found.")
                output_log.write("\n")
            else:
                for rule in rule_set.rules:
                    output_log.write(f"\n     -> Source IP: '{rule.source_ip}'")
                    output_log.write(f"\n     -> Source Mask : '{rule.source_mask}'")
                    output_log.write(f"\n     -> Destination IP : '{rule.destination_ip}'")
                    output_log.write(f"\n     -> Destination Mask : '{rule.destination_mask}'")
                    output_log.write(f"\n     -> UID : '{rule.uid}'")
                    output_log.write(f"\n     -> Action : '{rule.action}'")
                    output_log.write(f"\n     -> Interface IN Name : '{rule.interface_in_name}'")
                    output_log.write(f"\n     -> Interface OUT Name : '{rule.interface_out_name}'")
                    output_log.write(f"\n     -> State : '{rule.state}'")
                    output_log.write(f"\n     -> TCP Mask : '{rule.tcp_mask}'")
                    output_log.write(f"\n     -> TCP Cmp : '{rule.tcp_cmp}'")
                    output_log.write(f"\n     -> TCP Inv : {rule.tcp_inv}")
                    output_log.write(f"\n     -> Protocol : '{rule.protocol}'")
                    output_log.write(
                        f"\n     -> Source Port Range : 'min: {rule.source_port_range.min}, max: {rule.source_port_range.max}'"
                    )
                    output_log.write(
                        f"\n     -> Destination Port Range : 'min: {rule.destination_port_range.min}, max: {rule.destination_port_range.max}'"
                    )
                    output_log.write(f"\n     -> Packets : '{rule.packets}'")
                    output_log.write(f"\n     -> Bytes : '{rule.bytes}'")
                    output_log.write("\n")
    except Exception as err:
        log_error_message(
            err_msg=f"Could not get attached device's Network firewall rulesets:\n{type(err).__name__} was raised: {err}",
            data_log=output_log,
        )


def copy_azure_activity_logs(cmd, storage_path):
    """Copy Azure CLI activity logs to the specified storage path."""
    az_cli_logs = Path(get_config_dir(), f"logs/{cmd.cli_ctx.name}.log")
    have_log_file = True
    if not az_cli_logs.is_file():
        logger.warning(f"Azure CLI activity logs could not be found at: {az_cli_logs.as_posix()}")
        have_log_file = False

    if not get_config_value(cmd, "logging", "enable_log_file", False):
        logger.warning(
            "Azure CLI activity logging is disabled. Please follow the guidance at https://aka.ms/az-sphere-getsupportdata/ to enable logging and then reproduce your issue, so that the support data includes CLI activity logs related to this issue."
        )

    if not have_log_file:
        return

    cli_activity_log_file_path = os.path.join(storage_path, AZURE_CLI_LOGS_FILE_NAME)
    shutil.copyfile(az_cli_logs, cli_activity_log_file_path)


def log_local_configuration(cmd, local_data_log):
    """Log information about the Azure Sphere CLI configuration."""
    logger.debug(" -> Getting the Azure Sphere CLI configuration.")
    local_data_log.write(f"\n -> Azure Sphere SDK version: {get_sdk_version()}")
    logger.debug(" -> Getting the Azure CLI configuration.")
    local_data_log.write("\n AZURE CLI CONFIGURATION:")

    try:
        args = "az --version"
        result = subprocess.run(args=args, shell=True, check=True, capture_output=True, text=True)
        local_data_log.write(f"\n{result.stdout}")

    except Exception as ex:
        err_msg = f"Could not get the Azure CLI and Extension configuration: {ex}"
        logger.warning(err_msg)
        local_data_log.write(f"\n -> {err_msg}")

    # Check if the user is logged in - TODO
    # aad_username = get_azsphere_config_value(Configs.AAD_USER_NAME)
    # if aad_username:
    #     local_data_log.write("\n -> Login initialized: 'True'")
    # else:
    #     local_data_log.write("\n -> Login initialized: 'False'")

    # Deployment timeout
    timeout_value = get_config_value(cmd, "defaults", "sphere.deployment-timeout", "30")
    local_data_log.write(f"\n -> Deployment timeout: {timeout_value}")


def log_network_adapter_ip_addresses(local_data_log):
    """Gather information about the local network adapter IP addresses."""
    logger.debug(" -> Getting the local network adapter IP addresses.")

    local_data_log.write("\n\nNETWORK ADAPTER LIST:")
    try:
        addrs = psutil.net_if_addrs()

        for nic, addr_details in addrs.items():
            mac_address = addr_details[0].address
            # AddressFamily.AF_LINK (-1)refers to a MAC address.
            unicast_addresses = [snic.address for snic in addr_details if snic.family != -1]
            local_data_log.write(f"\n -> {nic} : {mac_address}")
            local_data_log.write(f"\n   -> Primary NIC addresses     : {unicast_addresses}\n")

    except Exception as err:
        err_msg = f"Could not get local network adapter IP addresses: {err}"
        logger.warning(err_msg)
        local_data_log.write("\n" + err_msg)


def log_azure_sphere_network_adapter_details(local_data_log):
    """Gather information about the Azure Sphere network adapter setup."""
    logger.debug(" -> Getting the Azure Sphere network adapter setup.")

    local_data_log.write("\n\nAZURE SPHERE NETWORK ADAPTER STATUS:")
    try:
        io_counters = psutil.net_io_counters(pernic=True)
        addrs = psutil.net_if_addrs()
        stats = psutil.net_if_stats()

        for nic, addr_details in addrs.items():
            mac_address = addr_details[0].address
            unicast_addresses = [snic.address for snic in addr_details if snic.family != -1]
            if nic == "Azure Sphere":
                operational_status = "Up" if stats[nic].isup else "Down"
                local_data_log.write(f"\n -> Name                  : {nic}")
                local_data_log.write("\n -> Description           : TAP-Windows Adapter V9")
                local_data_log.write("\n -> Interface type        : Ethernet")
                local_data_log.write(f"\n -> MAC address           : {mac_address}")
                local_data_log.write(f"\n -> Operational status    : {operational_status}")
                local_data_log.write(f"\n -> Speed                 : {stats[nic].speed} MB")
                local_data_log.write("\n -> Adapter addresses:")
                local_data_log.write(f"\n   -> Unicast addresses   : {unicast_addresses}")
                local_data_log.write("\n -> IP statistics:")
                local_data_log.write(f"\n   -> Bytes received      : {io_counters[nic].bytes_recv}")
                local_data_log.write(f"\n   -> Bytes sent          : {io_counters[nic].bytes_sent}")
                local_data_log.write(
                    f"\n   -> Packets Received    : {io_counters[nic].packets_recv}"
                )
                local_data_log.write(
                    f"\n   -> Packets Sent        : {io_counters[nic].packets_sent}"
                )
                local_data_log.write(
                    f"\n   -> Total number of errors while receiving                  : {io_counters[nic].errin}"
                )
                local_data_log.write(
                    f"\n   -> Total number of errors while sending                    : {io_counters[nic].errout}"
                )
                local_data_log.write(
                    f"\n   -> Total number of incoming packets which were dropped     : {io_counters[nic].dropin}"
                )
                local_data_log.write(
                    f"\n   -> Total number of outgoing packets which were dropped     : {io_counters[nic].dropout}"
                )

                break

    except Exception as err:
        err_msg = f"Could not get the Azure Sphere network adapter setup: {err}"
        logger.warning(err_msg)
        local_data_log.write("\n" + err_msg)


def log_slip_service_status(local_data_log):
    """Gather information about the Azure Sphere SLIP service status."""
    logger.debug(" -> Getting the Azure Sphere SLIP service status.")
    local_data_log.write("\n\nSLIP SERVICE STATUS:")

    service = None
    try:
        service = psutil.win_service_get("AzureSphereDeviceCommunicationService")
        service = service.as_dict()

        if not service:
            local_data_log.write("\n -> ** SERVICE NOT FOUND **")
            return

        local_data_log.write(f"\n -> Display name: {service['display_name']}")
        local_data_log.write(f"\n -> Service Name: {service['name']}")
        local_data_log.write(f"\n -> Status: {service['status']}")
        local_data_log.write(f"\n -> Service type : Win32OwnProcess")
        local_data_log.write(f"\n -> Start type: {service['start_type']}")

    except Exception as ex:
        err_msg = f"Could not get the Azure Sphere SLIP service status: {ex}"
        logger.warning(err_msg)
        local_data_log.write("\n" + err_msg)


def log_slip_service_event_logs(local_data_log):
    """Gather the last 100 Azure Sphere SLIP service events logs."""
    import win32evtlog

    logger.debug(" -> Getting the Azure Sphere SLIP service logs.")
    local_data_log.write("\n\nSLIP SERVICE LOGS:")

    levels_list = ["None", "Critical", "Error", "Warning", "Information", "Verbose"]

    flags = win32evtlog.EVENTLOG_FORWARDS_READ | win32evtlog.EVENTLOG_SEQUENTIAL_READ
    channelName = "Azure Sphere Device Communication Service"
    flags = win32evtlog.EvtQueryReverseDirection
    evtQueryResultNo = 100
    evtQueryTimeout = -1

    evtQueryResult = win32evtlog.EvtQuery(channelName, flags)

    events = win32evtlog.EvtNext(evtQueryResult, evtQueryResultNo, evtQueryTimeout, 0)
    for event in events:
        xml_content = win32evtlog.EvtRender(event, win32evtlog.EvtRenderEventXml)

        # Parse xml content
        xml = ET.fromstring(xml_content)

        # xml namespace, root element has a xmlns definition, so we have to use the namespace
        # http://schemas.microsoft.com/win/2004/08/events/event
        xml_namespace = xml.tag.split("}")[0].strip("{")

        level = xml.find(f"./{{{xml_namespace}}}System/{{{xml_namespace}}}Level").text
        event_data = xml.find(f"./{{{xml_namespace}}}EventData/{{{xml_namespace}}}Data").text

        time_created = xml.find(f"./{{{xml_namespace}}}System/{{{xml_namespace}}}TimeCreated").get(
            "SystemTime"
        )

        local_data_log.write(f"\n -> {time_created}, [{levels_list[int(level)]}] {event_data}")


def copy_installer_logs(
    file_filter, output_dir_name, storage_path, local_data_log, start_date_time_for_logs
):
    """Helper command to copy installer logs to the specified storage path.
    The logs are filtered by the specified file filter and the number of logs to be copied is
    limited by the start_date_time_for_logs parameter."""

    try:
        files_to_copy_path = os.path.join(tempfile.gettempdir(), file_filter)
        log_files = (
            x
            for x in glob.iglob(files_to_copy_path)
            if not os.path.isdir(x) and os.path.getmtime(x) > start_date_time_for_logs
        )

        file_list = list(log_files)

        if len(file_list) == 0:
            local_data_log.write("\n -> **  NO LOGS FOUND **")
            return

        # Create a clean folder
        installer_logs_path = os.path.join(storage_path, output_dir_name)
        os.umask(0)
        os.mkdir(installer_logs_path)

        for log_file in file_list:
            shutil.copy(log_file, installer_logs_path)

        local_data_log.write(f"\n -> {len(file_list)} log files have been copied.")
    except Exception as ex:
        err_msg = f"Could not copy logs: {ex}"
        logger.warning(err_msg)
        local_data_log.write(f"\n -> {err_msg}")


def log_azsphered_service_status(local_data_log):
    """Log the Azure Sphere Device Communication service status on Linux."""
    logger.debug(" -> Getting the Azure Sphere SLIP service status.")
    local_data_log.write("\n\nSLIP SERVICE STATUS:")

    args = "systemctl status azsphered.service"

    try:
        result = subprocess.run(args=args, shell=True, check=True, capture_output=True, text=True)
        local_data_log.write(f"\n{result.stdout}")

    except Exception as ex:
        err_msg = f"Could not get Azsphere Device Communication status: {ex}"
        logger.warning(err_msg)
        local_data_log.write(f"\n -> {err_msg}")


def log_azsphered_service_event_logs(local_data_log):
    """Log the last 100 Azure Sphere Azure Sphere Device Communication service events logs on Linux."""
    logger.debug(" -> Getting the Azure Sphere Device Communication Service logs.")
    local_data_log.write("\n\nAZURE SPHERE DEVICE COMMUNICATION SERVICE LOGS:")
    import subprocess

    args = "journalctl -u azsphered.service --no-pager | tail -100"

    try:
        result = subprocess.run(args=args, shell=True, check=True, capture_output=True, text=True)
        local_data_log.write(f"\n{result.stdout}")

    except Exception as ex:
        err_msg = f"Could not get Azsphere Device Communication logs: {ex}"
        logger.warning(err_msg)
        local_data_log.write(f"\n -> {err_msg}")
