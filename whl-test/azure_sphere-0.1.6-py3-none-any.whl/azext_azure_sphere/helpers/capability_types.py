# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------
"""This file provides the device capability types."""
from enum import Enum

DeviceCapabilityType = {
    # The dictionary comprises the capabilities that can be present on the device. It should be
    # updated when new capabilities are added at gatewayd level.
    1: "AllowTestKeySignedSoftware",
    2: "EnablePlutonDebugging",
    3: "EnableA7Debugging",
    4: "EnableN9Debugging",
    5: "EnableA7GdbDebugging",
    6: "EnableIoM41Debugging",
    7: "EnableIoM42Debugging",
    8: "EnableA7Console",
    9: "EnableSltLoader",
    10: "EnableSystemSoftwareDevelopment",
    11: "EnableAppDevelopment",
    12: "EnableRfTestMode",
    13: "EnableFieldServicing",
}


class DownloadCapabilityKeyEnum(Enum):
    """The downloaded capability type.

    :param Enum: download capabilities types
    :type Enum: str
    """

    EnableAppDevelopmentKey = "appdevelopment"
    UnlockGatewayDKey = "fieldservicing"
    NoneKey = "none"


DownloadedCapabilityType = {
    # The dictionary comprises the capabilities that can be downloaded. The values should match the
    # integers returned by gatewayd.
    DownloadCapabilityKeyEnum.EnableAppDevelopmentKey.value: [11],
    DownloadCapabilityKeyEnum.NoneKey.value: [],
    DownloadCapabilityKeyEnum.UnlockGatewayDKey.value: [13],
}


def get_support_data_capability_type_name(capability_type: int):
    switcher = {
        # The dictionary comprises the capabilities names to be displayed for get support data.
        # The values should match the integers returned by gatewayd.
        1: "Allow test key signed software",
        2: "Enable Pluton debugging",
        3: "Enable A7 debugging",
        4: "Enable N9 debugging",
        5: "Enable A7 GDB debugging",
        6: "Enable IO M4 1 debugging",
        7: "Enable IO M4 2 debugging",
        8: "Enable A7 Console",
        9: "Enable SLT Loader",
        10: "Enable System Software development",
        11: "Enable App development",
        12: "Enable RF test mode",
        13: "Enable field servicing",
    }

    return switcher.get(capability_type, "Unknown capability")
