"""ImageType Enum."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

from enum import IntEnum


class ImageType(IntEnum):
    """
    Known image types
    """

    # Invalid.
    Invalid = 0

    # Better known as 1BL; code executed by the ROM on Pluton.
    OneBL = 1

    # Pluton runtime.
    PlutonRuntime = 2

    # Vendor-specific WiFi firmware.
    WifiFirmware = 3

    # Secure World runtime, a.k.a. security monitor.
    SecurityMonitor = 4

    # Normal World loader.
    NormalWorldLoader = 5

    # Device Tree, used by Normal World OS.
    NormalWorldDTB = 6

    # Normal World OS kernel.
    NormalWorldKernel = 7

    # Normal World root file system.
    RootFs = 8

    # Normal World, services written and managed by Microsoft.
    Services = 9

    # Normal World, user-mode apps.
    Applications = 10

    # Configuration data for firmware (Pluton, HlosCore).
    FirmwareConfig = 13

    # Boot Manifest (secure flash storage)
    BootManifest = 16

    # Normal World File System
    NormalWorldFileSystem = 17

    # The TrustedKeystore image
    TrustedKeystore = 19

    # An image containing policies for the device.
    Policy = 20

    # An image containing board configuration for each customer system.
    CustomerBoardConfig = 21

    # An image containing the certificates needed by the OTA update process.
    UpdateCertStore = 22

    # A manifest describing the update of our trusted keys and certificate stores.
    BaseSystemUpdateManifest = 23

    # A manifest describing the update of our system software.
    FirmwareUpdateManifest = 24

    # A manifest describing the update of 3rd-party images.
    CustomerUpdateManifest = 25

    # A manifest describing system software for recovery.
    RecoveryManifest = 26

    # A manifest set that contains 1 or more manifests and flags concerning those manifests.
    ManifestSet = 27

    # Sentinel value indicating an unspecified image type.
    Other = 28
