"""Provides helper functions for capabilities."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

import base64
from pathlib import Path

from azext_azure_sphere._client_factory_device import cf_image_gatewayd
from azext_azure_sphere.helpers.capability_types import DeviceCapabilityType
from azure.core.exceptions import HttpResponseError
from knack.log import get_logger
from knack.util import CLIError

logger = get_logger(__name__)


def check_device_capabilities(device_capabilities):
    """Check and determine if device gets EnableAppDevelopment or/and Internal capabilities."""
    is_cap_app_dev = False
    is_internal_cap = False

    # Convert the ints to enums to ease readability.
    device_capabilities_enums = [
        DeviceCapabilityType[i] for i in device_capabilities.device_capabilities
    ]

    if "EnableAppDevelopment" in device_capabilities_enums:
        is_cap_app_dev = True

    internal_cap = [
        "AllowTestKeySignedSoftware",
        "EnablePlutonDebugging",
        "EnableA7Debugging",
        "EnableN9Debugging",
        "EnableA7GdbDebugging",
        "EnableIoM41Debugging",
        "EnableIoM42Debugging",
        "EnableA7Console",
        "EnableSltLoader",
        "EnableSystemSoftwareDevelopment",
    ]

    for capability in device_capabilities_enums:
        if capability in internal_cap:
            is_internal_cap = True

    if is_cap_app_dev and is_internal_cap:
        logger.warning(
            "Your internal capabilities will be retained, including the 'EnableAppDevelopment' capability. Sideloaded images may be removed by over-the-air application updates."
        )

    return is_cap_app_dev, is_internal_cap


def update_capability(cmd, device_ip, capability_file, header=False):
    """Update capability device (device capability update)."""
    capability_file = Path(capability_file)
    capability_file_content = capability_file.read_bytes()
    bytes_base64_encoded = base64.standard_b64encode(capability_file_content)

    if header:
        client = cf_image_gatewayd(
            cmd.cli_ctx, device_ip=device_ip, enable_development_cap=bytes_base64_encoded
        )
    else:
        client = cf_image_gatewayd(cmd.cli_ctx, device_ip=device_ip)

    try:
        client.images_stage_image(capability_file_content)

    except HttpResponseError as ex:
        images = client.images_get_images()
        if images.is_ota_update_in_progress:
            raise CLIError(
                "The device did not accept the device capability file. The device is currently "
                "applying a cloud deployment and sideloading is temporarily disabled. Please retry "
                "later."
            ) from ex
        raise ex

    response = client.images_install_staged_images()
    message = "The device will restart." if response.restarting_system else ""
    logger.warning(f"The capability file {str(capability_file)} was added on the device. {message}")
