"""Provides device version checking functionality."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from enum import Enum, auto

from azure.core.pipeline import PipelineResponse
from azure.core.pipeline.transport import HttpRequest, HttpResponse
from knack.cli import CLIError
from knack.log import get_logger
from semantic_version import Version

logger = get_logger(__name__)


class DeviceVersionResult(Enum):
    """Enum representing device API version result.

    This represents the relative API version difference between the
    device API version and the SDK API version.
    """

    OLD_BY_MAJOR_VERSION = auto()
    OLD_BY_MINOR_VERSION = auto()
    CORRECT_VERSION = auto()
    NEW_BY_MINOR_VERSION = auto()
    NEW_BY_MAJOR_VERSION = auto()
    INVALID_VERSION = auto()


SDK_VERSION = Version("4.4.0")
GA_VERSION_BOUNDARY = Version("4.0.0")
VERSION_HEADER_FIELD_NAME = "REST-API-Version"

DEVICE_VERSION_MESSAGE_DICT = {
    DeviceVersionResult.OLD_BY_MAJOR_VERSION: (
        "The Azure Sphere OS on the attached device requires an update to perform this "
        "operation, with this version of the SDK."
    ),
    DeviceVersionResult.OLD_BY_MINOR_VERSION: (
        "The Azure Sphere OS on the attached device has an available update, which may "
        "provide additional functionality for this operation, with this version of the SDK."
    ),
    DeviceVersionResult.CORRECT_VERSION: "",
    DeviceVersionResult.NEW_BY_MINOR_VERSION: (
        "The installed SDK has an available update, which may provide additional functionality "
        "for this operation, with the Azure Sphere OS version on the attached device."
    ),
    DeviceVersionResult.NEW_BY_MAJOR_VERSION: (
        "The installed SDK needs updating in order to perform this operation with the Azure "
        "Sphere OS on the attached device."
    ),
    DeviceVersionResult.INVALID_VERSION: (
        "Could not determine the communication protocol version for attached device."
    ),
}


def _get_api_version_diff(response: HttpResponse) -> DeviceVersionResult:
    """Get the API version used by the device relative to the SDK.

    The API version is determined from the 'REST-API-Version' header in
    any response form the device.

    :param response: Response from device with REST-API-Version header.
    :type response: HttpResponse
    :return: The device API version relative to the SDK's version.
    :rtype: DeviceVersionResult
    """
    old_by_major_boundary_version = Version(major=SDK_VERSION.major, minor=0, patch=0)
    old_by_minor_boundary_version = Version(
        major=SDK_VERSION.major, minor=SDK_VERSION.minor, patch=0
    )
    new_by_minor_boundary_version = Version(
        major=SDK_VERSION.major, minor=SDK_VERSION.minor + 1, patch=0
    )
    new_by_major_boundary_version = Version(major=SDK_VERSION.major + 1, minor=0, patch=0)

    device_semantic_version = None
    try:
        device_semantic_version = Version(response.headers["REST-API-Version"])
    except (ValueError, AttributeError, KeyError) as ex:
        logger.info(ex)

    if device_semantic_version is None:
        return DeviceVersionResult.INVALID_VERSION
    if device_semantic_version < old_by_major_boundary_version:
        return DeviceVersionResult.OLD_BY_MAJOR_VERSION
    if device_semantic_version < old_by_minor_boundary_version:
        return DeviceVersionResult.OLD_BY_MINOR_VERSION
    if device_semantic_version < new_by_minor_boundary_version:
        return DeviceVersionResult.CORRECT_VERSION
    if device_semantic_version < new_by_major_boundary_version:
        return DeviceVersionResult.NEW_BY_MINOR_VERSION
    return DeviceVersionResult.NEW_BY_MAJOR_VERSION


def version_checked_error(
    ex: Exception,
    response: HttpResponse,
    check_invalid: bool = True,
    check_major: bool = True,
    check_minor: bool = True,
) -> Exception:
    """Determine if an error may be due to incompatible API versions.

    If the error is due to a major/invalid version difference between
    the device and SDK API versions, then a DeviceVersionError is thrown
    from the original error.  If it may be due to a minor version
    difference a warning is printed.  Otherwise the error is returned.

    :param ex: The error who's cause is to be determined.
    :type ex: Exception
    :param response: The response that triggered the error, used to get
        the device API version from.
    :type response: HttpResponse
    :param check_invalid: Whether to raise a DeviceAPIVersionError if
        the device version is invalid, defaults to True.
    :type check_invalid: bool, optional
    :param check_major: Whether to raise a DeviceAPIVersionError if
        the API versions differ by a major version, defaults to True.
    :type check_major: bool, optional
    :param check_minor: Whether to raise a DeviceAPIVersionError if
        the API versions differ by a minor version, defaults to True.
    :type check_minor: bool, optional
    :raises DeviceAPIVersionError: An error advising to update either
        the device or SDK.
    :return: The original error if it was not caused by an API version
        issue.
    :rtype: Exception
    """
    device_version_result = _get_api_version_diff(response)
    device_version_message = DEVICE_VERSION_MESSAGE_DICT[device_version_result]

    if check_invalid and device_version_result == DeviceVersionResult.INVALID_VERSION:
        raise CLIError(device_version_message) from ex

    if check_major and device_version_result in [
        DeviceVersionResult.OLD_BY_MAJOR_VERSION,
        DeviceVersionResult.NEW_BY_MAJOR_VERSION,
    ]:
        raise CLIError(device_version_message) from ex

    if check_minor and device_version_result in [
        DeviceVersionResult.OLD_BY_MINOR_VERSION,
        DeviceVersionResult.NEW_BY_MINOR_VERSION,
    ]:
        logger.warning(device_version_message)

    return ex


def warn_if_deprecated_os(response: PipelineResponse[HttpRequest, HttpResponse]):
    """Log a warning if the OS is deprecated.

    If the API version header is greater than the GA_VERSION_BOUNDARY
    then it is safe to assume that the device has a post GA OS on it.

    :param response: The response from gatewayd.
    :type response: PipelineResponse[HttpRequest, HttpResponse]
    """

    deprecated_os_warning = (
        "Your device's Azure Sphere OS version is deprecated. "
        "Run 'az sphere device recover' to erase your device and move it to a current OS version. "
        "See https://aka.ms/AzureSphereUpgradeGuidance for further advice and support."
    )
    headers = response.http_response.headers
    if (not VERSION_HEADER_FIELD_NAME in headers) or Version(
        headers[VERSION_HEADER_FIELD_NAME]
    ) < GA_VERSION_BOUNDARY:
        logger.warning(deprecated_os_warning)
