"""Provides device error code parsing functionality."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from enum import Enum, unique
from typing import Dict

from azext_azure_sphere.sdk.azure_sphere_gatewayd.azure.sphere.gatewayd.models import Error


@unique
class ErrorCategory(Enum):
    """Enum representing the internal error category from the device."""

    OSKernel = 0
    ApplicationManager = 1
    ApplicationManifest = 2
    LifetimeManager = 3
    Mounter = 4
    Peripheral = 5
    Permissions = 6
    ImageUpdate = 7
    Test = 8
    TestPassthrough = 9
    Rest = 10
    Network = 11
    WpaRequest = 12
    Wifi = 13
    RestApplication = 14
    Http = 15
    RestUpdate = 16
    LogManager = 17
    NetConfig = 30  # exp23-a7-nw / EXP23_ERROR_CATEGORY_ID_30
    CertStorage = 37


ERROR_CODE_MASK = 0xFFFFF
ERROR_CODE_SHIFT = 0
ERROR_CATEGORY_MASK = 0xFFF00000
ERROR_CATEGORY_SHIFT = 20


def create_error_value(error_category: ErrorCategory, error_code: int) -> int:
    """Return an error value that is made up of the category and code.

    The error value is used to index into a dictionary, which stores the
    error messages associated with a given category and code.

    :param error_category: Category which represents a category of error
        codes in the device's internal error numbering system.
    :type error_category: ErrorCategory
    :param error_code: Integer which represents a specific error code in
        the device's internal error numbering system.
    :type error_code: int
    :return: The error value, which is a combination of the error
        category and code code.
    :rtype: int
    """
    error_value = ((error_code << ERROR_CODE_SHIFT) & ERROR_CODE_MASK) | (
        (error_category.value << ERROR_CATEGORY_SHIFT) & ERROR_CATEGORY_MASK
    )

    return error_value


# pylint: disable=line-too-long
# fmt: off
ERROR_MESSAGE_MAP_DICT: Dict[int, str] = {
    create_error_value(ErrorCategory.ApplicationManager, 2): "Application manifest must not include a policy field. See https://aka.ms/AzureSphereAppManifest for more information.", # policy is present
    create_error_value(ErrorCategory.ApplicationManager, 3): "Application manifest must not include one of the specified capabilities. See https://aka.ms/AzureSphereAppManifest for more information.", # 1st party capability
    create_error_value(ErrorCategory.ApplicationManager, 15): "Could not execute application; the application image is not valid.", # seen when loading an app built with incorrect compilation options
    create_error_value(ErrorCategory.ApplicationManager, 25): "Application manifest requested pins that are already in use", # seen when sideloading app that conflicts with a board config
    create_error_value(ErrorCategory.ApplicationManager, 20): "Operation not permitted; check if application development capability is enabled ('az sphere device enable-development')", # seen when trying to delete apps
    create_error_value(ErrorCategory.ApplicationManifest, 7): "Application manifest must not include one of the specified capabilities. See https://aka.ms/AzureSphereAppManifest for more information.", # error parsing toggle state
    create_error_value(ErrorCategory.ApplicationManifest, 1): "Could not parse application manifest JSON. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 3): "Application manifest must contain 'EntryPoint' string field. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 4): "Application manifest must contain 'Schema' string field. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 5): "Application manifest must contain 'CmdArgs' string array. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 6): "Application manifest must contain 'Capabilities' object. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 9): "Application manifest 'Capabilities' field 'AllowedConnections' or 'AllowedApplicationConnections' is not parseable. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 10): "Application manifest 'Capabilities' field 'Gpio' is not parseable. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 13): "Could not parse peripheral capability field from application manifest. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 15): "Application manifest 'Capabilities' field 'WifiConfig' is not parseable. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 16): "Application manifest 'EntryPoint' field is not parseable. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 17): "Application manifest 'SchemaVersion' field is not compatible. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 18): "Application manifest requests a UART that is not available.",
    create_error_value(ErrorCategory.ApplicationManifest, 21): "Application manifest must not include a policy field. See https://aka.ms/AzureSphereAppManifest for more information.", # error parsing policy
    create_error_value(ErrorCategory.ApplicationManifest, 22): "Application manifest 'EntryPoint' field does not exist. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 23): "Application manifest 'EntryPoint' is not a file. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 24): "Application manifest 'Capabilities' field 'DeviceAuthentication' is not parseable. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 25): "Application manifest is missing from image",
    create_error_value(ErrorCategory.ApplicationManifest, 26): "Application manifest specifies an unknown application type. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 28): "Application manifest 'Capabilities' field 'DeviceAuthentication' is not available for use. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 29): "Application manifest 'Capabilities' field 'DeviceAuthentication' is too long. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 30): "Application manifest 'Capabilities' field 'SystemTime' is not parseable. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 31): "Application manifest 'Capabilities' field 'MutableStorage' must be a JSON object type. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 32): "Application manifest 'Capabilities' field 'MutableStorage' must include 'SizeKB' field. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 33): "Application manifest 'Capabilities' field 'MutableStorage' is not parseable. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 34): "Application manifest 'Capabilities' field 'MutableStorage' specifies a 'SizeKB' that is too large. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 35): "Application manifest specifies peripherals that use the same underlying pin",
    create_error_value(ErrorCategory.ApplicationManifest, 36): "Application manifest 'Capabilities' field 'AllowedTcpServerPorts' is not parseable. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 37): "Application manifest 'Capabilities' field 'AllowedUdpServerPorts' is not parseable. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 38): "Application manifest 'Capabilities' field 'AllowedTcpServerPorts' has an invalid value. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 39): "Application manifest 'Capabilities' field 'AllowedUdpServerPorts' has an invalid value. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 40): "Application manifest 'Capabilities' field 'TimeSyncConfigParseError' has an invalid value. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 41): "Application manifest 'Capabilities' field 'DhcpService' is not parseable. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 42): "Application manifest 'Capabilities' field 'SntpService' is not parseable. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 43): "Application manifest 'Capabilities' field 'AllowedApplicationConnections' is not parseable. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 44): "Application manifest 'Capabilities' field 'CertStore' is not parseable. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 45): "Application manifest 'Capabilities' field 'EnterpriseWifiConfig' is not parseable. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 46): "Application manifest 'Capabilities' field 'SystemEventNotifications' is not parseable. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 47): "Application manifest 'Capabilities' field 'SoftwareUpdateDeferral' is not parseable. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 48): "Application manifest 'Capabilities' field 'PowerControls' is not parseable: it isn't an array of PowerControls, or it contains duplicate entries. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 49): "Application manifest 'Capabilities' field 'PowerControls' is empty. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ApplicationManifest, 50):  "Application manifest 'Capabilities' field 'PowerControls' has an invalid value. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.ImageUpdate, 15): "Image not trusted by device; check if application development capability is enabled ('az sphere device enable-development')",
    create_error_value(ErrorCategory.ImageUpdate, 18): "Image could not be staged; check that it is a valid image package",
    create_error_value(ErrorCategory.ImageUpdate, 24): "Installation failed; check if application development capability is enabled ('az sphere device enable-development')",
    create_error_value(ErrorCategory.ImageUpdate, 37): "Permission denied; check if application development capability is enabled ('az sphere device enable-development')",
    create_error_value(ErrorCategory.ImageUpdate, 39): "Over-the-air updating of the device is in progress and sideloading is temporarily disabled. Please retry later.",
    create_error_value(ErrorCategory.ImageUpdate, 47): "Image has an invalid component ID. Re-package your image and retry.",
    create_error_value(ErrorCategory.LifetimeManager, 1): "Application already exists on the device",
    create_error_value(ErrorCategory.LifetimeManager, 7): "A reboot is required",
    create_error_value(ErrorCategory.LifetimeManager, 10): "Cannot start application in debug mode; Debugging server is not present on device; try running 'az sphere device enable-development'.",
    create_error_value(ErrorCategory.Mounter, 2): "The application has already been deployed to this device",
    create_error_value(ErrorCategory.OSKernel, 13): "Permission denied; application development capability may be required ('az sphere device enable-development')",
    create_error_value(ErrorCategory.Peripheral, 3): "Application manifest requests a GPIO that is not defined on this device. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.Peripheral, 4): "Application manifest requests a GPIO that is already in use by another application",
    create_error_value(ErrorCategory.Peripheral, 7): "Application manifest contains a peripheral that is not defined on this device. See https://aka.ms/AzureSphereAppManifest for more information.",
    create_error_value(ErrorCategory.Peripheral, 8): "Application manifest requests a peripheral that is already in use by another application",
    create_error_value(ErrorCategory.Peripheral, 15): "Application manifest requests a GPIO block that is already in use by another application",
    create_error_value(ErrorCategory.Peripheral, 16): "Application manifest requests a PWM block that is already in use by another application",
    create_error_value(ErrorCategory.RestApplication, 12): "Application is not present",
    create_error_value(ErrorCategory.RestApplication, 17): "Image not trusted by device; check if application development capability is enabled ('az sphere device enable-development')",
    create_error_value(ErrorCategory.RestApplication, 18): "Insufficient free space on the device",
    create_error_value(ErrorCategory.Wifi, 1): "Invalid interface. Possible invalid parameter. See https://aka.ms/AzureSphereEAPTLS/Setup for further information on setting up an EAP-TLS network connection.",
    create_error_value(ErrorCategory.Wifi, 2): "Network already exists",
    create_error_value(ErrorCategory.Wifi, 3): "Network not found",
    create_error_value(ErrorCategory.Wifi, 4): "Network not connected",
    create_error_value(ErrorCategory.Wifi, 8): "Invalid network properties provided. See https://aka.ms/AzureSphereEAPTLS/Setup for further information on setting up an EAP-TLS network connection.",
    create_error_value(ErrorCategory.Wifi, 11): "The network could not be found in the list of configured networks.",
    create_error_value(ErrorCategory.Wifi, 15): "SSID is too long",
    create_error_value(ErrorCategory.Wifi, 16): "Key is too long",
    create_error_value(ErrorCategory.Wifi, 17): "The Wi-Fi interface is still initializing. Please try again.",
    create_error_value(ErrorCategory.Wifi, 18): "Wi-Fi interface is disabled",
    create_error_value(ErrorCategory.Wifi, 19): "Insufficient space to store the network.",
    create_error_value(ErrorCategory.Wifi, 22): "There are not enough resources to add additional Wi-Fi networks.",
    create_error_value(ErrorCategory.Wifi, 23): "Configuration name already exists.",
    create_error_value(ErrorCategory.Wifi, 24): "Client identifier is missing.",
    create_error_value(ErrorCategory.Wifi, 25): "PSK is too short.",
    create_error_value(ErrorCategory.Rest, 1): "Possible invalid parameter entry or authentication failure. See https://aka.ms/AzureSphereEAPTLS/Setup for further information on setting up an EAP-TLS network connection.",
    create_error_value(ErrorCategory.Rest, 5): "Device is busy and refused request", # seen if you attempt two overlapping wifi scans
    create_error_value(ErrorCategory.Rest, 6): "Unable to retrieve mutable storage quota for the requested component.",
    create_error_value(ErrorCategory.Rest, 12): "Certificate identifier too long.",
    create_error_value(ErrorCategory.Rest, 16): "Configuration name too long. Configuration name must be 1-16 characters in length.",
    create_error_value(ErrorCategory.CertStorage, 2): "The supplied certificate identifier is invalid. Certificate identifiers may only consist of alphanumeric characters or .-_ ",
    create_error_value(ErrorCategory.CertStorage, 3): "Certificate contents are invalid. Please supply a valid base64-encoded certificate.",
    create_error_value(ErrorCategory.CertStorage, 4): "Certificate identifier too long. Certificate identifiers must be 1-16 characters in length.",
    create_error_value(ErrorCategory.CertStorage, 7): "No certificate with that identifier could be found on the device.",
    create_error_value(ErrorCategory.CertStorage, 11): "Unable to add certificate. Certificate store is out of space.",
    create_error_value(ErrorCategory.CertStorage, 12): "Certificate type is invalid. Certificate type must be 'client' or 'rootca'.",
    create_error_value(ErrorCategory.CertStorage, 13): "Public Certificate content is invalid.",
    create_error_value(ErrorCategory.CertStorage, 14): "Public Certificate content is too long.",
    create_error_value(ErrorCategory.CertStorage, 15): "Private Key content is invalid.",
    create_error_value(ErrorCategory.CertStorage, 16): "Private Key content is too long.",
    create_error_value(ErrorCategory.CertStorage, 17): "Private Key is not allowed for this certificate type.",
    create_error_value(ErrorCategory.CertStorage, 18): "Private Key password is too long.",
    create_error_value(ErrorCategory.CertStorage, 19): "Private Key password is not allowed for this certificate type.",
    create_error_value(ErrorCategory.CertStorage, 20): "Certificate and Private Key pair do not match.",
    create_error_value(ErrorCategory.CertStorage, 21): "Private Key password provided for unencrypted key.",
    create_error_value(ErrorCategory.Http, 4): "The content provided is too large.",
    create_error_value(ErrorCategory.NetConfig, 6): "Invalid hardware address.",
    create_error_value(ErrorCategory.NetConfig, 14): "Invalid interface.",
    create_error_value(ErrorCategory.NetConfig, 15): "Operation not permitted on interface."
}
# fmt: on


def get_error_message(error_obj: Error) -> str:
    """Return the internal device error message for an error value.

    The error value represents an internal device error category and a
    specific error within that category.  Not all error values will have
    an associated message.  If not available the category and code will
    be returned instead.

    :param error_obj: Integer representing a device internal error.
    :type error_obj: ~azure.sphere.gatewayd.models.Error
    :return: String which contains the error message for the value.
    :rtype: str
    """
    if (
        (not isinstance(error_obj, Error))
        or (not hasattr(error_obj, "error"))
        or error_obj.error is None
    ):
        return ""

    error_value = error_obj.error

    if error_value in ERROR_MESSAGE_MAP_DICT:
        error_msg = f"Internal device error: {ERROR_MESSAGE_MAP_DICT.get(error_value)}"
        return error_msg

    error_category = (error_value & ERROR_CATEGORY_MASK) >> ERROR_CATEGORY_SHIFT
    error_code = (error_value & ERROR_CODE_MASK) >> ERROR_CODE_SHIFT

    try:
        error_category = ErrorCategory(error_category).name
    except ValueError:
        pass

    return f"Internal device error: {error_category}.{error_code}"
