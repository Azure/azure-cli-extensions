"""Provides helper functions for images."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

import uuid
from collections import OrderedDict
from typing import Dict, List

from azext_azure_sphere._client_factory_device import cf_application_gatewayd, cf_image_gatewayd
from azext_azure_sphere.helpers.image_type_enum import ImageType
from azext_azure_sphere.sdk.asrm.azure.mgmt.azuresphere.models import Image
from azext_azure_sphere.sdk.azure_sphere_gatewayd.azure.sphere.gatewayd.models import (
    ComponentDetails,
)
from azuresphere_device_api import devices
from knack.log import get_logger
from knack.util import CLIError

logger = get_logger(__name__)

GDB_SERVER_COMPONENT_ID = "8548b129-b16f-4f84-8dbe-d2c847862e78"


def get_all_component_ids_and_iids(get_images_response, image_type: int = 0):
    """Get all the component ids and image ids from the get_images_response."""
    device_images_component_id_uid_list = []
    if len(get_images_response) > 0:
        for components_index in get_images_response:
            image_details = {}

            # If image_type is specified, filter only those that match the image-type.
            if image_type and components_index.image_type != image_type:
                continue

            if isinstance(components_index, ComponentDetails):
                # GWD
                image_details["cid"] = components_index.uid
                if not components_index.images or len(components_index.images) == 0:
                    raise CLIError("Could not get image details.")
                image_details["iid"] = components_index.images[0].uid
            elif isinstance(components_index, Image):
                # ASRP
                image_details["cid"] = components_index.component_id
                image_details["iid"] = components_index.image_id
            device_images_component_id_uid_list.append(image_details)

        return device_images_component_id_uid_list

    raise CLIError("Could not get images from cloud.")


def get_image_info(component_id: str, get_images_response):
    """Get image info from images response."""
    if component_id:
        # Check if the given component id actually exists on the device.
        if get_images_response.components:
            for components_index in get_images_response.components:
                if component_id == components_index.uid:
                    image_details = {}
                    image_details["cid"] = components_index.uid
                    # Check that the list of image details exists.
                    if not components_index.images or len(components_index.images) == 0:
                        raise CLIError("Could not get image details.")
                    image_details["iid"] = components_index.images[0].uid
                    return [image_details]

            raise CLIError(f"Requested component '{component_id}' is not present on the device.")
        else:
            raise CLIError("Could not get images from device.")


def get_all_images_info(
    get_images_response, image_type: int = 0, include_gdb_server: bool = False
) -> List[Dict[str, str]]:
    """Get all images based on image_type."""
    device_images_component_id_uid_list = get_all_component_ids_and_iids(
        get_images_response.components, image_type
    )

    # List now contains all applications, including gdbserver.
    # Remove the gdbserver
    if not include_gdb_server:
        for image in device_images_component_id_uid_list:
            if image["cid"] == GDB_SERVER_COMPONENT_ID:
                device_images_component_id_uid_list.remove(image)

    return device_images_component_id_uid_list


def is_image_package(data):
    """Check if data is an image package."""
    magic_number_imagepackage = bytearray([0x45, 0x3D, 0xCD, 0x28])
    magic_number_boardconfig = bytearray([0xD0, 0x0D, 0xFE, 0xED])
    magic_number_capability = bytearray([0xFD, 0x5C, 0xFD, 0x5C])

    offset = 4
    if magic_number_imagepackage == data:
        return (ImageType.Applications, "little", offset)  # little endian

    if magic_number_boardconfig == data:
        return (ImageType.CustomerBoardConfig, "big", offset)  # big endian

    if magic_number_capability == data:
        offset = 5
        return (ImageType.FirmwareConfig, "big", offset)

    return (ImageType.Other, "", 0)


def get_image_package_type(input_file):
    """Get image package type."""
    try:
        with open(input_file, "rb") as image:
            data = image.read(4)
            image_package_type, endian, offset = is_image_package(data)
            return image_package_type
    except:
        return ImageType.Other


def get_image_id_from_imagepackage_file(input_file):
    """Get image id from image package file."""
    try:
        with open(input_file, "rb") as image:
            data = image.read(4)
            image_package, endian, offset = is_image_package(data)
            if image_package == ImageType.Other:
                return None  # Not an image package, board config, or capability

            print(f"Image package type: {image_package.name}")

            if offset > 0:
                image.seek(offset)

            footer_offset = int.from_bytes(image.read(4), byteorder=endian)
            image.seek(footer_offset)
            data = image.read(32)
            footer_signature = bytearray([0x34, 0x58, 0x34, 0x4D])

            if data[:4] == footer_signature:  # footer magic number is correct
                image_id = uuid.UUID(bytes_le=image.read(16))
                return image_id
            else:
                return None
    except:
        return None


def get_component_id_from_imagepackage_file(input_file):
    """Get component id from image package file."""
    try:
        with open(input_file, "rb") as image:
            data = image.read(4)
            image_package, endian, offset = is_image_package(data)
            if image_package == ImageType.Other:
                return None  # Not an image package, board config, or capability

            print(f"Image package type: {image_package.name}")

            if offset > 0:
                image.seek(offset)

            footer_offset = int.from_bytes(image.read(4), byteorder=endian)
            image.seek(footer_offset)
            data = image.read(16)
            footer_signature = bytearray([0x34, 0x58, 0x34, 0x4D])

            if data[:4] == footer_signature:  # footer magic number is correct
                component_id = uuid.UUID(bytes_le=image.read(16))
                return component_id
            else:
                return None
    except:
        return None


def get_image_type_name(image_type: int):
    """Return the image type name."""
    if image_type == ImageType.Applications:
        return "Applications"
    if image_type == ImageType.CustomerBoardConfig:
        return "Board configuration"
    if image_type == ImageType.FirmwareConfig:
        return "Capability configuration"
    if image_type == ImageType.Invalid:
        return "Invalid"
    if image_type == ImageType.Services:
        return "Services"
    if image_type == ImageType.BaseSystemUpdateManifest:
        return "Base system update manifest"
    if image_type == ImageType.BootManifest:
        return "Boot manifest"
    if image_type == ImageType.CustomerUpdateManifest:
        return "Customer update manifest"
    if image_type == ImageType.FirmwareUpdateManifest:
        return "Firmware update manifest"
    if image_type == ImageType.ManifestSet:
        return "Manifest set"
    if image_type == ImageType.NormalWorldDTB:
        return "Normal world DTB"
    if image_type == ImageType.NormalWorldKernel:
        return "Normal world kernel"
    if image_type == ImageType.NormalWorldLoader:
        return "Normal world loader"
    if image_type == ImageType.NormalWorldFileSystem:
        return "Normal world file system"
    if image_type == ImageType.OneBL:
        return "OneBL"
    if image_type == ImageType.RecoveryManifest:
        return "Recovery manifest"
    if image_type == ImageType.RootFs:
        return "RootFS"
    if image_type == ImageType.SecurityMonitor:
        return "Security monitor"
    if image_type == ImageType.PlutonRuntime:
        return "Pluton runtime"
    if image_type == ImageType.WifiFirmware:
        return "WiFi firmware"
    if image_type == ImageType.TrustedKeystore:
        return "Trusted keystore"
    if image_type == ImageType.Policy:
        return "Policy"
    if image_type == ImageType.UpdateCertStore:
        return "Update certificate store"
    if image_type == ImageType.BaseSystemUpdateManifest:
        return "Base system update manifest"
    if image_type == ImageType.Other:
        return "Other"

    return f"System software image type {image_type}"


def get_component_ids_from_device_response(get_images_response, image_type: int = 0):
    """Get all the component ids and uids from the get_images response."""
    device_images_component_id_uid_list = []
    if get_images_response.components:
        for components_index in get_images_response.components:
            image_details = {}

            # If image_type is specified, filter only those that match the image-type.
            if image_type and components_index.image_type != image_type:
                continue

            image_details["cid"] = components_index.uid
            # Check that the list of image details exists.
            if not components_index.images or len(components_index.images) == 0:
                raise CLIError("Could not get image details.")
            image_details["iid"] = components_index.images[0].uid
            device_images_component_id_uid_list.append(image_details)

        return device_images_component_id_uid_list

    raise CLIError("Could not get images from device.")


def get_component_ids_info(component_id, get_images_response):
    """Get component id from images response."""
    if component_id:
        component_id = component_id.lower()

    component_ids_for_status = []
    if component_id:
        component_id = component_id.lower()
        component_ids_for_status = get_image_info(
            component_id=component_id, get_images_response=get_images_response
        )
    else:
        component_ids_for_status = get_all_images_info(
            get_images_response=get_images_response,
            image_type=ImageType.Applications,
        )
    return component_ids_for_status


def delete_images(
    cmd,
    device_ip: str,
    component_id: str = None,
    except_component_ids: List[str] = None,
    get_images_response=None,
    delete_gdb_server_image: bool = False,
):
    """Delete images from device."""
    except_component_id_list = []
    if except_component_ids:
        except_component_id_list = [x.lower() for x in except_component_ids]

    # Get all images from the device.
    if not get_images_response:
        images_client = cf_image_gatewayd(cmd.cli_ctx, device_ip=device_ip)
        get_images_response = images_client.images_get_images()

    # Get all component ids to delete.
    component_ids_to_delete = []
    if component_id:
        component_id = component_id.lower()
        component_ids_to_delete = get_image_info(
            component_id=component_id, get_images_response=get_images_response
        )
    else:
        component_ids_to_delete = get_all_images_info(
            get_images_response=get_images_response,
            image_type=ImageType.Applications,
            include_gdb_server=delete_gdb_server_image,
        )

    if not component_ids_to_delete:
        logger.warning("There are no components to delete.")
        return []

    app_client = cf_application_gatewayd(cmd.cli_ctx, device_ip=device_ip)

    return_response = []
    for component_id_to_delete in component_ids_to_delete:
        if except_component_id_list and component_id_to_delete["cid"] in except_component_id_list:
            info = OrderedDict()
            info["componentId"] = component_id_to_delete["cid"]
            info["imageId"] = component_id_to_delete["iid"]
            info["componentDeleted"] = False
            return_response.append(info)
            continue

        response = app_client.app_remove_component(component_id_to_delete["cid"])

        info = OrderedDict()
        info["componentId"] = component_id_to_delete["cid"]
        info["imageId"] = component_id_to_delete["iid"]
        info["componentDeleted"] = True
        info["restartingSystem"] = bool(response.restarting_system)
        return_response.append(info)

    return return_response
