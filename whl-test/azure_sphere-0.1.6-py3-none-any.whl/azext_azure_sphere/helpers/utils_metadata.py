"""Provides helper functions for metadata."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
#
import json
from pathlib import Path
from typing import List

from azext_azure_sphere.helpers.cramfs import ImagePackageReader
from azext_azure_sphere.sdk.azure_sphere_gatewayd.azure.sphere.gatewayd.models import AbiVersionSet
from azuresphere_imagemetadata.image import Image
from azuresphere_imagemetadata.metadata_sections.abi import (
    ABIDependsSection,
    ABIDependsType,
    ABIIdentity,
)
from knack.log import get_logger
from knack.util import CLIError

logger = get_logger(__name__)


def get_image_package_requirements(image_package: Path):
    """Get ABIDependsSection versions."""
    try:
        with open(image_package, "rb") as file:
            image_metadata_stream = file.read()
            image = Image(image_metadata_stream)
            for section in image.metadata.sections:
                if isinstance(section, ABIDependsSection):
                    return section.versions
            return []
    except:
        raise CLIError("Could not parse image as an image package.")


def ensure_requirements_are_statisfied(
    image_pkg_reqmnts: List[ABIIdentity], abi_versions: AbiVersionSet
):
    """Compare and check the image package requirement type used."""

    def ensure_requirement_is_satisfied(image_pkg_rqmnt: ABIIdentity):
        generic_update_device_software_message = (
            "The app requires a more recent version of the Azure "
            "Sphere operating system than is on the attached "
            "device; the software must be updated before "
            "this image package can be deployed to it."
        )

        if image_pkg_rqmnt.type == ABIDependsType.NoDependency:
            logger.warning("Invalid image package.")
            logger.debug(
                f"Image package contains requirement '{image_pkg_rqmnt.type}:{image_pkg_rqmnt.version}'."
            )
            raise CLIError(f"Invalid image requirement type '{image_pkg_rqmnt.type}'.")
        if image_pkg_rqmnt.type == ABIDependsType.SecureWorldRuntime:
            if abi_versions.secure_world_runtime < image_pkg_rqmnt.version:
                raise CLIError(generic_update_device_software_message)
        elif image_pkg_rqmnt.type == ABIDependsType.OSRuntime:
            if abi_versions.os_runtime < image_pkg_rqmnt.version:
                raise CLIError(generic_update_device_software_message)
        elif image_pkg_rqmnt.type == ABIDependsType.ApplicationRuntime:
            if abi_versions.application_runtime < image_pkg_rqmnt.version:
                raise CLIError(generic_update_device_software_message)
        else:
            logger.warning(
                f"Unrecognized image requirement '{image_pkg_rqmnt.type}' the image "
                "might not run on the device. Ensure your Azure Sphere SDK is "
                "up-to-date and try again."
            )

    for image_pkg_rqmnt in image_pkg_reqmnts:
        ensure_requirement_is_satisfied(image_pkg_rqmnt=image_pkg_rqmnt)
        return


def check_valid_beta_use(abi_versions: AbiVersionSet, image_package: Path, force_beta: bool):
    """Check if valid beta APIs are used."""
    try:
        reader = ImagePackageReader()
        app_manifest = reader.GetAppManifestFromImagePackage(image_package)
    except:
        logger.debug(
            "Could not validate this image package's app manifest. This is expected when deploying non-standard image packages."
        )
        return True

    data = json.loads(app_manifest)

    if not data.get("TargetBetaApis"):
        return True

    if data.get("TargetBetaApis"):
        if data["TargetBetaApis"].isspace():
            return True

    if abi_versions.application_runtime == data["TargetApplicationRuntimeVersion"]:
        logger.warning("This app targets Beta APIs that may change or be removed in future.")
        return True

    if force_beta:
        logger.warning(
            "This app targets Beta APIs that may no longer be supported by this device. "
            "The app may fail to start or otherwise behave unexpectedly. Please upgrade "
            "your app to target the API sets that this device supports."
        )
        return True

    return False
