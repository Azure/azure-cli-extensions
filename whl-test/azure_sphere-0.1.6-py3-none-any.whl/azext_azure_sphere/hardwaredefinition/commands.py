"""This module provides the hardware-definition commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere.hardwaredefinition.format import (
    transform_generate_header_output,
    transform_test_header_output,
)
from azext_azure_sphere.hardwaredefinition.validators import hardware_definition_file_path_validator
from azure.cli.core.commands import CliCommandType


def load_hardware_definition_command_table(self, _):
    """List of the hardware definiton commands and their configurations."""
    hardware_definition_custom_type = CliCommandType(
        operations_tmpl="azext_azure_sphere.hardwaredefinition.custom#{}"
    )

    with self.command_group(
        "sphere hardware-definition", custom_command_type=hardware_definition_custom_type
    ) as ctx:
        ctx.custom_command(
            "generate-header",
            "generate_header",
            transform=transform_generate_header_output,
            validator=hardware_definition_file_path_validator,
        )
        ctx.custom_command(
            "test-header",
            "validate_header_file",
            transform=transform_test_header_output,
            validator=hardware_definition_file_path_validator,
        )
