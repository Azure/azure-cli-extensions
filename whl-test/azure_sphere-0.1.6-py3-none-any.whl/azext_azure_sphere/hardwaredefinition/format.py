"""Provides transform functions for hardware-definition command group."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

from pathlib import PureWindowsPath

from knack.log import get_logger

logger = get_logger(__name__)


def transform_generate_header_output(result):
    """Transform the generate hardware definition command output."""
    logger.warning("Successfully generated header file.")
    # Convert Windows to POSIX paths
    result["hardware_definition_file"] = PureWindowsPath(
        result["hardware_definition_file"]
    ).as_posix()
    return result


def transform_test_header_output(result):
    """Transform the transform hardware definition command output."""
    logger.warning("Header file is consistent.")
    # Convert Windows to POSIX paths
    result["hardware_definition_file"] = PureWindowsPath(
        result["hardware_definition_file"]
    ).as_posix()
    return result
