"""Provides custom commands for hardware-definition command group."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere.helpers.utils_hardware_definition import (
    import_and_generate_header,
    import_and_test_header,
)
from knack.log import get_logger

logger = get_logger(__name__)


def generate_header(hardware_definition_file):
    """Generate a header file based on input hardware definition."""
    output_header_file_path = import_and_generate_header(hardware_definition_file)

    return {
        "hardware_definition_file": hardware_definition_file,
        "generated_header_file": output_header_file_path,
    }


def validate_header_file(hardware_definition_file):
    """Test that the existing header file matches the input hardware destination file."""
    output_header_file_path = import_and_test_header(hardware_definition_file)

    return {
        "hardware_definition_file": hardware_definition_file,
        "validated_header_file": output_header_file_path,
    }
