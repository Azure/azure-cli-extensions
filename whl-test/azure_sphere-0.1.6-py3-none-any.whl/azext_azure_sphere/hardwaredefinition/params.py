"""This module provides the parameters for the hardware-definition commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

HW_FILE_PARAM_LONG_NAME = "--hardware-definition-file"


def load_hardware_definition_arguments(self, _):
    """Load arguments for hardware definition related commands."""
    with self.argument_context("hardware-definition generate-header") as context:
        context.argument(
            "hardware_definition_file",
            type=str,
            options_list=[HW_FILE_PARAM_LONG_NAME],
            required=True,
        )
    with self.argument_context("hardware-definition test-header") as context:
        context.argument(
            "hardware_definition_file",
            type=str,
            options_list=[HW_FILE_PARAM_LONG_NAME],
            required=True,
        )
