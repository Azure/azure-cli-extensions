"""This module provides device communication service utilities."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

from sys import platform
from typing import Callable

from azext_azure_sphere.auto_detection.params import DEVICE_PARAM_LONG_NAME
from azext_azure_sphere.device_comm.exception_handler import device_comm_exception_handler_wrapper
from azext_azure_sphere.sdk.azure_sphere_devicecomm.azure.sphere.devicecomm import DeviceCommClient
from azext_azure_sphere.sdk.azure_sphere_devicecomm.azure.sphere.devicecomm.models import (
    DeviceConnectionInfo,
)
from knack.util import CLIError


@device_comm_exception_handler_wrapper
def get_single_attached_device() -> DeviceConnectionInfo:
    """Get an IP address from the single device attached to the PC.

    :raises CLIError: Error raised when multiple devices are
        attached to the PC.
    :raises CLIError: Error raised when no devices that are attached
        to the PC could be detected.
    :return: The single device attached to the PC.
    :rtype: DeviceConnectionInfo
    """

    devices = get_device_connections()
    if len(devices) > 1:
        message = (
            f"Multiple devices are connected. Please connect only one "
            f"device or specify only one device. Use the {DEVICE_PARAM_LONG_NAME} parameter to "
            f"specify a device."
        )
        raise CLIError(message)

    if len(devices) == 0:
        message = (
            "Could not connect to an Azure Sphere device. Please check "
            "the device is correctly connected. Please run 'az sphere device list-attached' to "
            "see the attached devices."
        )
        raise CLIError(message)

    return devices[0]


@device_comm_exception_handler_wrapper
def get_device_satisfying_condition(
    condition: Callable[..., bool], specifying_method: str
) -> DeviceConnectionInfo:
    """Get the first device satisfying the given condition.

    :param condition: Condition which the device must satisfy.
    :type condition: Callable[..., bool]
    :param specifying_method: String to insert into the raised error,
        tells the user which method they used to specify the device.
    :type specifying_method: str
    :raises CLIError: Error raised if multi-device functionality is used
        on a Non-Windows OS.
    :raises CLIError: Error raised if no devices satisfying the
        condition can be found.
    :return: The first device that satisfies the condition.
    :rtype: DeviceConnectionInfo
    """
    devices = get_device_connections()
    for device in devices:
        if condition(device):
            return device

    error_msg = (
        f"Could not connect to device with the provided device {specifying_method}. Please check "
        "the device is correctly connected and use 'az sphere device list-attached' to ensure you "
        "are specifying it correctly."
    )

    raise CLIError(error_msg)


@device_comm_exception_handler_wrapper
def get_count_attached_device():
    """Get count of attached devices.

    :raises CLIError: Error raised if rescan functionality is used
        on a Non-Windows OS.
    :return: Count of attached devices.
    :rtype: int
    """
    return DeviceCommClient().rescan_attached_devices()


@device_comm_exception_handler_wrapper
def get_device_connections():
    """Get list of attached devices.

    :return: List of attached devices. Empty list if no MT3620 devices are found.
    :rtype: List
    """
    return DeviceCommClient().get_devices()
