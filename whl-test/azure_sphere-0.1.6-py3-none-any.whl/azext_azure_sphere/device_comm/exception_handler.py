"""This module provides an exception handler for device comm client."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------
from functools import wraps
from typing import Callable

from azure.core.exceptions import ServiceRequestError
from knack.util import CLIError


def _device_comm_exception_handler(ex: Exception):
    if isinstance(ex, ServiceRequestError):
        message = (
            "Could not connect to the Azure Sphere Device Communication Service. "
            "Please try again; if the issue persists, please refer to "
            "https://aka.ms/AzureSphereSDKHelp/Device and https://aka.ms/azurespheresupport "
            "for troubleshooting suggestions and support."
        )
        raise CLIError(message) from ex


def device_comm_exception_handler_wrapper(func: Callable) -> Callable:
    """Wrapper to handle device comm service exceptions

    :param func: The function to wrap which uses the device comm service
    :type func: Callable
    :raises CLIError: Raises an error if the request timed out.
    :return: The error handled wrapped function.
    :rtype: Callable
    """

    @wraps(func)
    def exception_handler(*args, **kwargs):

        try:
            return func(*args, **kwargs)
        except Exception as ex:
            _device_comm_exception_handler(ex)

            raise ex

    return exception_handler
