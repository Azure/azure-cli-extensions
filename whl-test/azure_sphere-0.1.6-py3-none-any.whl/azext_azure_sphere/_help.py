"""Provides help for 'az sphere --help' command."""
# coding=utf-8
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from knack.help_files import helps  # pylint: disable=unused-import

helps[
    "sphere"
] = """
type: group
short-summary: Manage Azure Sphere resources.
examples:
    - name: Displays a list of available subgroups and commands, along with other useful context and examples.
      text: az sphere --help
    - name: List all catalogs in a resource group.
      text: az sphere catalog list --resource-group MyResourceGroup
    - name: List all devices in a resource group and catalog.
      text: az sphere device list --resource-group MyResourceGroup --catalog MyCatalog
"""

helps[
    "sphere show-sdk-version"
] = """
type: command
short-summary: Show the version of the Azure Sphere SDK installed.
examples:
    - name: Show the version of the Azure Sphere SDK installed.
      text: az sphere show-sdk-version
"""

helps[
    "sphere get-support-data"
] = """
type: command
short-summary: Gather diagnostic data about your local system, cloud and device configurations.
parameters:
    - name: "--output-file -of"
      short-summary: The path and filename of the .zip file to save the support data in. You can provide a relative or absolute path. If you do not specify a filename, the support data will be saved in a file called support_data.zip in the specified directory. If you specify a filename, it must have the .zip extension. (Path).
examples:
    - name: Gather diagnostic data about your local system, cloud and device configurations for devices in a resource group and catalog.
      text: az sphere get-support-data --resource-group MyResourceGroup --catalog MyCatalog --output-file archive.zip
"""

helps[
    "sphere catalog"
] = """
type: group
short-summary: Manage catalogs.
examples:
    - name: Create a new catalog "MyCatalog" in resource group "MyResourceGroup".
      text: az sphere catalog create --resource-group MyResourceGroup --name MyCatalog
    - name: List all catalogs in a resource group.
      text: az sphere catalog list --resource-group MyResourceGroup
    - name: Show details of a catalog using resource group and catalog name.
      text: az sphere catalog show --resource-group MyResourceGroup --catalog MyCatalog
    - name: Download error reports in a csv file using resource group and catalog name.
      text: az sphere catalog download-error-report --resource-group MyResourceGroup --catalog MyCatalog --output-file myErrorReport.csv
    """

helps[
    "sphere catalog create"
] = """
type: command
short-summary: Create a catalog.
parameters:
    - name: "--name -n"
      short-summary: "The catalog name."
examples:
    - name: Create a new catalog "MyCatalog" in resource group "MyResourceGroup".
      text: az sphere catalog create --resource-group MyResourceGroup --name MyCatalog
"""

helps[
    "sphere catalog delete"
] = """
type: command
short-summary: Delete a catalog.
parameters:
    - name: "--catalog -c"
      short-summary: "The catalog name."
      populator-commands: 
        - az sphere catalog list
examples:
    - name: Delete a catalog using resource group and catalog name.
      text: az sphere catalog delete --resource-group MyResourceGroup --catalog MyCatalog
"""

helps[
    "sphere catalog list"
] = """
type: command
short-summary: List available catalogs either in a resource group or a subscription.
parameters:
    - name: "--all"
      short-summary: "List all catalogs in all resource groups in a subscription."
examples:
    - name: List all catalogs in a resource group.
      text: az sphere catalog list --resource-group MyResourceGroup
    - name: List all catalogs in all resource groups in a subscription.
      text: az sphere catalog list --all
"""

helps[
    "sphere catalog show"
] = """
type: command
short-summary: Show details of a catalog.
parameters:
    - name: "--catalog -c"
      short-summary: "The catalog name."
      populator-commands: 
        - az sphere catalog list
examples:
    - name: Show details of a catalog using resource group and catalog name.
      text: az sphere catalog show --resource-group MyResourceGroup --catalog MyCatalog
"""

helps[
    "sphere catalog download-error-report"
] = """
type: command
short-summary: List or download the available error reports for the selected catalog.
parameters:
    - name: "--output-file -of"
      short-summary:  "The path to the new csv file to create, containing the error report data. You can provide a relative or absolute path. If this parameter is not set, the file will be saved in the current folder with a default name. (Path)."
examples:
    - name: Download error reports in a csv file using resource group and catalog name.
      text: az sphere catalog download-error-report --resource-group MyResourceGroup --catalog MyCatalog --output-file myErrorReport.csv
"""

helps[
    "sphere product"
] = """
type: group
short-summary: Manage products in your resource group and catalog.
examples:
    - name: Create a new product "MyProduct" in resource group "MyResourceGroup" and catalog "MyCatalog".
      text: az sphere product create --resource-group MyResourceGroup --catalog MyCatalog --name MyProduct --description MyDescription
    - name: List all catalogs in a resource group and catalog.
      text: az sphere product list --resource-group MyResourceGroup --catalog MyCatalog
    - name: Show details of a product using resource group, catalog name, and product name. 
      text: az sphere product show --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct
    """

helps[
    "sphere product create"
] = """
type: command
short-summary: Create a new product in your resource group and catalog.
parameters:
    - name: "--name -n"
      short-summary: Alphanumeric name of the product.
    - name: "--description -d"
      short-summary: A description of the product.
examples:
    - name: Create a new product "MyProduct" in resource group "MyResourceGroup" and catalog "MyCatalog".
      text: az sphere product create --resource-group MyResourceGroup --catalog MyCatalog --name MyProduct --description MyDescription
"""

helps[
    "sphere product update"
] = """
type: command
short-summary: Update a product's details in your resource group and catalog.
parameters:
    - name: "--product -p"
      short-summary: The product name.
      populator-commands:
        - az sphere product list
    - name: "--description -d"
      short-summary: The new product description to update the product to.
examples:
    - name: Update the properties of a product.
      text: az sphere product update --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --description MyDescription
"""

helps[
    "sphere product delete"
] = """
type: command
short-summary: Delete the specified product.
parameters:
    - name: "--product -p"
      short-summary: The product name.
      populator-commands: 
        - az sphere product list
examples:
    - name: Delete a product using resource group, catalog name, and product name.
      text: az sphere product delete --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct
"""

helps[
    "sphere product list"
] = """
type: command
short-summary: List all products in your resource group and catalog.
examples:
    - name: List all products in a resource group and catalog.
      text: az sphere product list --resource-group MyResourceGroup --catalog MyCatalog
"""

helps[
    "sphere product show"
] = """
type: command
short-summary: Show details of a product in your resource group and catalog.
parameters:
    - name: "--product -p"
      short-summary: The product name.
      populator-commands: 
        - az sphere product list
examples:
    - name: Show details of a product using resource group, catalog name, and product name. 
      text: az sphere product show --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct
"""

helps[
    "sphere device-group"
] = """
type: group
short-summary: Manage device groups in your resource group and catalog.
examples:
    - name: Create a new device group "Development" in resource group "MyResourceGroup", catalog "MyCatalog", product "MyProduct", description "MyDescription", and default regional data boundary.
      text: az sphere device-group create --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --name Development --description MyDescription
    - name: Create default device groups in resource group "MyResourceGroup", catalog "MyCatalog", and product "MyProduct".
      text: az sphere device-group create-defaults --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct
    - name: List all device groups in a resource group and catalog.
      text: az sphere device-group list --resource-group MyResourceGroup --catalog MyCatalog
    - name: List all device groups with the specified name in a resource group and catalog.
      text: az sphere device-group list --resource-group MyResourceGroup --catalog MyCatalog --device-group Development
    - name: List all device groups in a resource group, catalog, and product.
      text: az sphere device-group list --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct
    - name: Show details of a device group using resource group, catalog name, product name and device group name.
      text: az sphere device-group show --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --device-group Development
"""

helps[
    "sphere device-group list"
] = """
type: command
short-summary: List all device groups in a catalog.
parameters:
    - name: "--product -p"
      short-summary: List all device groups in a product.
      populator-commands:
        - az sphere product list
    - name: "--device-group -dg"
      short-summary: List all device groups that have a specified name.
examples:
    - name: List all device groups in a resource group and catalog.
      text: az sphere device-group list --resource-group MyResourceGroup --catalog MyCatalog
    - name: List all device groups with the specified name in a resource group and catalog.
      text: az sphere device-group list --resource-group MyResourceGroup --catalog MyCatalog --device-group Development
    - name: List all device groups in a resource group, catalog, and product.
      text: az sphere device-group list --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct
"""

helps[
    "sphere device-group show"
] = """
type: command
short-summary: Show a device group's details.
parameters:
    - name: "--product -p"
      short-summary: The product name for which to show the device group.
      populator-commands:
        - az sphere product list
    - name: "--device-group -dg"
      short-summary: The device group to show.
      populator-commands: 
        - az sphere device-group list
examples:
    - name: Show details of a device group using resource group, catalog name, product name, and device group name.
      text: az sphere device-group show --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --device-group MyDeviceGroup
"""

helps[
    "sphere device-group create"
] = """
type: command
short-summary: Create a device group.
parameters:
    - name: "--product -p"
      short-summary: The product name.
      populator-commands:
        - az sphere product list
    - name: "--name -n"
      short-summary: Alphanumeric name of the device group.
    - name: "--description -d"
      short-summary: Description of the device group.
    - name: "--os-feed -f"
      short-summary: The OS feed type to use for OS updates.
    - name: "--application-update -a"
      short-summary: Application update policy for this device group.
    - name: "--allow-crash-dumps-collection -cd"
      short-summary: Provide consent for collection of crash dumps by Microsoft for this device-group. For more information, see https://aka.ms/AzureSphereCrashDumpsCollection.
    - name: "--regional-data-boundary -r"
      short-summary: Regional data boundary for this device group.
examples:
    - name: Create a new device group "MyDeviceGroup" in resource group "MyResourceGroup", catalog "MyCatalog", product "MyProduct", description "MyDescription", and default regional data boundary.
      text: az sphere device-group create --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --name MyDeviceGroup --description MyDescription
    - name: Create a new device group "MyDeviceGroup" in resource group "MyResourceGroup", catalog "MyCatalog", product "MyProduct", description "MyDescription", and specify a regional data boundary.
      text: az sphere device-group create --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --name MyDeviceGroup --description MyDescription --regional-data-boundary EU
"""

helps[
    "sphere device-group create-defaults"
] = """
type: command
short-summary: Create default device groups targeting a product.
parameters:
    - name: "--product -p"
      short-summary: The product name.
      populator-commands:
        - az sphere product list
examples:
    - name: Create default device groups in resource group "MyResourceGroup", catalog "MyCatalog", and product "MyProduct".
      text: az sphere device-group create-defaults --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct
"""

helps[
    "sphere device-group update"
] = """
type: command
short-summary: Update a device group's details.
parameters:
    - name: "--product -p"
      short-summary: The product name.
      populator-commands:
        - az sphere product list
    - name: "--device-group -dg"
      short-summary: The device group name.
      populator-commands: 
        - az sphere device-group list
    - name: "--description -d"
      short-summary: A new description of the device group.
    - name: "--os-feed -f"
      short-summary: The OS feed type to use for OS updates.
    - name: "--application-update -a"
      short-summary: Application update policy for this device group.
    - name: "--allow-crash-dumps-collection -cd"
      short-summary: Provide consent for collection of crash dumps by Microsoft for this device-group. For more information, see https://aka.ms/AzureSphereCrashDumpsCollection.
    - name: "--regional-data-boundary -r"
      short-summary: Regional data boundary for this device group.
examples:
    - name: Update the properties of a device group.
      text: az sphere device-group update --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --device-group MyDeviceGroup --description NewDescription
"""

helps[
    "sphere device-group delete"
] = """
type: command
short-summary: Delete the specified device group.
parameters:
    - name: "--product -p"
      short-summary: The product for which to delete the device groups.
      populator-commands:
        - az sphere product list
    - name: "--device-group -dg"
      short-summary: The device group name.
      populator-commands: 
        - az sphere device-group list
examples:
    - name: Delete a device group using resource group, catalog name, product name, and device group name.
      text: az sphere device-group delete --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --device-group MyDeviceGroup
"""

helps[
    "sphere image-package"
] = """
type: group
short-summary: Manage image packages.
examples:
    - name: Show details of an image package. 
      text: az sphere image-package show --image-package MyImage.imagepackage
"""

helps[
    "sphere image-package show"
] = """
type: command
short-summary: Show details of a given image package.
parameters:
    - name: "--image-package"
      short-summary: Path to the image package file to show details for. You can provide a relative or absolute path.
examples:
    - name: Show details of an image package. 
      text: az sphere image-package show --image-package MyImage.imagepackage
"""

helps[
    "sphere image"
] = """
type: group
short-summary: Manage images in your resource group and catalog.
examples:
    - name: Add a new image in resource group "MyResourceGroup" and catalog "MyCatalog".
      text: az sphere image add --resource-group MyResourceGroup --catalog MyCatalog --image-path MyImage.imagepackage
    - name: List all images in a resource group and catalog.
      text: az sphere image list --resource-group MyResourceGroup --catalog MyCatalog
    - name: Show details of an image using resource group, catalog name, and image ID. 
      text: az sphere image show --resource-group MyResourceGroup --catalog MyCatalog --image adb44b96-2642-4643-8c30-5f681f466425
"""

helps[
    "sphere image show"
] = """
type: command
short-summary: Show details of an existing image from your catalog.
parameters:
    - name: "--image"
      short-summary: The image ID.
      populator-commands: 
        - az sphere image list
examples:
    - name: Show details of an image using resource group, catalog name, and image ID. 
      text: az sphere image show --resource-group MyResourceGroup --catalog MyCatalog --image adb44b96-2642-4643-8c30-5f681f466425
"""

helps[
    "sphere image list"
] = """
type: command
short-summary: List all images in your resource group and catalog.
examples:
    - name: List all images in a resource group and catalog.
      text: az sphere image list --resource-group MyResourceGroup --catalog MyCatalog
"""

helps[
    "sphere image add"
] = """
type: command
short-summary: Add an image to your catalog from your local machine.
parameters:
    - name: "--image-path -img"
      short-summary: Path to a local image file.
    - name: "--regional-data-boundary -r"
      short-summary: Regional data boundary for this image.
examples:
    - name: Add a new image in resource group "MyResourceGroup" and catalog "MyCatalog".
      text: az sphere image add --resource-group MyResourceGroup --catalog MyCatalog --image-path MyImage.imagepackage
    - name: Add a new image in resource group "MyResourceGroup", catalog "MyCatalog", and Regional data boundary "EU".
      text: az sphere image add --resource-group MyResourceGroup --catalog MyCatalog --image-path MyImage.imagepackage --regional-data-boundary EU
"""

helps[
    "sphere device"
] = """
type: group
short-summary: Manage Azure Sphere devices.
examples:
    - name: Claim a device using resource group, catalog name, and device ID.
      text: az sphere device claim --resource-group MyResourceGroup --catalog MyCatalog --device <DeviceIdValue>
    - name: List all devices in a resource group and catalog.
      text: az sphere device list --resource-group MyResourceGroup --catalog MyCatalog
    - name: List all devices in a resource group, catalog, and product.
      text: az sphere device list --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct
    - name: List all devices in a resource group, catalog, product, and device group.
      text: az sphere device list --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --device-group MyDeviceGroup
    - name: Show details of a device using resource group, catalog name, product, device group, and device ID.
      text: az sphere device show --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --device-group MyDeviceGroup --device <DeviceIdValue>
    - name: Recover an attached device with specific capability and images.
      text: az sphere device recover --capability myCapability.cap --images myImagesFolder
    - name: List all the attached devices.
      text: az sphere device list-attached
    - name: Show details of the attached device.
      text: az sphere device show-attached      
    - name: Show the number of attached devices.
      text: az sphere device rescan-attached
    - name: Restart the attached device.
      text: az sphere device restart
    - name: Enable a device for development by enabling sideloading and debugging using resource group, catalog name, device ID, and default "Development" device group.
      text: az sphere device enable-development --resource-group MyResourceGroup --catalog MyCatalog --device <DeviceIdValue>
    - name: Enable a device for testing cloud using resource group, catalog name, device ID, and default "Field Test" device group.
      text: az sphere device enable-cloud-test --resource-group MyResourceGroup --catalog MyCatalog --device <DeviceIdValue>
"""

helps[
    "sphere device rescan-attached"
] = """
type: command
short-summary: Show the number of attached devices.
examples:
    - name: Show the number of attached devices.
      text: az sphere device rescan-attached
"""

helps[
    "sphere device list-attached"
] = """
type: command
short-summary: List all the attached devices.
examples:
    - name: List all the attached devices.
      text: az sphere device list-attached
"""

helps[
    "sphere device show-attached"
] = """
type: command
short-summary: Show the details of the attached device.
parameters:
    - name: "--device -d"
      short-summary: "The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device."
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Show details of the attached device.
      text: az sphere device show-attached
    - name: Show details of the specified device.
      text: az sphere device show-attached --device <DeviceIdValue>
"""

helps[
    "sphere device list"
] = """
type: command
short-summary: List all the devices in your catalog, product, or device group.
parameters:
    - name: "--product -p"
      short-summary: The product name.
      populator-commands:
        - az sphere product list
    - name: "--device-group -dg"
      short-summary: The device group name.
      populator-commands:
        - az sphere device-group list
examples:
    - name: List all devices in a resource group and catalog.
      text: az sphere device list --resource-group MyResourceGroup --catalog MyCatalog
    - name: List all devices in a resource group, catalog, and product.
      text: az sphere device list --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct
    - name: List all devices in a resource group, catalog, product, and device group.
      text: az sphere device list --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --device-group MyDeviceGroup

"""

helps[
    "sphere device show-count"
] = """
type: command
short-summary: Show the number of devices in your catalog, product, or device group.
parameters:
    - name: "--product -p"
      short-summary: The product name.
      populator-commands:
        - az sphere product list
    - name: "--device-group -dg"
      short-summary: The device group name.
      populator-commands:
        - az sphere device-group list
examples:
    - name: Show the number of devices in a resource group and catalog.
      text: az sphere device show-count --resource-group MyResourceGroup --catalog MyCatalog
    - name: Show the number of devices in a resource group, catalog, and product.
      text: az sphere device show-count --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct
    - name: Show the number of devices in a resource group, catalog, product, and device group.
      text: az sphere device show-count --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --device-group MyDeviceGroup

"""

helps[
    "sphere device show"
] = """
type: command
short-summary: Show details of an existing device in your resource group and catalog.
parameters:
    - name: "--product -p"
      short-summary: The product name.
      populator-commands:
        - az sphere product list
    - name: "--device-group -dg"
      short-summary: The device group name.
      populator-commands:
        - az sphere device-group list
    - name: "--device -d"
      short-summary: "The device to target for this command. This is required when no device or multiple devices are attached, to disambiguate which device to target. If the device is attached, you may provide either device ID, IP address, or Local Connection ID. Otherwise you must provide the device ID only."
      populator-commands:
        - az sphere device list
examples:
    - name: Show details of a device using resource group, catalog name, product, device group, and device ID.
      text: az sphere device show --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --device-group MyDeviceGroup --device <DeviceIdValue>
"""

helps[
    "sphere device assign"
] = """
type: command
short-summary: Assign a device to a device group in your resource group and catalog.
parameters:
    - name: "--device -d"
      short-summary: "The device to target for this command. This is required when no device or multiple devices are attached, to disambiguate which device to target. If the device is attached, you may provide either device ID, IP address, or Local Connection ID. Otherwise you must provide the device ID only."
      populator-commands:
        - az sphere device list
    - name: "--target-product"
      short-summary: The name of the target product.
      populator-commands:
        - az sphere product list
    - name: "--target-device-group"
      short-summary: The name of the target device group.
      populator-commands: 
        - az sphere device-group list
examples:
    - name: Assign a device using resource group, catalog name, target product name, target device group name, and device ID. 
      text: az sphere device assign --resource-group MyResourceGroup --catalog MyCatalog --target-product MyProduct --target-device-group MyCurrentDeviceGroup --device <DeviceIdValue>
"""

helps[
    "sphere device unassign"
] = """
type: command
short-summary: Unassign a device from a device group in your resource group and catalog.
parameters:
    - name: "--device -d"
      short-summary: "The device to target for this command. This is required when no device or multiple devices are attached, to disambiguate which device to target. If the device is attached, you may provide either device ID, IP address, or Local Connection ID. Otherwise you must provide the device ID only."
      populator-commands:
        - az sphere device list
    - name: "--product -p"
      short-summary: The product name.
      populator-commands:
        - az sphere product list
    - name: "--device-group -dg"
      short-summary: The device group name.
      populator-commands: 
        - az sphere device-group list
examples:
    - name: Unassign a device using resource group, catalog name, product name, device group name, and device ID.
      text: az sphere device unassign --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --device-group MyDeviceGroup --device <DeviceIdValue>
"""

helps[
    "sphere device restart"
] = """
type: command
short-summary: Restart the attached device.
parameters:
    - name: "--device -d"
      short-summary: "The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device."
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Restart the attached device.
      text: az sphere device restart
    - name: Restart a specified device.
      text: az sphere device restart --device <DeviceIdValue>
"""

helps[
    "sphere device claim"
] = """
type: command
short-summary: Claim a device in your resource group and catalog.
parameters:
    - name: "--device -d"
      short-summary: "The device to target for this command. This is required when no device or multiple devices are attached, to disambiguate which device to target. If the device is attached, you may provide either device ID, IP address, or Local Connection ID. Otherwise you must provide the device ID only."
      populator-commands:
        - az sphere device list
    - name: "--product -p"
      short-summary: The product name where to claim the device.
      populator-commands:
        - az sphere product list
    - name: "--device-group -dg"
      short-summary: The device group name where to claim the device.
      populator-commands: 
        - az sphere device-group list
examples:
    - name: Claim a device using resource group, catalog name, and device ID.
      text: az sphere device claim --resource-group MyResourceGroup --catalog MyCatalog --device <DeviceIdValue>
    - name: Claim a device using resource group, catalog name, product name, device group name, and device ID.
      text: az sphere device claim --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --device-group MyDeviceGroup --device <DeviceIdValue>
"""

helps[
    "sphere device recover"
] = """
type: command
short-summary: Use recovery mode to load new firmware onto the attached device.
parameters:
    - name: "--device -d"
      short-summary: "The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device."
      populator-commands:
        - az sphere device list-attached
    - name: "--capability"
      short-summary: "Filename of a device capability image to apply to the device during recovery. (Path)."
    - name: "--images"
      short-summary: "Folder containing the image packages to write to the device. If not specified then the latest OS images are downloaded and used. (Path)."
examples:
    - name: Recover an attached device.
      text: az sphere device recover
    - name: Recover an attached device with specific capability and images.
      text: az sphere device recover --capability myCapability.cap --images myImagesFolder
"""

helps[
    "sphere device show-os-version"
] = """
type: command
short-summary: Show the operating system version on the attached device.
parameters:
    - name: "--device -d"
      short-summary: "The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device."
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Show the operating system version on the attached device.
      text: az sphere device show-os-version
    - name: Show the operation system version on a specified device.
      text: az sphere device show-os-version --device <DeviceIdValue>
"""

helps[
    "sphere device show-deployment-status"
] = """
type: command
short-summary: Show the deployment status of the operating system on a device.
parameters:
    - name: "--device -d"
      short-summary: "The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device."
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Show the deployment status of the operation system using resource group, catalog name, and device ID.
      text: az sphere device show-deployment-status --resource-group MyResourceGroup --catalog MyCatalog --device <DeviceIdValue>
"""

helps[
    "sphere device enable-development"
] = """
type: command
short-summary: "Enable a device for development by enabling sideloading and debugging on the attached device, and by assigning it to a device group that disables application updates from the cloud. By default, this will be the Development device group of the device's product, but other device groups can be specified. Not for use in manufacturing scenarios: see https://aka.ms/AzureSphereManufacturing for more information."
parameters:
    - name: "--device -d"
      short-summary: "The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device."
      populator-commands:
        - az sphere device list-attached
    - name: "--enable-rt-core-debugging -r"
      short-summary: "Install drivers required to debug applications running on a real-time core. Requires administrator permissions."
    - name: "--product -p"
      short-summary: The target product name. The device will be assigned to the default "Development" device group of the selected product unless the device-group is also specified.
      populator-commands:
        - az sphere product list
    - name: "--device-group -dg"
      short-summary: The device group name to which the device will be assigned. By default, this is the "Development" device group of the product.
      populator-commands:
        - az sphere device-group list
examples:
    - name: Enable a device for development by enabling sideloading and debugging using resource group, catalog name, device ID, and default "Development" device group.
      text: az sphere device enable-development --resource-group MyResourceGroup --catalog MyCatalog --device <DeviceIdValue>
    - name: Enable a device for development by enabling sideloading and debugging using resource group, catalog name, product name, device group name, and device ID.
      text: az sphere device enable-development --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --device-group MyDeviceGroup --device <DeviceIdValue>
"""

helps[
    "sphere device enable-cloud-test"
] = """
type: command
short-summary: "Enable a device for testing cloud loading by disabling development and debugging on the attached device, and by assigning it to a device group that enables application updates from the cloud. By default, this will be the Field Test device group of the device's product, but other device groups can be specified. Not for use in manufacturing scenarios: see https://aka.ms/AzureSphereManufacturing for more information."
parameters:
    - name: "--device -d"
      short-summary: "The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device."
      populator-commands:
        - az sphere device list-attached
    - name: "--product -p"
      short-summary: The target product name. The device will be assigned to the default "Field Test" device group of the selected product unless the device-group is also specified.
      populator-commands:
        - az sphere product list
    - name: "--device-group -dg"
      short-summary: The device group name to which the device will be assigned. By default, this is the "Field Test" device group of the product.
      populator-commands:
        - az sphere device-group list
examples:
    - name: Enable a device for testing cloud using resource group, catalog name, device ID, and default "Field Test" device group.
      text: az sphere device enable-cloud-test --resource-group MyResourceGroup --catalog MyCatalog --device <DeviceIdValue>
    - name: Enable a device for testing cloud using resource group, catalog name, product name, device group name, and device ID.
      text: az sphere device enable-cloud-test --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --device-group MyDeviceGroup --device <DeviceIdValue>
"""

helps[
    "sphere device app"
] = """
type: group
short-summary: Manage applications on the attached device.
examples:
    - name: Show the status of applications on the attached device.
      text: az sphere device app show-status
    - name: Show the storage quota and usage for applications on the attached device.
      text: az sphere device app show-quota
    - name: Show the memory statistics for applications on the attached device.
      text: az sphere device app show-memory-stats
    - name: Start applications on the attached device.
      text: az sphere device app start
    - name: Stop applications on the attached device.
      text: az sphere device app stop
"""

helps[
    "sphere device app show-status"
] = """
type: command
short-summary: Show the status of applications on the attached device.
parameters:
    - name: "--component-id -i"
      short-summary: "The component ID to show the status of; by default, all application statuses are shown. (GUID)."
    - name: "--device -d"
      short-summary: "The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device."
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Show the status of applications on the attached device.
      text: az sphere device app show-status
    - name: Show the status of a specific application on the attached device.
      text: az sphere device app show-status --component-id 4d46953f-51d4-43d3-83a2-a808dc36cc53
    - name: Show the status of applications on the specified device.
      text: az sphere device app show-status --device <DeviceIdValue>
"""

helps[
    "sphere device app show-quota"
] = """
type: command
short-summary: Show the storage quota and usage for applications on the attached device.
parameters:
    - name: "--component-id -i"
      short-summary: "The component ID to get the quota information for. By default, gets all components. (GUID)."
      populator-commands:
        - az sphere device app show-status
    - name: "--device -d"
      short-summary: "The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device."
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Show the storage quota and usage for applications on the attached device.
      text: az sphere device app show-quota
    - name: Show the storage quota of a specific application on the attached device.
      text: az sphere device app show-quota --component-id 4d46953f-51d4-43d3-83a2-a808dc36cc53
    - name: Show the storage quota and usage for applications on the specified device.
      text: az sphere device app show-quota --device <DeviceIdValue>
"""

helps[
    "sphere device app show-memory-stats"
] = """
type: command
short-summary: Show the memory statistics for applications on the attached device.
parameters:
    - name: "--device -d"
      short-summary: "The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device."
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Show the memory statistics for applications on the attached device.
      text: az sphere device app show-memory-stats
    - name: Show the memory statistics for applications on the specified device.
      text: az sphere device app show-memory-stats --device <DeviceIdValue>
"""

helps[
    "sphere device app start"
] = """
type: command
short-summary: Start applications on the attached device.
parameters:
    - name: "--component-id -i"
      short-summary: "The component ID of the application to start. By default, all applications are started. Required if '--debug-mode' is used. (GUID)."
      populator-commands:
        - az sphere device app show-status
    - name: "--debug-mode"
      short-summary: "Start the application in debug mode. '--component-id' must be provided."
    - name: "--device -d"
      short-summary: "The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device."
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Start applications on the attached device.
      text: az sphere device app start
    - name: Start a specific application on the attached device.
      text: az sphere device app start --component-id 4d46953f-51d4-43d3-83a2-a808dc36cc53      
    - name: Start applications on the specified device.
      text: az sphere device app start --device <DeviceIdValue>
"""

helps[
    "sphere device app stop"
] = """
type: command
short-summary: Stop applications on the attached device.
parameters:
    - name: "--component-id -i"
      short-summary: "The component ID to stop; by default, all applications are stopped. (GUID)."
      populator-commands:
        - az sphere device app show-status
    - name: "--device -d"
      short-summary: "The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device."
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Stop applications on the attached device.
      text: az sphere device app stop
    - name: Stop a specific application on the attached device.
      text: az sphere device app stop --component-id 4d46953f-51d4-43d3-83a2-a808dc36cc53
    - name: Stop applications on the specified device.
      text: az sphere device app stop --device <DeviceIdValue>
"""

helps[
    "sphere device capability"
] = """
type: group
short-summary: Manage device capability configurations.
examples:
    - name: Download capability "ApplicationDevelopment" for a device using resource group, catalog name, device ID, and capability.
      text: az sphere device capability download --resource-group MyResourceGroup --catalog MyCatalog --device <DeviceIdValue> --type ApplicationDevelopment --output-file myCapabilities.cap
    - name: Update the device capability configuration for the attached device.
      text: az sphere device capability update --capability-file myCapabilities.cap
    - name: Select temporarily the device capability session.
      text: az sphere device capability select --capability-file myCapabilities.cap
    - name: Show the device capability configuration of the attached device.
      text: az sphere device capability show-attached
"""

helps[
    "sphere device capability download"
] = """
type: command
short-summary: Download a device capability file from the Azure Sphere Security Service.
parameters:
    - name: "--product -p"
      short-summary: The product name.
      populator-commands:
        - az sphere product list
    - name: "--device-group -dg"
      short-summary: The device group name.
      populator-commands:
        - az sphere device-group list
    - name: "--device -d"
      short-summary: "The device to target for this command. This is required when no device or multiple devices are attached, to disambiguate which device to target. If the device is attached, you may provide either device ID, IP address, or Local Connection ID. Otherwise you must provide the device ID only."
      populator-commands:
        - az sphere device list
    - name: "--type -t"
      short-summary: "Space-separated list of capabilities to download. If this parameter is not set, the capability `None` will be applied."
    - name: "--output-file -of"
      short-summary:  "Path and file name in which to download capabilities. If this parameter is not set, the file will be saved in the current folder with a default name (capability-device.cap)."
examples:
    - name: Download capability "ApplicationDevelopment" for a device using resource group, catalog name, device ID, and capability.
      text: az sphere device capability download --resource-group MyResourceGroup --catalog MyCatalog --device <DeviceIdValue> --type ApplicationDevelopment --output-file myCapabilities.cap
    - name: Download no capability for a device using resource group, catalog name, device ID, and capability.
      text: az sphere device capability download --resource-group MyResourceGroup --catalog MyCatalog --device <DeviceIdValue> --output-file myCapabilities.cap
"""

helps[
    "sphere device capability update"
] = """
type: command
short-summary: Update the device capability configuration for the attached device.
parameters:
    - name: "--device -d"
      short-summary: "The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device."
      populator-commands:
        - az sphere device list-attached
    - name: "--capability-file"
      short-summary: "The path and filename to the device capability configuration file to apply."
examples:
    - name: Update the device capability configuration for the attached device.
      text: az sphere device capability update --capability-file myCapabilities.cap
    - name: Update the device capability configuration for the specified device.
      text: az sphere device capability update --capability-file myCapabilities.cap --device <DeviceIdValue> 
"""

helps[
    "sphere device capability select"
] = """
type: command
short-summary: Temporarily select the device capability session for the attached device.
parameters:
    - name: "--device -d"
      short-summary: "The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device."
      populator-commands:
        - az sphere device list-attached
    - name: "--capability-file"
      short-summary: "The path and filename to the device capability configuration file to select. You can provide a relative or absolute path."
    - name: "--none -n"
      short-summary: "End the temporarily selected device capability session."
examples:
    - name: Select temporarily the device capability session.
      text: az sphere device capability select --capability-file myCapabilities.cap
    - name: End the temporarily selected device capability session.
      text: az sphere device capability select --none
"""

helps[
    "sphere device capability show-attached"
] = """
type: command
short-summary: Show the current device capability configuration of the attached device.
parameters:
    - name: "--device -d"
      short-summary: "The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device."
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Show the device capability configuration of the attached device.
      text: az sphere device capability show-attached
    - name: Show the device capability configuration of the specified device.
      text: az sphere device capability show-attached --device <DeviceIdValue> 
"""


helps[
    "sphere device certificate"
] = """
type: group
short-summary: Manage certificates on the attached device.
examples:
    - name: Add a rootca certificate on the attached device.
      text: az sphere device certificate add --certificate certSample --cert-type rootca --public-key-file pubcert.pem
    - name: Add a client certificate on the attached device.
      text: az sphere device certificate add --certificate certSample --cert-type client --public-key-file pubcert.pem --private-key-file privkeycert.pem --private-key-password 1234
    - name: Delete a certificate on the attached device.
      text: az sphere device certificate delete --certificate certSample
    - name: Show details of a certificate on the attached device.
      text: az sphere device certificate show --certificate certSample      
    - name: List certificates on the attached device.
      text: az sphere device certificate list
    - name: Show the available free space in the attached device's certificate store.
      text: az sphere device certificate show-quota
"""

helps[
    "sphere device certificate add"
] = """
type: command
short-summary: Add a certificate in the attached device's certificate store.
parameters:
    - name: "--device -d"
      short-summary: "The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device."
      populator-commands:
        - az sphere device list-attached
    - name: "--certificate -c"
      short-summary: "The name of the certificate to add."
    - name: "--cert-type -t"
      short-summary: 'The type of certificate to add. "rootca" - a root CA certificate for use with EAP-TLS networks where the device authenticates the server. "client" - a client certificate, containing both the public and private key, for use with EAP-TLS networks. Please see: https://aka.ms/AzureSphereCertificateStore for more details.'
    - name: "--public-key-file -p"
      short-summary: "The path to a public key certificate .pem file. You can provide a relative or absolute path."
    - name: "--private-key-file"
      short-summary: 'The path to a client private key .pem file. Required when adding a certificate of type "client". You can provide a relative or absolute path.'
    - name: "--private-key-password -w"
      short-summary: "Password for the client private key. Required when adding a client private key that is encrypted." 
examples:
    - name: Add a rootca certificate on the attached device.
      text: az sphere device certificate add --certificate certSample --cert-type rootca --public-key-file pubcert.pem
    - name: Add a client certificate on the attached device.
      text: az sphere device certificate add --certificate certSample --cert-type client --public-key-file pubcert.pem --private-key-file privkeycert.pem --private-key-password 1234
"""

helps[
    "sphere device certificate delete"
] = """
type: command
short-summary: Delete a certificate in the attached device's certificate store.
parameters:
    - name: "--device -d"
      short-summary: "The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device."
      populator-commands:
        - az sphere device list-attached
    - name: "--certificate -c"
      short-summary: "The name of the certificate to delete."
      populator-commands:
      - az sphere device certificate list
examples:
    - name: Delete a certificate on the attached device.
      text: az sphere device certificate delete --certificate certSample
"""
helps[
    "sphere device certificate list"
] = """
type: command
short-summary: List certificates in the attached device's certificate store.
parameters:
    - name: "--device -d"
      short-summary: "The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device."
      populator-commands:
        - az sphere device list-attached
examples:
    - name: List certificates on the attached device.
      text: az sphere device certificate list
"""
helps[
    "sphere device certificate show-quota"
] = """
type: command
short-summary: Show the available free space in the attached device's certificate store.
parameters:
    - name: "--device -d"
      short-summary: "The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device."
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Show the available free space in the attached device's certificate store.
      text: az sphere device certificate show-quota
"""
helps[
    "sphere device certificate show"
] = """
type: command
short-summary: Show details of a certificate in the attached device's certificate store.
parameters:
    - name: "--device -d"
      short-summary: "The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device."
      populator-commands:
        - az sphere device list-attached
    - name: "--certificate -c"
      short-summary: "The certificate name of the certificate for which to show the details."
      populator-commands:
      - az sphere device certificate list
examples:
    - name: Show details of a certificate on the attached device.
      text: az sphere device certificate show --certificate certSample
"""

helps[
    "sphere device image"
] = """
type: group
short-summary: Manage images in your catalog and the attached device.
examples:
    - name: List only applications installed on the attached device.
      text: az sphere device image list-installed
    - name: List all images installed on the attached device.
      text: az sphere device image list-installed --all
    - name: List only applications uploaded to a resource group, catalog, and device.
      text: az sphere image list-targeted --resource-group MyResourceGroup --catalog MyCatalog --device <DeviceIdValue> 
"""

helps[
    "sphere device image list-installed"
] = """
type: command
short-summary: List the images installed on the attached device. By default, lists only applications.
parameters:
    - name: "--device -d"
      short-summary: "The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device."
      populator-commands:
        - az sphere device list-attached
    - name: "--all"
      short-summary: "Lists all images on the device; rather than only applications."
examples:
    - name: List only applications installed on the attached device.
      text: az sphere device image list-installed
    - name: List all images installed on the attached device.
      text: az sphere device image list-installed --all
"""

helps[
    "sphere device image list-targeted"
] = """
type: command
short-summary: List images in your catalog. By default, lists only images that will be installed when the device is updated.
parameters:
    - name: "--device -d"
      short-summary: "The device to target for this command. This is required when no device or multiple devices are attached, to disambiguate which device to target. If the device is attached, you may provide either device ID, IP address, or Local Connection ID. Otherwise you must provide the device ID only."
      populator-commands:
        - az sphere device list      
    - name: "--all"
      short-summary: List all images in your resource group and catalog.
examples:
    - name: List only applications uploaded to a resource group, catalog, and device.
      text: az sphere image list-targeted --resource-group MyResourceGroup --catalog MyCatalog --device <DeviceIdValue>
    - name: List all images uploaded in a resource group, catalog, and device.
      text: az sphere image list-targeted --resource-group MyResourceGroup --catalog MyCatalog --device <DeviceIdValue> --all
"""

helps[
    "sphere device manufacturing-state"
] = """
type: group
short-summary: Manage the manufacturing state of attached devices.
examples:
    - name: Show the manufacturing state on the attached device.
      text: az sphere device manufacturing-state show
    - name: Update the manufacturing state on the attached device.
      text: az sphere device manufacturing-state update --state DeviceComplete
"""

helps[
    "sphere device manufacturing-state show"
] = """
type: command
short-summary: Show the manufacturing state of the attached device.
parameters:
    - name: "--device -d"
      short-summary: "The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device."
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Show the manufacturing state on the attached device.
      text: az sphere device manufacturing-state show
    - name: Show the manufacturing state on the specified device.
      text: az sphere device manufacturing-state show --device <DeviceIdValue>
"""

helps[
    "sphere device manufacturing-state update"
] = """
type: command
short-summary: "Update the manufacturing state of the attached device. Caution: manufacturing state changes are permanent and irreversible."
parameters:
    - name: "--device -d"
      short-summary: "The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device."
      populator-commands:
        - az sphere device list-attached
    - name: "--state -s"
      short-summary: "The manufacturing state of the attached device."
examples:
    - name: Update the manufacturing state on the attached device.
      text: az sphere device manufacturing-state update --state DeviceComplete
    - name: Update the manufacturing state on the specified device.
      text: az sphere device manufacturing-state update --state DeviceComplete --device <DeviceIdValue>
"""

helps[
    "sphere device network"
] = """
type: group
short-summary: Provides information about the status of network interfaces on the attached device.
examples:
    - name: Enable the network interface
      text: az sphere device network enable --interface eth0
    - name: Disable the network interface
      text: az sphere device network disable --interface eth0
    - name: List all firewall rules
      text: az sphere device network list-firewall-rules
    - name: List interfaces on device
      text: az sphere device network list-interfaces
    - name: Show diagnostics for all networks
      text: az sphere device network show-diagnostics
    - name: Show status of network on device
      text: az sphere device network show-status
    - name: Update the hardware address value for a specific network interface
      text: az sphere device network update-interface --interface eth0 --hardware-address aa:bb:33:dd:ee:ff
"""

helps[
    "sphere device network enable"
] = """
type: command
short-summary: Enable a network interface on the attached device.
parameters:
    - name: --interface
      short-summary: The interface to enable.
      populator-commands:
        - az sphere device network list-interfaces
    - name: --device -d
      short-summary: The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device.
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Enable the network interface
      text: az sphere device network enable --interface eth0
"""

helps[
    "sphere device network disable"
] = """
type: command
short-summary: Disable a network interface on the attached device.
parameters:
    - name: --device -d
      short-summary: The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device.
      populator-commands:
        - az sphere device list-attached
    - name: --interface
      short-summary: The interface to disable.
      populator-commands:
        - az sphere device network list-interfaces
examples:
    - name: Disable the network interface
      text: az sphere device network disable --interface eth0
"""

helps[
    "sphere device network list-firewall-rules"
] = """
type: command
short-summary: List firewall rules for the attached device.
parameters:
    - name: --device -d
      short-summary: The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device.
      populator-commands:
        - az sphere device list-attached
examples:
    - name: List all firewall rules
      text: az sphere device network list-firewall-rules
"""

helps[
    "sphere device network list-interfaces"
] = """
type: command
short-summary: List the network interfaces for the attached device.
parameters:
    - name: --device -d
      short-summary: The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device.
      populator-commands:
        - az sphere device list-attached
examples:
    - name: List interfaces on the attached device
      text: az sphere device network list-interfaces
"""

helps[
    "sphere device network show-diagnostics"
] = """
type: command
short-summary: Show diagnostics for one or all Wi-Fi networks on the attached device.
parameters:
    - name: --device -d
      short-summary: The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device.
      populator-commands:
        - az sphere device list-attached
    - name: --network -n
      short-summary: The network for which to show diagnostics. 
      populator-commands: 
        - az sphere device network list-interfaces
examples:
    - name: Show diagnostics for all networks
      text: az sphere device network show-diagnostics
"""

helps[
    "sphere device network show-status"
] = """
type: command
short-summary: Show the network status for the attached device.
parameters:
    - name: --device -d
      short-summary: The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device.
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Show status of network on device
      text: az sphere device network show-status
"""

helps[
    "sphere device network update-interface"
] = """
type: command
short-summary: Update the network interface configuration for the attached device.
parameters:
    - name: --device -d
      short-summary: The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device.
      populator-commands:
        - az sphere device list-attached
    - name: --hardware-address
      short-summary: Specify the device hardware address to be set.
    - name: --interface
      short-summary: The interface to update.
      populator-commands:
        - az sphere device network list-interfaces
examples:
    - name: Update the hardware address value for a specific network interface
      text: az sphere device network update-interface --interface eth0 --hardware-address aa:bb:33:dd:ee:ff
"""

helps[
    "sphere device network proxy"
] = """
type: group
short-summary: Manage proxy address use for network connection.
examples:
    - name: Apply a Network Proxy with Basic Authentication
      text:  az sphere device network proxy apply --address contoso.com --authentication basic --port 8080
        --username ExampleUsername --password ExamplePassword --no-proxy-addresses badcontoso.com
        badcontoso2.com --enable
    - name: Apply a Network Proxy with Anonymous Authentication
      text: az sphere device network proxy apply --address contoso.com --authentication anonymous --port 8080 --enable --device 192.168.35.2
    - name: Show proxy connection on the attached device.
      text: az sphere device network proxy show --device <DeviceIdValue>
    - name: Enable network proxy on the attached device.
      text: az sphere device network proxy enable
    - name: Disable network proxy on the attached device.
      text: az sphere device network proxy disable
    - name: Delete proxy connection on the attached device.
      text: az sphere device network proxy delete
"""

helps[
    "sphere device network proxy show"
] = """
type: command
short-summary: Show proxy connection on the attached device.
parameters:
    - name: --device -d
      short-summary: The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device.
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Show proxy connection on the attached device.
      text: az sphere device network proxy show --device <DeviceIdValue>
"""

helps[
    "sphere device network proxy delete"
] = """
type: command
short-summary: Delete proxy connection on the attached device.
parameters:
    - name: --device -d
      short-summary: The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device.
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Delete proxy connection on the attached device.
      text: az sphere device network proxy delete
"""

helps[
    "sphere device network proxy apply"
] = """
type: command
short-summary: Configure the network proxy on the attached device.
parameters:
    - name: --address -a
      short-summary: The network address of the proxy.
    - name: --authentication -t
      short-summary: If the proxy requires a user name and password, set this to basic, otherwise anonymous.  Allowed values are anonymous, basic.
    - name: --port -r
      short-summary: The port on the network address to be used.
    - name: --device -d
      short-summary: The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device.
      populator-commands:
        - az sphere device list-attached
    - name: --enable
      short-summary: Enable the network proxy configuration on the attached device.
    - name: --no-proxy-addresses -n
      short-summary: Array of space-separated network addresses the device should avoid for proxy connection.
    - name: --password -p
      short-summary: For Basic Authentication, password used for proxy authentication.
    - name: --username -u
      short-summary: For Basic Authentication, username used for proxy authentication.
examples:
    - name: Apply a Network Proxy with Basic Authentication
      text:  az sphere device network proxy apply --address contoso.com --authentication basic --port 8080
        --username ExampleUsername --password ExamplePassword --no-proxy-addresses badcontoso.com
        badcontoso2.com --enable
    - name: Apply a Network Proxy with Anonymous Authentication
      text: az sphere device network proxy apply --address contoso.com --authentication anonymous --port 8080 --enable --device 192.168.35.2
"""

helps[
    "sphere device network proxy enable"
] = """
type: command
short-summary: Enable network proxy on the attached device.
parameters:
    - name: --device -d
      short-summary: The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of the device.
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Enable network proxy on the attached device.
      text: az sphere device network proxy enable
"""

helps[
    "sphere device network proxy disable"
] = """
type: command
short-summary: Disable network proxy on the attached device.
parameters:
    - name: --device -d
      short-summary: The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of the device.
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Disable network proxy on the attached device.
      text: az sphere device network proxy disable
"""

helps[
    "sphere device sideload"
] = """
type: group
short-summary: Deploy and manage applications on the attached device.
examples:
    - name: Set deployment timeout value.
      text: az sphere device sideload set-deployment-timeout --value 30
    - name: Show deployment timeout value.
      text: az sphere device sideload show-deployment-timeout
    - name: Deploy an image package to the device.
      text: az sphere device sideload deploy --image-package MyImage.imagepackage
    - name: Delete applications from the device.
      text: az sphere device sideload delete
"""

helps[
    "sphere device sideload set-deployment-timeout"
] = """
type: command
short-summary: Set deployment timeout in seconds.
parameters:
    - name: "--value -v"
      short-summary: "Timeout value in seconds."
examples:
    - name: Set deployment timeout value.
      text: az sphere device sideload set-deployment-timeout --value 30
"""

helps[
    "sphere device sideload show-deployment-timeout"
] = """
type: command
short-summary: Show deployment timeout in seconds.
parameters:
examples:
    - name: Show deployment timeout value.
      text: az sphere device sideload show-deployment-timeout
"""

helps[
    "sphere device sideload deploy"
] = """
type: command
short-summary: Deploy an application to the attached device.
parameters:
    - name: --device -d
      short-summary: The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device.
      populator-commands:
        - az sphere device list-attached
    - name: --image-package -p
      short-summary: The path and filename of the image package file to deploy. You can provide a relative or absolute path. (Path).
    - name: --force
      short-summary: Force the deployment of an image using a Beta API that may no longer be supported.
    - name: --manual-start -m
      short-summary: Do not automatically start the application after sideload.
examples:
    - name: Deploy an image package to the device.
      text: az sphere device sideload deploy --image-package MyImage.imagepackage
    - name: Deploy an image package to the device with manual start.
      text: az sphere device sideload deploy --image-package MyImage.imagepackage --manual-start
    - name: Deploy an image package to a specific device.
      text: az sphere device sideload deploy --image-package MyImage.imagepackage --device <DeviceIdValue>
"""

helps[
    "sphere device sideload delete"
] = """
type: command
short-summary: Delete applications from the attached device.
parameters:
    - name: --device -d
      short-summary: The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device.
      populator-commands:
        - az sphere device list-attached
    - name: --component-id -i
      short-summary: The component ID to delete; by default, all applications are deleted. (GUID).
      populator-commands:
        - az sphere device image list-installed
    - name: --except-component-ids -e
      short-summary: Space-separated IDs of components to exclude from the set of applications to be deleted. (GUID).
      populator-commands:
        - az sphere device image list-installed
examples:
    - name: Delete applications from the device.
      text: az sphere device sideload delete
    - name: Delete applications from a specific device.
      text: az sphere device sideload delete --device <DeviceIdValue>
    - name: Delete a specific application from the device.
      text: az sphere device sideload delete --component-id d2d461c4-b870-4619-b207-e86b8ab1481c
    - name: Delete applications except two specific applications from the device.
      text: az sphere device sideload delete --except-component-ids d2d461c4-b870-4619-b207-e86b8ab1481c 683520b6-df43-4f4f-a4de-4c7a6f2ad05d
"""


helps[
    "sphere ca-certificate"
] = """
type: group
short-summary: Manage certificates in your resource group and catalog.
examples:
    - name: List all certificates in a resource group and catalog.
      text: az sphere ca-certificate list --resource-group MyResourceGroup --catalog MyCatalog
    - name: Download an active certificate using resource group and catalog name.
      text: az sphere ca-certificate download --resource-group MyResourceGroup --catalog MyCatalog --output-file myCert.cer
    - name: Download certificate using resource group and catalog name.
      text: az sphere ca-certificate download --resource-group MyResourceGroup --catalog MyCatalog --serial-number 2E7A0AF370ABC439901BBB37AF38B97 --output-file myCert.cer
"""

helps[
    "sphere ca-certificate list"
] = """
type: command
short-summary: List all certificates in your resource group and catalog.
examples:
    - name: List all certificates in a resource group and catalog.
      text: az sphere ca-certificate list --resource-group MyResourceGroup --catalog MyCatalog
"""

helps[
    "sphere ca-certificate download"
] = """
type: command
short-summary: Download the certificate for your catalog.
parameters:
    - name: "--serial-number -sn"
      short-summary: "The certificate to download. Specify serial number."
    - name: "--output-file -of"
      short-summary: Path and file name in which to save the certificate. Specify a relative or absolute path.
examples:
    - name: Download an active certificate using resource group and catalog name.
      text: az sphere ca-certificate download --resource-group MyResourceGroup --catalog MyCatalog --output-file myCert.cer
    - name: Download certificate using resource group and catalog name.
      text: az sphere ca-certificate download --resource-group MyResourceGroup --catalog MyCatalog --serial-number 2E7A0AF370ABC439901BBB37AF38B97 --output-file myCert.cer
"""

helps[
    "sphere ca-certificate download-chain"
] = """
type: command
short-summary: Download the certificate chain for your catalog as a PKCS#7 ".p7b" file.
parameters:
    - name: "--serial-number -sn"
      short-summary: "The certificate to download. Specify serial number."
    - name: "--output-file -of"
      short-summary: Path and file name in which to save the certificate chain. Specify a relative or absolute path using a ".p7b" extension.
examples:
    - name: Download a certificate chain using resource group and catalog name.
      text: az sphere ca-certificate download-chain --resource-group MyResourceGroup --catalog MyCatalog --serial-number 2E7A0AF370ABC439901BBB37AF38B97 --output-file myCertChain.p7b
    - name: Download an active certificate chain using resource group and catalog name.
      text: az sphere ca-certificate download-chain --resource-group MyResourceGroup --catalog MyCatalog --output-file myCertChain.p7b

"""

helps[
    "sphere ca-certificate download-proof"
] = """
type: command
short-summary: Download a proof-of-possession certificate for your catalog for use with a provided code.
parameters:
    - name: "--serial-number -sn"
      short-summary: "The certificate to download. Specify serial number."
    - name: "--verification-code -v"
      short-summary: "The verification code for the Azure Sphere Security Service to use when generating the certificate."
    - name: "--output-file -of"
      short-summary: Path and file name in which to save the certificate. Specify a relative or absolute path.
examples:
    - name: Download a proof-of-possession certificate using resource group and catalog name.
      text: az sphere ca-certificate download-proof --resource-group MyResourceGroup --catalog MyCatalog --serial-number 2E7A0AF370ABC439901BBB37AF38B97 --verification-code 3304517c557a3375e --output-file myCert.cer
    - name: Download an active proof-of-possession certificate using resource group and catalog name.
      text: az sphere ca-certificate download-proof --resource-group MyResourceGroup --catalog MyCatalog --verification-code 3304517c557a3375e --output-file myCert.cer

"""

helps[
    "sphere deployment"
] = """
type: group
short-summary: Manage deployments in your resource group and catalog.
examples:
    - name: Create a new deployment with image in resource group "MyResourceGroup", catalog "MyCatalog', product "MyProduct", and device group "MyDeviceGroup".
      text: az sphere deployment create --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --device-group MyDeviceGroup --images 25b91eed-1996-4049-ab9f-70982b87ad58
    - name: Create a new deployment with images in resource group "MyResourceGroup", catalog "MyCatalog', product "MyProduct", and device group "MyDeviceGroup".
      text: az sphere deployment create --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --device-group MyDeviceGroup --images 25b91eed-1996-4049-ab9f-70982b87ad58 48ecb7b3-c296-49cb-8dec-5fdaea0abb62
    - name: List all deployments in a resource group, catalog, product, and device group.
      text: az sphere deployment list --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --device-group MyDeviceGroup
    - name: Show details of a deployment using resource group, catalog name, and deployment ID.
      text: az sphere deployment show --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --device-group MyDeviceGroup --deployment-id 5422a862-cfc7-4cb8-a2d7-7ba71873b7b6
"""

helps[
    "sphere deployment show"
] = """
type: command
short-summary: Show details of a deployment.
parameters:
    - name: "--deployment-id -di"
      short-summary: "The deployment ID."
    - name: "--product -p"
      short-summary: The product in which to list deployments.
      populator-commands:
        - az sphere product list
    - name: "--device-group -dg"
      short-summary: The device group name.
      populator-commands:
        - az sphere device-group list
examples:
    - name: Show details of a deployment using resource group, catalog name, and deployment ID.
      text: az sphere deployment show --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --device-group MyDeviceGroup --deployment-id 5422a862-cfc7-4cb8-a2d7-7ba71873b7b6
"""

helps[
    "sphere deployment list"
] = """
type: command
short-summary: List all deployments.
parameters:
    - name: "--product -p"
      short-summary: The product in which to list deployments.
      populator-commands:
        - az sphere product list
    - name: "--device-group -dg"
      short-summary: The device group name.
      populator-commands:
        - az sphere device-group list
examples:
    - name: List all deployments in a resource group, catalog, product, and device group.
      text: az sphere deployment list --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --device-group MyDeviceGroup
"""

helps[
    "sphere deployment create"
] = """
type: command
short-summary: Create a deployment.
parameters:
    - name: "--product -p"
      short-summary: The product in which to create a deployment.
      populator-commands:
        - az sphere product list
    - name: "--device-group -dg"
      short-summary: The device group name.
      populator-commands:
        - az sphere device-group list
    - name: "--images -i"
      short-summary: Space-separated list of images to deploy.
      populator-commands: 
        - az sphere image list
examples:
    - name: Create a new deployment with image in resource group "MyResourceGroup", catalog "MyCatalog", product "MyProduct", and device group "MyDeviceGroup".
      text: az sphere deployment create --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --device-group MyDeviceGroup --images 25b91eed-1996-4049-ab9f-70982b87ad58
    - name: Create a new deployment with images in resource group "MyResourceGroup", catalog "MyCatalog", product "MyProduct", and device group "MyDeviceGroup".
      text: az sphere deployment create --resource-group MyResourceGroup --catalog MyCatalog --product MyProduct --device-group MyDeviceGroup --images 25b91eed-1996-4049-ab9f-70982b87ad58 48ecb7b3-c296-49cb-8dec-5fdaea0abb62
"""


helps[
    "sphere device wifi"
] = """
type: group
short-summary: Manage Wi-Fi configurations for the attached device.
examples:
    - name: Add open Wi-Fi network
      text: az sphere device wifi add --ssid
    - name: Disable configured Wi-Fi network
      text: az sphere device wifi disable --id 1
    - name: Enable configured Wi-Fi network
      text: az sphere device wifi enable --id 1
    - name: Forget configured Wi-Fi network
      text: az sphere device wifi forget --id 1
    - name: List configured Wi-Fi network
      text: az sphere device wifi list
    - name: Reload configured Wi-Fi network
      text: az sphere device wifi reload-config
    - name: Scan for Wi-Fi networks
      text: az sphere device wifi scan
    - name: Show details of a configured Wi-Fi network
      text: az sphere device wifi show
    - name: Show status of configured Wi-Fi network
      text: az sphere device wifi show-status
"""

helps[
    "sphere device wifi add"
] = """
type: command
short-summary:  Add a Wi-Fi network on the attached device.
parameters:
    - name: "--ssid -s"
      short-summary: The SSID of the network to connect to.
    - name: "--client-cert-id"
      short-summary: "[EAP-TLS] - A string value (up to 16 characters) that identifies the client certificate (containing both the public and private key). Required to set up an EAP-TLS network."
    - name: "--client-id"
      short-summary:  <user@domain> [EAP-TLS] ID recognized for authentication by this network's RADIUS server. Required for some EAP-TLS networks.
    - name: "--config-name"
      short-summary: A string value (up to 16 characters) that specifies the name for this network configuration.
    - name: "--device -d"
      short-summary: The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device.
      populator-commands:
        - az sphere device list-attached
    - name: "--root-ca-cert-id"
      short-summary: "[EAP-TLS] - A string value (up to 16 characters) that identifies the server's root CA certificate for EAP-TLS networks where the device authenticates the server."
    - name: targeted-scan
      short-summary: Attempt to connect to an SSID even if not advertised.
    - name: "--psk -p"
      short-summary: The WPA/WPA2 PSK for the new network. Do not set this if connecting to an open network.
    - name: "--targeted-scan"
      short-summary: Attempt to connect to an SSID even if not advertised
examples:
    - name: Add open Wi-Fi network
      text: az sphere device wifi add --ssid 
    - name: Add a WPA/WPA2 PSK-protected Wi-Fi network
      text: az sphere device wifi add --ssid NETWORK1 --psk EXAMPLEPSK
    - name: Add an EAP-TLS Wi-Fi network
      text: az sphere device wifi add --ssid myEapTlsSsid --client-cert-id myClientCert --client-id user@domain.com --root-ca-cert-id myRootCA --config-name Network1
"""

helps[
    "sphere device wifi disable"
] = """
type: command
short-summary: Disable a Wi-Fi connection on the attached device.
parameters:
    - name: --id -i
      short-summary: The ID of the network to disable.
    - name: --device -d
      short-summary: The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device.
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Disable configured Wi-Fi network
      text: az sphere device wifi disable --id 1
"""

helps[
    "sphere device wifi enable"
] = """
type: command
short-summary: Enable a Wi-Fi network on the attached device.
parameters:
    - name: --id -i
      short-summary: The ID of the network to enable.
    - name: --device -d
      short-summary: The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device.
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Enable configured Wi-Fi network
      text: az sphere device wifi enable --id 1
"""

helps[
    "sphere device wifi forget"
] = """
type: command
short-summary:  Forget a Wi-Fi network on the attached device.
parameters:
    - name: --id -i
      short-summary: The ID of the network to forget.
    - name: --device -d
      short-summary: The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device.
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Forget configured Wi-Fi network
      text: az sphere device wifi forget --id 1
"""

helps[
    "sphere device wifi list"
] = """
type: command
short-summary: List the current Wi-Fi configurations for the attached device.
parameters:
    - name: --device -d
      short-summary: The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device.
      populator-commands:
        - az sphere device list-attached
examples:
    - name: List configured Wi-Fi network
      text: az sphere device wifi list
"""

helps[
    "sphere device wifi reload-config"
] = """
type: command
short-summary: Reload the Wi-Fi network configuration on the attached device. Use this command after you add or remove a certificate (azsphere device certificate) to ensure that EAP-TLS networks use the most recent contents of the certificate store.
parameters:
    - name: --device -d
      short-summary: The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device.
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Reload configured Wi-Fi network
      text: az sphere device wifi reload-config
"""

helps[
    "sphere device wifi scan"
] = """
type: command
short-summary: Scan for available Wi-Fi networks visible to the attached device.
parameters:
    - name: --device -d
      short-summary: The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device.
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Scan for Wi-Fi networks
      text: az sphere device wifi scan
"""

helps[
    "sphere device wifi show"
] = """
type: command
short-summary:  Show details of a Wi-Fi network on the attached device.
parameters:
    - name: --id -i
      short-summary: The ID of the network to show details for.
    - name: --device -d
      short-summary: The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device.
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Show details of a configured Wi-Fi network
      text: az sphere device wifi show
"""

helps[
    "sphere device wifi show-status"
] = """
type: command
short-summary: Show the status of the wireless interface on the attached device.
parameters:
    - name: --device -d
      short-summary: The device to run the command on when multiple devices are attached. Specify the ID, IP address, or Local Connection ID of an attached device.
      populator-commands:
        - az sphere device list-attached
examples:
    - name: Show status of configured Wi-Fi network
      text: az sphere device wifi show-status
"""

helps[
    "sphere hardware-definition"
] = """
type: group
short-summary: Manage hardware definitions.
examples:
    - name: Generate a C header file corresponding to a hardware definition
      text: az sphere hardware-definition generate-header --hardware-definition-file mt3620.json
    - name: Test that the C header file is up-to-date with respect to the input JSON
      text: az sphere hardware-definition test-header --hardware-definition-file mt3620.json 
"""

helps[
    "sphere hardware-definition generate-header"
] = """
type: command
short-summary: Generate a C header file corresponding to a hardware definition and place it in the folder 'inc/hw' relative to the input JSON.
parameters:
    - name: --hardware-definition-file
      short-summary: "Path to a hardware definition JSON file. (Path)"
examples:
    - name: Generate a C header file corresponding to a hardware definition
      text: az sphere hardware-definition generate-header --hardware-definition-file mt3620.json
"""

helps[
    "sphere hardware-definition test-header"
] = """
type: command
short-summary: Test that the C header file in the 'inc/hw' folder is up-to-date with respect to the input JSON.
parameters:
    - name: --hardware-definition-file
      short-summary: "Path to a hardware definition JSON file. You can provide a relative or absolute path. (Path)"
examples:
    - name: Test a C header file
      text: az sphere hardware-definition test-header --hardware-definition-file mt3620.json 
"""
