"""This module provides the deployment commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._client_factory import cf_deployment
from azext_azure_sphere._exception_handler import cloud_exception_handler
from azext_azure_sphere.deployment.validators import (
    deployment_id_validator,
    deployment_images_validator,
)
from azure.cli.core.commands import CliCommandType


def load_deployment_command_table(self, _):
    """List of the deployment commands and their configurations."""
    deployment_sdk = CliCommandType(
        operations_tmpl="azext_azure_sphere.sdk.asrm.azure.mgmt.azuresphere.operations#DeploymentsOperations.{}",  # pylint: disable=line-too-long
        client_factory=cf_deployment,
        exception_handler=cloud_exception_handler,
    )

    deployment_custom_type = CliCommandType(
        operations_tmpl="azext_azure_sphere.deployment.custom#{}",
        exception_handler=cloud_exception_handler,
    )

    with self.command_group(
        "sphere deployment",
        command_type=deployment_sdk,
        custom_command_type=deployment_custom_type,
    ) as ctx:
        ctx.show_command("show", "get", validator=deployment_id_validator)
        ctx.command("list", "list_by_device_group")
        ctx.custom_command(
            "create",
            "create_deployment",
            validator=deployment_images_validator,
        )
