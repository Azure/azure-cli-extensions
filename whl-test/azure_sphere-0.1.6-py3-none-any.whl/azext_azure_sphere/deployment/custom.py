"""This module provides the implementation of custom deployment commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._client_factory import cf_deployment
from azext_azure_sphere.helpers.utils import DEFAULT_VALUE
from azext_azure_sphere.sdk.asrm.azure.mgmt.azuresphere.models._models import Deployment, Image
from azure.cli.core.commands import AzCliCommand
from knack.log import get_logger

logger = get_logger(__name__)


def create_deployment(
    cmd: AzCliCommand,
    resource_group_name: str,
    catalog_name: str,
    product_name: str,
    device_group_name: str,
    image_identifiers: str,
):
    """Deploy images in a device group in your Product (deployment create)."""
    parameters = Deployment()
    parameters.deployed_images = []

    for image_id in image_identifiers:
        image_details = Image()
        image_details.image = image_id
        parameters.deployed_images.append(image_details)

    deployment_client = cf_deployment(cmd.cli_ctx)
    return deployment_client.begin_create_or_update(
        resource_group_name,
        catalog_name,
        product_name,
        device_group_name,
        DEFAULT_VALUE,
        resource=parameters,
    )
