"""This module provides the deployment commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere.devicegroup.params import DG_NAME_PARAM_LONG_NAME, DG_NAME_PARAM_SHORT_NAME
from azext_azure_sphere.product.params import (
    PRODUCT_NAME_PARAM_LONG_NAME,
    PRODUCT_NAME_PARAM_SHORT_NAME,
)

DEPLOYMENT_NAME_PARAM_LONG_NAME = "--deployment-id"
DEPLOYMENT_NAME_PARAM_SHORT_NAME = "-di"

DG_IMAGES_LONG_NAME = "--images"
DG_IMAGES_SHORT_NAME = "-i"


def load_deployment_arguments(self, _):
    """Load arguments for deployment related commands."""
    with self.argument_context("sphere deployment") as ctx:
        ctx.argument(
            "product_name",
            type=str,
            options_list=[PRODUCT_NAME_PARAM_LONG_NAME, PRODUCT_NAME_PARAM_SHORT_NAME],
            required=True,
        )
        ctx.argument(
            "device_group_name",
            type=str,
            options_list=[DG_NAME_PARAM_LONG_NAME, DG_NAME_PARAM_SHORT_NAME],
            required=True,
        )

    with self.argument_context("sphere deployment show") as ctx:
        ctx.argument(
            "deployment_name",
            type=str,
            options_list=[DEPLOYMENT_NAME_PARAM_LONG_NAME, DEPLOYMENT_NAME_PARAM_SHORT_NAME],
            required=True,
            help="",
        )

    with self.argument_context("sphere deployment create") as ctx:
        ctx.argument(
            "image_identifiers",
            nargs="+",
            options_list=[DG_IMAGES_LONG_NAME, DG_IMAGES_SHORT_NAME],
            required=True,
        )
