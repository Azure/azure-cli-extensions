"""This module provides the deployment validator."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from argparse import Namespace

from azext_azure_sphere.deployment.params import (
    DEPLOYMENT_NAME_PARAM_LONG_NAME,
    DEPLOYMENT_NAME_PARAM_SHORT_NAME,
    DG_IMAGES_LONG_NAME,
)
from azext_azure_sphere.helpers.utils import is_uuid
from knack.util import CLIError


def deployment_images_validator(namespace: Namespace):
    """Validate the deployment create command."""
    if namespace.image_identifiers and len(namespace.image_identifiers) == 1:
        namespace.image_identifiers = namespace.image_identifiers[0].split(" ")

    for image in namespace.image_identifiers:
        if not is_uuid(image):
            raise CLIError(f"The {DG_IMAGES_LONG_NAME} parameter is invalid.")


def deployment_id_validator(namespace: Namespace):
    """Validate the deployment id parameter."""
    if not is_uuid(namespace.deployment_name):
        raise CLIError(
            f"The {DEPLOYMENT_NAME_PARAM_LONG_NAME}/{DEPLOYMENT_NAME_PARAM_SHORT_NAME} parameter is invalid."
        )
