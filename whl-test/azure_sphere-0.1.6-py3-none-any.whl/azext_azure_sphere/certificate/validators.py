"""This module provides the ca-certificate validator."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from argparse import Namespace

from azext_azure_sphere._validators import destination_file_validator


def destination_file_p7b_validator(namespace: Namespace):
    """Validate the --output-file parameter with .p7b extension."""
    destination_file_validator(namespace, ".p7b")
