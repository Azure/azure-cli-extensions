"""This module provides the ca-certificate commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._client_factory import cf_certificate
from azext_azure_sphere._exception_handler import cloud_exception_handler
from azext_azure_sphere.certificate.format import transform_certificate_list
from azext_azure_sphere.certificate.validators import (
    destination_file_p7b_validator,
    destination_file_validator,
)
from azure.cli.core.commands import CliCommandType


def load_certificate_command_table(self, _):
    """List of the certificate commands and their configurations."""
    certificate_sdk = CliCommandType(
        operations_tmpl="azext_azure_sphere.sdk.asrm.azure.mgmt.azuresphere.operations#CertificatesOperations.{}",  # pylint: disable=line-too-long
        client_factory=cf_certificate,
        exception_handler=cloud_exception_handler,
    )

    certificate_type = CliCommandType(
        operations_tmpl="azext_azure_sphere.certificate.custom#{}",
        exception_handler=cloud_exception_handler,
    )

    with self.command_group(
        "sphere ca-certificate", command_type=certificate_sdk, custom_command_type=certificate_type
    ) as ctx:
        ctx.command("list", "list_by_catalog", transform=transform_certificate_list)
        ctx.custom_show_command(
            "download", "download_certificate", validator=destination_file_validator
        )
        ctx.custom_command(
            "download-chain", "download_chain_certificate", validator=destination_file_p7b_validator
        )
        ctx.custom_command(
            "download-proof",
            "download_proof_of_possession_certificate",
            validator=destination_file_validator,
        )
