"""This module provides the certificate commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._validators import OUTPUT_FILE_PARAM_LONG_NAME, OUTPUT_FILE_PARAM_SHORT_NAME

CERTIFICATE_NAME_PARAM_LONG_NAME = "--serial-number"
CERTIFICATE_NAME_PARAM_SHORT_NAME = "-sn"

PROOF_OF_POSSESSION_PARAM_LONG_NAME = "--verification-code"
PROOF_OF_POSSESSION_PARAM_SHORT_NAME = "-v"


def load_certificate_arguments(self, _):
    """Load arguments for ca-certificate related commands."""
    with self.argument_context("sphere ca-certificate") as ctx:
        ctx.argument(
            "serial_number",
            type=str,
            default="active",
            options_list=[CERTIFICATE_NAME_PARAM_LONG_NAME, CERTIFICATE_NAME_PARAM_SHORT_NAME],
            required=False,
        )
        ctx.argument(
            "output_file",
            type=str,
            options_list=[OUTPUT_FILE_PARAM_LONG_NAME, OUTPUT_FILE_PARAM_SHORT_NAME],
            required=True,
        )

    with self.argument_context("sphere ca-certificate download-proof") as ctx:
        ctx.argument(
            "verificationcode",
            type=str,
            options_list=[
                PROOF_OF_POSSESSION_PARAM_LONG_NAME,
                PROOF_OF_POSSESSION_PARAM_SHORT_NAME,
            ],
            required=True,
        )
