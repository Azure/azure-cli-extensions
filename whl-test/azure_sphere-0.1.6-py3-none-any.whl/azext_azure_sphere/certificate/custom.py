"""This module provides the implementation of custom ca-certificate commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._client_factory import cf_certificate
from azext_azure_sphere.helpers.utils import save_certificate
from azext_azure_sphere.sdk.asrm.azure.mgmt.azuresphere.models._models_py3 import (
    ProofOfPossessionNonceRequest,
)
from azure.cli.core.commands import AzCliCommand
from knack.log import get_logger

logger = get_logger(__name__)


def download_chain_certificate(
    cmd: AzCliCommand,
    resource_group_name: str,
    catalog_name: str,
    serial_number: str,
    output_file: str,
):
    """Download certificate chain (ca-certificate download-chain)."""
    certificate_client = cf_certificate(cmd.cli_ctx)
    result = certificate_client.retrieve_cert_chain(
        resource_group_name, catalog_name, serial_number
    )
    save_certificate(result.certificate_chain, output_file)


def download_certificate(
    cmd: AzCliCommand,
    resource_group_name: str,
    catalog_name: str,
    serial_number: str,
    output_file: str,
):
    """Download certificate (ca-certificate download)."""
    certificate_client = cf_certificate(cmd.cli_ctx)
    result = certificate_client.get(resource_group_name, catalog_name, serial_number)
    save_certificate(result.certificate, output_file)


def download_proof_of_possession_certificate(
    cmd: AzCliCommand,
    resource_group_name: str,
    catalog_name: str,
    serial_number: str,
    verificationcode: str,
    output_file: str,
):
    """Download certificate proof of possession (ca-certificate download-proof)."""
    parameters = ProofOfPossessionNonceRequest(proof_of_possession_nonce=verificationcode)
    certificate_client = cf_certificate(cmd.cli_ctx)
    result = certificate_client.retrieve_proof_of_possession_nonce(
        resource_group_name,
        catalog_name,
        serial_number,
        proof_of_possession_nonce_request=parameters,
    )
    save_certificate(result.certificate, output_file)
