"""Provides validators for sphere commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

import os
import re
from argparse import Namespace
from pathlib import Path

from azext_azure_sphere.helpers.utils import get_config_value
from azure.cli.core.commands import AzCliCommand
from knack.log import get_logger
from knack.util import CLIError

logger = get_logger(__name__)

CATALOG_PARAM_LONG_NAME = "--catalog"
CATALOG_PARAM_SHORT_NAME = "-c"

OUTPUT_FILE_PARAM_LONG_NAME = "--output-file"
OUTPUT_FILE_PARAM_SHORT_NAME = "-of"

INPUT_FILE_PARAM_LONG_NAME = "--input-file"
INPUT_FILE_PARAM_SHORT_NAME = "-if"


def catalog_validator(cmd: AzCliCommand, namespace: Namespace):
    """Validate the --catalog-name parameter.

    This validator is invoked by specifying the 'catalog_name' parameter in a
    command.

    :param cmd: The current command instance, which allows access to the
        CLI context and numerous helper methods.
    :type cmd: AzCliCommand
    :param namespace: An object for storing attributes which are passed
        as parameters to the individual commands e.g. 'catalog_name'.
    :type namespace: Namespace
    """
    if (not hasattr(namespace, "catalog_name")) or namespace.catalog_name is None:
        namespace.catalog_name = get_config_value(cmd, "defaults", "sphere.catalog", None)
        if namespace.catalog_name is None:
            raise CLIError(
                "the following arguments are required: "
                f"{CATALOG_PARAM_LONG_NAME}/{CATALOG_PARAM_SHORT_NAME}"
            )


def destination_file_validator(
    namespace: Namespace,
    extension: str = None,
    allow_extension_correction: bool = False,
    allow_overwrite: bool = False,
):
    """Validate the --output-file parameter."""
    if namespace.output_file.isspace():
        raise CLIError(
            f"The {OUTPUT_FILE_PARAM_LONG_NAME}/{OUTPUT_FILE_PARAM_SHORT_NAME} (path) parameter is invalid."
        )

    dest_path = Path(namespace.output_file)
    if not dest_path.parent.exists():
        raise CLIError(
            f"The {OUTPUT_FILE_PARAM_LONG_NAME}/{OUTPUT_FILE_PARAM_SHORT_NAME} (path) parameter is invalid."
        )

    if dest_path.is_dir():
        message = f"The {OUTPUT_FILE_PARAM_LONG_NAME}/{OUTPUT_FILE_PARAM_SHORT_NAME} (path) parameter cannot be a directory."
        raise CLIError(message)

    if dest_path.is_file() and not allow_overwrite:
        raise CLIError(
            f"The {OUTPUT_FILE_PARAM_LONG_NAME}/{OUTPUT_FILE_PARAM_SHORT_NAME} (path) cannot be an existing file."
        )

    if (
        dest_path.is_file()
        and allow_overwrite
        and not os.access(dest_path, os.W_OK)
        and not os.access(dest_path.parent, os.W_OK | os.X_OK)
    ):
        raise CLIError(
            f"The {OUTPUT_FILE_PARAM_LONG_NAME}/{OUTPUT_FILE_PARAM_SHORT_NAME} (path) cannot be overwritten."
        )

    if not dest_path.is_file() and not os.access(dest_path.parent, os.W_OK):
        message = (
            f"The {OUTPUT_FILE_PARAM_LONG_NAME}/{OUTPUT_FILE_PARAM_SHORT_NAME} (path) parameter "
            "points to a file you do not have write permission for."
        )
        raise CLIError(message)

    if extension and dest_path.suffix != extension:
        if not allow_extension_correction:
            message = (
                f"The {OUTPUT_FILE_PARAM_LONG_NAME}/{OUTPUT_FILE_PARAM_SHORT_NAME} (path) parameter "
                f"must have the '{extension}' extension."
            )
            raise CLIError(message)
        else:
            dest_path = dest_path.with_suffix(extension)

    namespace.output_file = dest_path.resolve()


def input_file_validator(
    input_file: str,
    extension: str = None,
    long_param_name=INPUT_FILE_PARAM_LONG_NAME,
    short_param_name=INPUT_FILE_PARAM_SHORT_NAME,
):
    """Validate the --input-file parameter."""
    if short_param_name is None:
        param_message = f"{long_param_name}"
    else:
        param_message = f"{long_param_name}/{short_param_name}"

    if input_file.isspace():
        raise CLIError(f"The {param_message} (path) parameter is invalid.")

    input_path = Path(input_file)
    if not input_path.exists():
        raise CLIError(f"The {param_message} (path) parameter is invalid. The file doesn't exist.")

    if input_path.is_dir():
        message = f"The {param_message} (path) parameter cannot be a directory."
        raise CLIError(message)

    if input_path.is_file() and not os.access(input_path, os.R_OK):
        message = (
            f"The {param_message} (path) parameter "
            "points to a file you do not have read permission for."
        )
        raise CLIError(message)

    if extension and input_path.suffix != extension:
        message = f"The {param_message} (path) parameter " f"must have the '{extension}' extension."
        raise CLIError(message)

    return input_path.resolve()


def get_support_data_destination_validator(namespace: Namespace):
    """Validate the --destination parameter.

    This validator validates that the path to the destination exists.
    If the user does not specify a filename, then the logs are saved in
    a file called support_data.zip. If the filename is specified, then it
    validates that only .zip extension can be specified.'

    :param namespace: An object for storing attributes which are passed
        as parameters to the individual commands e.g. 'file_path'.
    :type namespace: Namespace
    """
    allowed_extension = ".zip"
    dest_path = Path(namespace.output_file)

    # Check if destination has a suffix. If it does, then it is a file.
    if dest_path.suffix:
        # Check if the suffix is the correct extension.
        if dest_path.suffix != allowed_extension:
            message = (
                f"The {OUTPUT_FILE_PARAM_LONG_NAME} '{dest_path.as_posix()}' parameter "
                f"must have the '{allowed_extension}' extension."
            )
            raise CLIError(message)

        # Check that parent path of destination exists.
        if not dest_path.parent.exists():
            raise CLIError(
                f"The {OUTPUT_FILE_PARAM_LONG_NAME} '{dest_path.as_posix()}' path does not exist."
            )

    else:
        # User has not specified a suffix. Check if the destination is a directory.
        if not dest_path.exists():
            # Destination does not exist.
            raise CLIError(
                f"The {OUTPUT_FILE_PARAM_LONG_NAME} '{dest_path.as_posix()}' parameter path does not exist."
            )

        # Destination exists. Support data will be created with file name 'support_data.zip'
        logger.warning(
            f"The {OUTPUT_FILE_PARAM_LONG_NAME} '{dest_path.as_posix()}' parameter is a directory. Support data will be saved with file name 'support_data.zip'"
        )
        dest_path = Path(os.path.join(dest_path, "support_data.zip"))

    if dest_path.is_file():
        raise CLIError(
            f"The {OUTPUT_FILE_PARAM_LONG_NAME} '{dest_path.as_posix()}' cannot be an existing file."
        )

    if not os.access(dest_path.parent, os.W_OK):
        message = (
            f"The {OUTPUT_FILE_PARAM_LONG_NAME} '{dest_path.as_posix()}' parameter "
            "points to a file you do not have write permission for."
        )
        raise CLIError(message)

    namespace.output_file = dest_path.resolve()


def parameter_length_validator(
    param: str,
    max_length: int,
    long_param_name: str,
    short_param_name: str = None,
    min_length: int = 0,
):
    """Validate the lenght of a string parameter."""
    if min_length > 0:
        if len(param) < min_length and len(param) < max_length:
            if short_param_name is None:
                param_message = f"{long_param_name}"
            else:
                param_message = f"{long_param_name}/{short_param_name}"
            raise CLIError(
                f"The {param_message} parameter must have length between {min_length} and {max_length} characters."
            )
    elif len(param) > max_length:
        if short_param_name is None:
            param_message = f"{long_param_name}"
        else:
            param_message = f"{long_param_name}/{short_param_name}"
        raise CLIError(
            f"The {param_message} parameter cannot exceed the maximum length of {max_length} characters."
        )


def parameter_regex_validator(
    param: str, regex: str, error_msg: str, long_param_name: str, short_param_name: str = None
):
    """Validate the format(regex) of a string parameter."""
    if not re.match(regex, param):
        if short_param_name is None:
            param_message = f"{long_param_name}"
        else:
            param_message = f"{long_param_name}/{short_param_name}"
        raise CLIError(
            f"The {param_message} parameter does not match the expected format: Check the values you provided and try again. {error_msg}."
        )
