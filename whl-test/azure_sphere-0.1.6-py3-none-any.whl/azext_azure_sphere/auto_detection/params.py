"""This module has a function to load auto-detection device arguments for device and cloud commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

DEVICE_PARAM_LONG_NAME = "--device"
DEVICE_PARAM_SHORT_NAME = "-d"


def load_auto_detection_arguments(self, _):
    """Load arguments for auto detection device commands."""
    from azext_azure_sphere.auto_detection.validators import (
        device_id_validator,
        device_ip_validator,
        device_name_validator,
    )

    with self.argument_context("") as context:
        context.argument(
            "device_ip",
            type=str,
            required=False,
            options_list=[DEVICE_PARAM_LONG_NAME, DEVICE_PARAM_SHORT_NAME],
            validator=device_ip_validator,
        )
        context.argument(
            "device_id",
            type=str,
            required=False,
            options_list=[DEVICE_PARAM_LONG_NAME, DEVICE_PARAM_SHORT_NAME],
            validator=device_id_validator,
        )
        context.argument(
            "device_name",
            type=str,
            required=False,
            options_list=[DEVICE_PARAM_LONG_NAME, DEVICE_PARAM_SHORT_NAME],
            validator=device_name_validator,
        )
