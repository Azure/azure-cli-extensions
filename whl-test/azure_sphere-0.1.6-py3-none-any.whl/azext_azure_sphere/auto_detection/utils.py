"""This module provides utilities for auto detection of attached device."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

import re
from uuid import UUID

from azuresphere_device_api import device, devices
from knack.util import CLIError


def get_device_id(device_ip: str) -> str:
    """Returns the device identifier given the device_ip.

    :param cli_ctx: Command object.
    :type cli_ctx: AzCli
    :param device_ip: str
    :type device_ip: str
    :return: Device identifier (or device identity public key for OS < 20.07)
    :rtype: str
    """
    security_state = {}
    devices.set_active_device_ip_address(device_ip)
    security_state = device.get_device_security_state()

    if security_state["securityState"] == "TEST":
        message = (
            "The device is in test mode. You must provide the "
            "device ID of a test mode device to claim it."
        )
        raise CLIError(message)

    # for OS versions < 20.07 device_identifier == deviceIdentityPublicKey
    # device_identifier doesn't exist in the response
    if "deviceIdentifier" in security_state:
        return security_state["deviceIdentifier"]

    return security_state["deviceIdentityPublicKey"]


def is_device_id(device_id: str) -> bool:
    """Checks if a string is a valid device id.

    :param device_id: The string being tested
    :type device_id: str
    :return: true if the string is a device id, false otherwise
    :rtype: bool
    """
    # MT3620 devices will always have a device id of length 128 characters.
    pattern = re.compile(r"^[0-9a-fA-F]{128}$")
    if pattern.match(device_id) is None:
        return False
    return True


def is_device_ip(device_ip: str) -> bool:
    """Checks if a string is a valid device IP.

    Only allows valid IPv4 addresses.

    :param device_id: The string being tested
    :type device_id: str
    :return: true if the string is a device IP, false otherwise
    :rtype: bool
    """
    pattern = re.compile(
        r"^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.)"
        r"{3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$"
    )
    if pattern.match(device_ip) is None:
        return False
    return True


def is_device_location(device_location: str) -> bool:
    """Checks if a string is a valid device location.

    Device FTDI Location is described here:
    https://www.ftdichip.com/Support/Knowledgebase/index.html?usinglocationids.htm

    :param device_id: The string being tested
    :type device_id: str
    :return: true if the string is a device location, false otherwise
    :rtype: bool
    """
    pattern = re.compile(r"^[0-9a-fA-F]{1,8}$")
    if pattern.match(device_location) is None:
        return False
    return True


def is_uuid(uuid: str) -> bool:
    """Check if a string is a valid UUID of any version.

    :param uuid: The string being tested.
    :type uuid: str
    :return: Whether the string is a valid UUID.
    :rtype: bool
    """
    try:
        _ = UUID(uuid).version
        return True
    except (ValueError, TypeError):
        return False
