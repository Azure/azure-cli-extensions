"""This module provides the image-package command structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._exception_handler import cloud_exception_handler
from azext_azure_sphere.device.validators import device_commands_cliv2_common_validator
from azext_azure_sphere.helpers.utils import get_query_param_value
from azure.cli.core.commands import CliCommandType


def load_image_package_command_table(self, _):
    """List of the image-packages commands and their configurations."""
    image_package_custom_type = CliCommandType(
        operations_tmpl="azext_azure_sphere.imagepackage.custom#{}",
        exception_handler=cloud_exception_handler,
    )

    with self.command_group(
        "sphere image-package", custom_command_type=image_package_custom_type
    ) as ctx:
        ctx.custom_command(
            "show",
            "image_package_show",
            validator=device_commands_cliv2_common_validator,
            table_transformer=get_query_param_value(_),
        )
