"""This module provides the image-package commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

IMAGE_PACKAGE_PARAM_NAME = "--image-package"


def load_image_package_arguments(self, _):
    """Load arguments for image-package related commands."""
    with self.argument_context("sphere image-package show") as ctx:
        ctx.argument(
            "image_package",
            type=str,
            options_list=[IMAGE_PACKAGE_PARAM_NAME],
            required=True,
        )
