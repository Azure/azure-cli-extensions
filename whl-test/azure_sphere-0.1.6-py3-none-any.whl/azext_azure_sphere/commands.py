"""This module provides the sphere commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._exception_handler import (
    cloud_exception_handler,
    combo_commands_exception_handler,
    device_exception_handler,
)
from azext_azure_sphere._validators import get_support_data_destination_validator
from azext_azure_sphere.device.validators import device_commands_common_validator
from azure.cli.core.commands import CliCommandType


def load_sphere_command_table(self, _):
    """List of the sphere commands and their configurations."""
    sphere_custom_type = CliCommandType(
        operations_tmpl="azext_azure_sphere.custom#{}",
        exception_handler=cloud_exception_handler,
    )

    with self.command_group("sphere", custom_command_type=sphere_custom_type) as ctx:
        ctx.custom_command(
            "get-support-data",
            "get_support_data",
            validator=get_support_data_destination_validator,
            exception_handler=combo_commands_exception_handler,
        )
        ctx.custom_command(
            "show-sdk-version",
            "show_sdk_version",
            validator=device_commands_common_validator,
            exception_handler=device_exception_handler,
        )
