"""This module provides the cloud management commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._help import helps  # pylint: disable=unused-import
from azure.cli.core import AzCommandsLoader, commands


class AzureSphereCommandsLoader(AzCommandsLoader):
    """This module provides the cloud management commands."""

    def __init__(self, cli_ctx=None):
        """Initialise all cloud command groups e.g. tenant and role."""
        super(AzureSphereCommandsLoader, self).__init__(cli_ctx=cli_ctx)

    # pylint: disable=import-outside-toplevel
    def load_command_table(self, args):
        """Load all cloud commands."""
        from azext_azure_sphere.catalog.commands import load_catalog_command_table
        from azext_azure_sphere.certificate.commands import load_certificate_command_table
        from azext_azure_sphere.commands import load_sphere_command_table
        from azext_azure_sphere.deployment.commands import load_deployment_command_table
        from azext_azure_sphere.device.app.commands import load_device_app_command_table
        from azext_azure_sphere.device.capability.commands import (
            load_device_capability_command_table,
        )
        from azext_azure_sphere.device.certificate.commands import (
            load_device_certificate_command_table,
        )
        from azext_azure_sphere.device.commands import load_device_command_table
        from azext_azure_sphere.device.image.commands import load_device_image_command_table
        from azext_azure_sphere.device.manufacturing.commands import (
            load_device_manufacturing_command_table,
        )
        from azext_azure_sphere.device.network.commands import load_device_network_command_table
        from azext_azure_sphere.device.network.proxy.commands import (
            load_device_network_proxy_command_table,
        )
        from azext_azure_sphere.device.sideload.commands import load_device_sideload_command_table
        from azext_azure_sphere.device.wifi.commands import load_device_wifi_command_table
        from azext_azure_sphere.devicegroup.commands import load_device_group_command_table
        from azext_azure_sphere.hardwaredefinition.commands import (
            load_hardware_definition_command_table,
        )
        from azext_azure_sphere.image.commands import load_image_command_table
        from azext_azure_sphere.imagepackage.commands import load_image_package_command_table
        from azext_azure_sphere.product.commands import load_product_command_table

        load_sphere_command_table(self, args)
        load_catalog_command_table(self, args)
        load_product_command_table(self, args)
        load_device_group_command_table(self, args)
        load_image_command_table(self, args)
        load_device_command_table(self, args)
        load_device_app_command_table(self, args)
        load_device_certificate_command_table(self, args)
        load_device_capability_command_table(self, args)
        load_device_image_command_table(self, args)
        load_device_manufacturing_command_table(self, args)
        load_device_network_command_table(self, args)
        load_device_network_proxy_command_table(self, args)
        load_device_wifi_command_table(self, args)
        load_device_sideload_command_table(self, args)
        load_certificate_command_table(self, args)
        load_deployment_command_table(self, args)
        load_image_package_command_table(self, args)
        load_hardware_definition_command_table(self, args)
        return self.command_table

    # pylint: disable=import-outside-toplevel
    def load_arguments(self, command):
        """Load all cloud arguments."""
        from azext_azure_sphere._params import load_core_catalog_arguments
        from azext_azure_sphere.auto_detection.params import load_auto_detection_arguments
        from azext_azure_sphere.catalog.params import load_catalog_arguments
        from azext_azure_sphere.certificate.params import load_certificate_arguments
        from azext_azure_sphere.deployment.params import load_deployment_arguments
        from azext_azure_sphere.device.app.params import load_device_app_arguments
        from azext_azure_sphere.device.capability.params import load_device_capability_arguments
        from azext_azure_sphere.device.certificate.params import load_device_certificate_arguments
        from azext_azure_sphere.device.image.params import load_device_image_arguments
        from azext_azure_sphere.device.manufacturing.params import (
            load_device_manufacturing_arguments,
        )
        from azext_azure_sphere.device.network.params import load_device_network_arguments
        from azext_azure_sphere.device.network.proxy.params import (
            load_device_network_proxy_arguments,
        )
        from azext_azure_sphere.device.params import load_device_arguments
        from azext_azure_sphere.device.sideload.params import load_device_sideload_arguments
        from azext_azure_sphere.device.wifi.params import load_device_wifi_arguments
        from azext_azure_sphere.devicegroup.params import load_device_group_arguments
        from azext_azure_sphere.hardwaredefinition.params import load_hardware_definition_arguments
        from azext_azure_sphere.image.params import load_image_arguments
        from azext_azure_sphere.imagepackage.params import load_image_package_arguments
        from azext_azure_sphere.product.params import load_product_arguments

        load_auto_detection_arguments(self, command)
        load_core_catalog_arguments(self, command)
        load_product_arguments(self, command)
        load_device_group_arguments(self, command)
        load_image_arguments(self, command)
        load_device_arguments(self, command)
        load_device_app_arguments(self, command)
        load_device_certificate_arguments(self, command)
        load_device_image_arguments(self, command)
        load_device_manufacturing_arguments(self, command)
        load_device_network_arguments(self, command)
        load_device_network_proxy_arguments(self, command)
        load_device_wifi_arguments(self, command)
        load_device_sideload_arguments(self, command)
        load_device_capability_arguments(self, command)
        load_catalog_arguments(self, command)
        load_certificate_arguments(self, command)
        load_deployment_arguments(self, command)
        load_image_package_arguments(self, command)
        load_hardware_definition_arguments(self, command)


# pylint: disable=invalid-name
COMMAND_LOADER_CLS = AzureSphereCommandsLoader


from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("azure-sphere")
    VERSION = __version__
except PackageNotFoundError:
    # package is not installed
    pass