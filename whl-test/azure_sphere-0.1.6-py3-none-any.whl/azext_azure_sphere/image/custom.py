"""This module provides the implementation of custom image commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------
import base64
import time

from azext_azure_sphere._client_factory import cf_image
from azext_azure_sphere.helpers.utils import DEFAULT_VALUE
from azext_azure_sphere.helpers.utils_images import get_image_id_from_imagepackage_file
from azext_azure_sphere.sdk.asrm.azure.mgmt.azuresphere.models._models import Image
from azure.cli.core.commands import AzCliCommand
from azure.core.polling import LROPoller
from knack.log import get_logger
from knack.util import CLIError

logger = get_logger(__name__)


def add_image(
    cmd: AzCliCommand,
    resource_group_name: str,
    catalog_name: str,
    input_file: str,
    image_regionaldataboundary=None,
):
    """Add a new image (image add)."""
    image_id = get_image_id_from_imagepackage_file(input_file=input_file)
    if image_id is None:
        raise CLIError(f"The imagepackage file '{input_file}' appears to be invalid.")
    try:
        with open(input_file, "rb") as image_path:
            encoded_string = base64.b64encode(image_path.read())
            images = encoded_string.decode("utf-8")
            parameters = Image(image=images)
        parameters.regional_data_boundary = image_regionaldataboundary
    except Exception as ex:
        raise CLIError(f"Unable to parse the imagepackage file '{input_file}'.") from ex

    image_client = cf_image(cmd.cli_ctx)
    response = image_client.begin_create_or_update(
        resource_group_name, catalog_name, DEFAULT_VALUE, parameters
    )

    # Wait for the asynchronous function to finish executing
    while isinstance(response, LROPoller) and not response.done():
        time.sleep(1)

    return image_client.get(
        resource_group_name=resource_group_name, catalog_name=catalog_name, image_name=image_id
    )
