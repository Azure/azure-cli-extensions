"""This module provides the image commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere.sdk.asrm.azure.mgmt.azuresphere.models._azure_sphere_provider_client_enums import (
    RegionalDataBoundary,
)
from azure.cli.core.commands.parameters import get_enum_type, get_three_state_flag

IMAGE_PARAM_LONG_NAME = "--image"

IMAGE_PATH_PARAM_LONG_NAME = "--image-path"
IMAGE_PATH_PARAM_SHORT_NAME = "-img"

IMAGE_URL_PARAM_LONG_NAME = "--image-sas-url"
IMAGE_URL_PARAM_SHORT_NAME = "-url"

IMAGE_REGIONAL_DATA_BOUNDARY_LONG_NAME = "--regional-data-boundary"
IMAGE_REGIONAL_DATA_BOUNDARY_SHORT_NAME = "-r"


def load_image_arguments(self, _):
    """Load arguments for image related commands."""
    with self.argument_context("sphere image") as ctx:
        ctx.argument(
            "image_name",
            type=str,
            options_list=[IMAGE_PARAM_LONG_NAME],
            required=True,
        )
    with self.argument_context("sphere image add") as ctx:
        ctx.argument(
            "input_file",
            type=str,
            options_list=[IMAGE_PATH_PARAM_LONG_NAME, IMAGE_PATH_PARAM_SHORT_NAME],
            required=True,
        )
        ctx.argument(
            "image_regionaldataboundary",
            arg_type=get_enum_type(
                RegionalDataBoundary,
                RegionalDataBoundary.NONE,
            ),
            options_list=[
                IMAGE_REGIONAL_DATA_BOUNDARY_LONG_NAME,
                IMAGE_REGIONAL_DATA_BOUNDARY_SHORT_NAME,
            ],
        )
