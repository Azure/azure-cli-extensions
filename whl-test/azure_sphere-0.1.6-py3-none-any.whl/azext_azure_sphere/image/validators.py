"""This module provides the image validator."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from argparse import Namespace

from azext_azure_sphere._validators import input_file_validator
from azext_azure_sphere.helpers.utils import is_uuid
from azext_azure_sphere.image.params import (
    IMAGE_PARAM_LONG_NAME,
    IMAGE_PATH_PARAM_LONG_NAME,
    IMAGE_PATH_PARAM_SHORT_NAME,
)
from knack.util import CLIError


def image_name_validator(namespace: Namespace):
    """Validate the image name parameter."""
    if not is_uuid(namespace.image_name):
        raise CLIError(f"The {IMAGE_PARAM_LONG_NAME} parameter is invalid.")


def image_path_validator(namespace: Namespace):
    """Validate the image path / input file parameter."""
    namespace.input_file = input_file_validator(
        input_file=namespace.input_file,
        extension=".imagepackage",
        long_param_name=IMAGE_PATH_PARAM_LONG_NAME,
        short_param_name=IMAGE_PATH_PARAM_SHORT_NAME,
    )
