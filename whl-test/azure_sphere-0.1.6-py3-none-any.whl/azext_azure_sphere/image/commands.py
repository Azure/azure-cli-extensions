"""This module provides the image commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._client_factory import cf_image
from azext_azure_sphere._exception_handler import cloud_exception_handler
from azext_azure_sphere.image.validators import image_name_validator, image_path_validator
from azure.cli.core.commands import CliCommandType


def load_image_command_table(self, _):
    """List of the image commands and their configurations."""
    image_sdk = CliCommandType(
        operations_tmpl="azext_azure_sphere.sdk.asrm.azure.mgmt.azuresphere.operations#ImagesOperations.{}",  # pylint: disable=line-too-long
        client_factory=cf_image,
        exception_handler=cloud_exception_handler,
    )

    image_custom_type = CliCommandType(
        operations_tmpl="azext_azure_sphere.image.custom#{}",
        exception_handler=cloud_exception_handler,
    )

    with self.command_group(
        "sphere image", command_type=image_sdk, custom_command_type=image_custom_type
    ) as ctx:
        ctx.command("list", "list_by_catalog")
        ctx.show_command("show", "get", validator=image_name_validator)
        ctx.custom_command(
            "add",
            "add_image",
            validator=image_path_validator,
        )
