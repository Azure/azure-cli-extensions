"""This module provides the implementation of custom sphere commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

import os
import sys
import tempfile
import time
from io import StringIO
from pathlib import Path

from azext_azure_sphere.auto_detection.utils import get_device_id
from azext_azure_sphere.device_comm.utils import get_device_connections
from azext_azure_sphere.helpers.utils import get_sdk_version
from azext_azure_sphere.helpers.utils_get_support_data import (
    copy_attached_device_log,
    copy_attached_device_tech_support_data,
    copy_azure_activity_logs,
    copy_installer_logs,
    create_zip_archive_file,
    gather_catalogs_available,
    gather_device_configuration,
    gather_ota_status,
    log_attached_device_capabilities,
    log_attached_device_details,
    log_attached_device_installed_images,
    log_attached_device_manufacturing_state,
    log_attached_device_network_firewall_rulesets_status,
    log_attached_device_network_state,
    log_attached_device_stored_wifi_networks,
    log_attached_device_visible_wifi_networks,
    log_attached_device_wifi_status,
    log_azsphered_service_event_logs,
    log_azsphered_service_status,
    log_azure_sphere_network_adapter_details,
    log_local_configuration,
    log_network_adapter_ip_addresses,
    log_slip_service_event_logs,
    log_slip_service_status,
    remove_temporary_folder,
    write_log_file,
)
from azure.cli.core.commands import AzCliCommand
from knack.log import get_logger
from knack.util import CLIError

logger = get_logger(__name__)

PACKAGING_FOLDER_NAME = "Azure_Sphere_Logs"


def show_sdk_version():
    """Get the installed SDK version."""
    try:
        sdk_version = get_sdk_version()
    except Exception as ex:
        raise CLIError(f"Impossible to get SDK version: {ex}") from ex

    return {"Azure Sphere SDK": sdk_version}


def get_support_data(
    cmd: AzCliCommand,
    resource_group_name: str,
    catalog_name: str,
    output_file: str,
):
    """Get support data Cloud, Device and Local data (get-support-data)."""
    # Create temporary folder to store log files
    usr_temporary_folder = tempfile.gettempdir()
    packaging_folder_name = Path(usr_temporary_folder, PACKAGING_FOLDER_NAME)
    logger.warning("Gathering Azure Sphere data.")

    # Delete temporary folder (if exists)
    remove_temporary_folder(packaging_folder_name)

    # Create temporary folder
    try:
        os.mkdir(packaging_folder_name)
        logger.warning(f"Created packaging folder: '{packaging_folder_name}'.")
    except Exception as ex:
        raise CLIError(f"Could not create the temporary packaging folder: {ex}") from ex

    # Get all attached devices
    devices = get_device_connections()

    # Get support data for each device
    try:
        for device_item in devices:
            # Cloud logs
            gather_cloud_data(
                cmd=cmd,
                resource_group_name=resource_group_name,
                catalog_name=catalog_name,
                device=device_item,
                packaging_folder_name=packaging_folder_name,
            )

            # Device logs
            gather_device_data(
                cmd=cmd, device=device_item, packaging_folder_name=packaging_folder_name
            )

        # Local logs
        gather_local_data(cmd=cmd, storage_path=packaging_folder_name)

    except CLIError as err:
        # Don't raise the exception if DCS is not found to continue other part, and
        # instruct user on what to do when the AzureSphereDeviceCommunicationService is not found
        logger.warning(err)
    except Exception as err:
        # Hide all other exceptions to continue other part
        logger.warning("Failed to gather device data.")

    # Create Zip file
    create_zip_archive_file(output_file, packaging_folder_name)

    logger.warning(
        "Note: This archive contains information about your system including the list of Wi-Fi networks the device can see, installation logs, Azure Sphere command-line activity logs, attached USB devices, and Azure Sphere local and cloud configuration. If you choose to provide this data to Microsoft, please send an email to AzCommunity@microsoft.com and attach the generated archive. All data will be handled according to the Microsoft Privacy Statement: https://aka.ms/privacystatement"
    )
    return {"output_file": output_file.as_posix()}


def gather_cloud_data(cmd, resource_group_name, catalog_name, device, packaging_folder_name):
    """Get support data - Cloud data."""

    device_ip = device.ip_address
    device_id = ""
    try:
        device_id = get_device_id(device_ip)
    except Exception as e:
        logger.warning(e)

    # Cloud logs
    logger.warning(f"Gathering Azure Sphere Security Service data {device_id}.")
    logger.warning(" -> Getting cloud configuration.")

    cloud_content = StringIO()
    cloud_content.write("AZURE SPHERE SECURITY SERVICE CONFIGURATION:")
    cloud_content.write(f"\n -> Using device ID: '{device_id}'.")

    # Cloud logs - Catalog list
    logger.warning(" -> Getting list of available catalogs.")
    cloud_content.write("\n\nAVAILABLE CATALOGS:")
    gather_catalogs_available(cmd, resource_group_name, cloud_content)

    # Cloud logs - Device show
    logger.warning(" -> Getting device configuration.")
    cloud_content.write("\n\nDEVICE CONFIGURATION:")
    gather_device_configuration(cmd, resource_group_name, catalog_name, device_id, cloud_content)

    # Cloud logs - OTA status
    logger.warning(" -> Getting device configuration status.")
    cloud_content.write("\n\nDEVICE CONFIGURATION STATUS:")
    gather_ota_status(
        cmd,
        resource_group_name,
        catalog_name,
        device_ip,
        cloud_content,
    )

    # Cloud logs - Write Logs
    write_log_file(packaging_folder_name, device.device_connection_path, cloud_content)


def gather_device_data(cmd, device, packaging_folder_name):
    """Get support data - Device data."""
    logger.warning("Gathering device data.")
    device_data_log = StringIO()

    log_attached_device_details(cmd, device_data_log, device)
    log_attached_device_installed_images(cmd, device_data_log, device.ip_address)
    log_attached_device_capabilities(cmd, device_data_log, device.ip_address)
    log_attached_device_network_state(cmd, device_data_log, device.ip_address)
    log_attached_device_stored_wifi_networks(cmd, device_data_log, device.ip_address)
    log_attached_device_visible_wifi_networks(cmd, device_data_log, device.ip_address)
    log_attached_device_wifi_status(cmd, device_data_log, device.ip_address)
    log_attached_device_manufacturing_state(cmd, device_data_log, device.ip_address)
    log_attached_device_network_firewall_rulesets_status(cmd, device_data_log, device.ip_address)

    # Copy the device's log file
    copy_attached_device_log(cmd, packaging_folder_name, device_data_log, device)

    # Copy the device's tech support data
    copy_attached_device_tech_support_data(cmd, packaging_folder_name, device_data_log, device)

    # Save the device data log
    if len(device_data_log.getvalue()) > 0:
        # Format path
        device_log_file_path = os.path.join(
            packaging_folder_name, f"AzureSphere_Device_{device.device_connection_path}.log"
        )

        with open(device_log_file_path, "w") as f:
            f.write(device_data_log.getvalue())


def gather_local_data(cmd, storage_path: str):
    """Gather local data of the computer."""
    logger.warning("Gathering computer setup data.")

    local_data_log = StringIO()

    # Copy activity logs
    copy_azure_activity_logs(cmd, storage_path)

    # Log the local data.
    log_local_configuration(cmd, local_data_log)
    log_network_adapter_ip_addresses(local_data_log)

    # No non-Windows installer or slip service at the moment, so don't attempt to get
    # any info about this on any other platform
    if sys.platform == "win32":
        # Copy logs from the last 7 days
        start_date_time_for_logs = time.time() - 7 * 24 * 60 * 60

        log_azure_sphere_network_adapter_details(local_data_log)
        log_slip_service_status(local_data_log)
        log_slip_service_event_logs(local_data_log)

        # Copy Azure Sphere installer logs
        logger.debug(" -> Getting the Azure Sphere installer logs.")
        local_data_log.write("\n\nAZURE SPHERE INSTALLER LOGS:")
        copy_installer_logs(
            "dd_VC_AzureSphere_**",
            "InstallerLogs_AzureSphere",
            storage_path,
            local_data_log,
            start_date_time_for_logs,
        )

        # Copy Visual Studio installer logs
        logger.debug(" -> Getting the Visual Studio installer logs.")
        local_data_log.write("\n\nVISUAL STUDIO INSTALLER LOGS:")
        copy_installer_logs(
            "dd_setup*",
            "InstallerLogs_VisualStudio",
            storage_path,
            local_data_log,
            start_date_time_for_logs,
        )

        # Copy VSIX installer logs
        logger.debug(" -> Getting the VSIX plugin installer logs.")
        local_data_log.write("\n\nVSIX PLUGIN INSTALLER LOGS:")
        copy_installer_logs(
            "dd_VSIXInstaller_*",
            "InstallerLogs_VsixPlugins",
            storage_path,
            local_data_log,
            start_date_time_for_logs,
        )
    elif sys.platform == "linux":
        log_azsphered_service_status(local_data_log)
        log_azsphered_service_event_logs(local_data_log)
    else:
        logger.debug(f"Unsupported platform {sys.platform}. Skipping installer logs.")

    # Save the local data log
    if len(local_data_log.getvalue()) > 0:
        # Format path
        local_data_log_file_path = os.path.join(storage_path, "AzureSphere_ComputerSetup.log")

        with open(local_data_log_file_path, "w") as f:
            f.write(local_data_log.getvalue())
