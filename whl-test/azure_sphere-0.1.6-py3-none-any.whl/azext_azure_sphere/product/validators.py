"""This module provides the product validator."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from argparse import Namespace

from azext_azure_sphere._validators import parameter_length_validator, parameter_regex_validator
from azext_azure_sphere.product.params import (
    PRODUCT_DESC_PARAM_LONG_NAME,
    PRODUCT_DESC_PARAM_SHORT_NAME,
    PRODUCT_NAME_PARAM_LONG_NAME,
    PRODUCT_NAME_PARAM_SHORT_NAME,
)

PRODUCT_REGEX = "^[\\w][\\w\\s]{1,48}[\\w]$|^\\.default$|^\\.unassigned$"


def product_create_validator(namespace: Namespace):
    """Validate the product create command."""
    parameter_regex_validator(
        param=namespace.product_name,
        regex=PRODUCT_REGEX,
        error_msg="The product name must be between 3 and 50 characters long and can only contain letters, numbers, and spaces",
        long_param_name=PRODUCT_NAME_PARAM_LONG_NAME,
        short_param_name=PRODUCT_NAME_PARAM_SHORT_NAME,
    )
    parameter_length_validator(
        param=namespace.product_description,
        max_length=100,
        long_param_name=PRODUCT_DESC_PARAM_LONG_NAME,
        short_param_name=PRODUCT_DESC_PARAM_SHORT_NAME,
    )


def product_update_validator(namespace: Namespace):
    """Validate the product update command."""
    if namespace.product_description:
        parameter_length_validator(
            param=namespace.product_description,
            max_length=100,
            long_param_name=PRODUCT_DESC_PARAM_LONG_NAME,
            short_param_name=PRODUCT_DESC_PARAM_SHORT_NAME,
        )
