"""This module provides the product commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._client_factory import cf_product
from azext_azure_sphere._exception_handler import cloud_exception_handler
from azext_azure_sphere.product.validators import product_create_validator, product_update_validator
from azure.cli.core.commands import CliCommandType


def load_product_command_table(self, _):
    """List of the product commands and their configurations."""
    product_sdk = CliCommandType(
        operations_tmpl="azext_azure_sphere.sdk.asrm.azure.mgmt.azuresphere.operations#ProductsOperations.{}",  # pylint: disable=line-too-long
        client_factory=cf_product,
        exception_handler=cloud_exception_handler,
    )

    product_custom_type = CliCommandType(
        operations_tmpl="azext_azure_sphere.product.custom#{}",
        exception_handler=cloud_exception_handler,
    )

    with self.command_group(
        "sphere product", command_type=product_sdk, custom_command_type=product_custom_type
    ) as ctx:
        ctx.command("list", "list_by_catalog")
        ctx.custom_show_command("show", "get_product")
        ctx.custom_command("create", "create_product", validator=product_create_validator)
        ctx.custom_command("update", "update_product", validator=product_update_validator)
        ctx.command("delete", "begin_delete")
