"""This module provides the device group validator."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from argparse import Namespace

from azext_azure_sphere._validators import parameter_length_validator, parameter_regex_validator
from azext_azure_sphere.devicegroup.params import (
    DG_DESC_PARAM_LONG_NAME,
    DG_DESC_PARAM_SHORT_NAME,
    DG_NAME_PARAM_LONG_NAME,
    DG_NAME_PARAM_SHORT_NAME,
)
from knack.util import CLIError

DG_REGEX = (
    r"^[A-Za-z0-9]{1,2}$|^[A-Za-z0-9][A-Za-z0-9\s]{1,48}[A-Za-z0-9]$|^\.default$|^\.unassigned$"
)


def device_group_create_validator(namespace: Namespace):
    """Validate the device group create command."""
    parameter_regex_validator(
        param=namespace.device_group_name,
        regex=DG_REGEX,
        error_msg="The device group name must be between 3 and 50 characters long and can only contain letters, numbers, and spaces",
        long_param_name=DG_NAME_PARAM_LONG_NAME,
        short_param_name=DG_NAME_PARAM_SHORT_NAME,
    )
    parameter_length_validator(
        param=namespace.device_group_description,
        max_length=100,
        long_param_name=DG_DESC_PARAM_LONG_NAME,
        short_param_name=DG_DESC_PARAM_SHORT_NAME,
    )


def device_group_update_validator(namespace: Namespace):
    """Validate the device-group update command."""
    if (
        (not namespace.device_group_description or namespace.device_group_description.isspace())
        and not namespace.device_group_applicationupdate
        and not namespace.device_group_osfeed
        and not namespace.device_group_allowcrashdumps
        and not namespace.device_group_regionaldataboundary
    ):
        message = "You must provide a value for at least one of the optional update arguments."
        raise CLIError(message)

    if namespace.device_group_description:
        parameter_length_validator(
            param=namespace.device_group_description,
            max_length=100,
            long_param_name=DG_DESC_PARAM_LONG_NAME,
            short_param_name=DG_DESC_PARAM_SHORT_NAME,
        )
