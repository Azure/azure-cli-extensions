"""This module provides the device group commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------
# pylint: disable=line-too-long

from azext_azure_sphere.product.params import (
    PRODUCT_NAME_PARAM_LONG_NAME,
    PRODUCT_NAME_PARAM_SHORT_NAME,
)
from azext_azure_sphere.sdk.asrm.azure.mgmt.azuresphere.models._azure_sphere_provider_client_enums import (
    AllowCrashDumpCollection,
    OSFeedType,
    RegionalDataBoundary,
    UpdatePolicy,
)
from azure.cli.core.commands.parameters import get_enum_type

DG_NAME_PARAM_LONG_NAME = "--device-group"
DG_NAME_PARAM_SHORT_NAME = "-dg"

DG_DESC_PARAM_LONG_NAME = "--description"
DG_DESC_PARAM_SHORT_NAME = "-d"

DG_APP_UPDATE_LONG_NAME = "--application-update"
DG_APP_UPDATE_SHORT_NAME = "-a"

DG_OS_FEED_LONG_NAME = "--os-feed"
DG_OS_FEED_SHORT_NAME = "-f"

DG_CRASH_DUMPS_LONG_NAME = "--allow-crash-dumps-collection"
DG_CRASH_DUMPS_SHORT_NAME = "-cd"

DG_REGIONAL_DATA_BOUNDARY_LONG_NAME = "--regional-data-boundary"
DG_REGIONAL_DATA_BOUNDARY_SHORT_NAME = "-r"


def load_device_group_arguments(self, _):
    """Load arguments for device group related commands."""
    with self.argument_context("sphere device-group") as ctx:
        ctx.argument(
            "product_name",
            type=str,
            options_list=[PRODUCT_NAME_PARAM_LONG_NAME, PRODUCT_NAME_PARAM_SHORT_NAME],
            required=True,
        )
        ctx.argument(
            "device_group_name",
            type=str,
            options_list=[DG_NAME_PARAM_LONG_NAME, DG_NAME_PARAM_SHORT_NAME],
            required=True,
        )

    with self.argument_context("sphere device-group create") as ctx:
        ctx.argument(
            "device_group_name",
            type=str,
            options_list=["--name", "-n"],
            required=True,
        )
        ctx.argument(
            "device_group_description",
            type=str,
            options_list=[DG_DESC_PARAM_LONG_NAME, DG_DESC_PARAM_SHORT_NAME],
            required=True,
        )
        ctx.argument(
            "device_group_applicationupdate",
            arg_type=get_enum_type(
                UpdatePolicy,
                UpdatePolicy.UPDATE_ALL,
            ),
            options_list=[DG_APP_UPDATE_LONG_NAME, DG_APP_UPDATE_SHORT_NAME],
        )
        ctx.argument(
            "device_group_osfeed",
            arg_type=get_enum_type(
                OSFeedType,
                OSFeedType.RETAIL,
            ),
            options_list=[DG_OS_FEED_LONG_NAME, DG_OS_FEED_SHORT_NAME],
        )
        ctx.argument(
            "device_group_allowcrashdumps",
            arg_type=get_enum_type(AllowCrashDumpCollection, AllowCrashDumpCollection.DISABLED),
            options_list=[DG_CRASH_DUMPS_LONG_NAME, DG_CRASH_DUMPS_SHORT_NAME],
        )
        ctx.argument(
            "device_group_regionaldataboundary",
            arg_type=get_enum_type(
                RegionalDataBoundary,
                RegionalDataBoundary.NONE,
            ),
            options_list=[
                DG_REGIONAL_DATA_BOUNDARY_LONG_NAME,
                DG_REGIONAL_DATA_BOUNDARY_SHORT_NAME,
            ],
        )

    with self.argument_context("sphere device-group update") as ctx:
        ctx.argument(
            "device_group_description",
            type=str,
            options_list=[DG_DESC_PARAM_LONG_NAME, DG_DESC_PARAM_SHORT_NAME],
        )
        ctx.argument(
            "device_group_applicationupdate",
            arg_type=get_enum_type(UpdatePolicy),
            options_list=[DG_APP_UPDATE_LONG_NAME, DG_APP_UPDATE_SHORT_NAME],
        )
        ctx.argument(
            "device_group_osfeed",
            arg_type=get_enum_type(OSFeedType),
            options_list=[DG_OS_FEED_LONG_NAME, DG_OS_FEED_SHORT_NAME],
        )
        ctx.argument(
            "device_group_allowcrashdumps",
            arg_type=get_enum_type(AllowCrashDumpCollection),
            options_list=[DG_CRASH_DUMPS_LONG_NAME, DG_CRASH_DUMPS_SHORT_NAME],
        )
        ctx.argument(
            "device_group_regionaldataboundary",
            arg_type=get_enum_type(RegionalDataBoundary),
            options_list=[
                DG_REGIONAL_DATA_BOUNDARY_LONG_NAME,
                DG_REGIONAL_DATA_BOUNDARY_SHORT_NAME,
            ],
        )

    with self.argument_context("sphere device-group list") as ctx:
        ctx.argument(
            "product_name",
            type=str,
            options_list=[PRODUCT_NAME_PARAM_LONG_NAME, PRODUCT_NAME_PARAM_SHORT_NAME],
            required=False,
        )
        ctx.argument(
            "device_group_name",
            type=str,
            options_list=[DG_NAME_PARAM_LONG_NAME, DG_NAME_PARAM_SHORT_NAME],
            required=False,
        )
