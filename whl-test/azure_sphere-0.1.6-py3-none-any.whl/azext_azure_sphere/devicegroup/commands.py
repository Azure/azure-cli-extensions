"""This module provides the device group commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._client_factory import cf_device_group, cf_product
from azext_azure_sphere._exception_handler import cloud_exception_handler
from azext_azure_sphere.devicegroup.validators import (
    device_group_create_validator,
    device_group_update_validator,
)
from azure.cli.core.commands import CliCommandType


def load_device_group_command_table(self, _):
    """List of the device group commands and their configurations."""
    device_group_sdk = CliCommandType(
        operations_tmpl="azext_azure_sphere.sdk.asrm.azure.mgmt.azuresphere.operations#DeviceGroupsOperations.{}",  # pylint: disable=line-too-long
        client_factory=cf_device_group,
        exception_handler=cloud_exception_handler,
    )

    product_sdk = CliCommandType(
        operations_tmpl="azext_azure_sphere.sdk.asrm.azure.mgmt.azuresphere.operations#ProductsOperations.{}",  # pylint: disable=line-too-long
        client_factory=cf_product,
        exception_handler=cloud_exception_handler,
    )

    device_group_custom_type = CliCommandType(
        operations_tmpl="azext_azure_sphere.devicegroup.custom#{}",
        exception_handler=cloud_exception_handler,
    )

    with self.command_group(
        "sphere device-group",
        command_type=device_group_sdk,
        custom_command_type=device_group_custom_type,
    ) as ctx:
        ctx.custom_show_command("show", "get_device_group")
        ctx.custom_command("list", "list_device_group")
        ctx.custom_command("create", "create_device_group", validator=device_group_create_validator)
        ctx.custom_command(
            "update",
            "update_device_group",
            validator=device_group_update_validator,
        )
        ctx.command("delete", "begin_delete")

    with self.command_group(
        "sphere device-group",
        command_type=product_sdk,
    ) as ctx:
        ctx.command("create-defaults", "generate_default_device_groups")
