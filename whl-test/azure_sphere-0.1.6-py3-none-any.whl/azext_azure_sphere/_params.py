"""This module has a function to load arguments in common cloud commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._validators import (
    CATALOG_PARAM_LONG_NAME,
    CATALOG_PARAM_SHORT_NAME,
    OUTPUT_FILE_PARAM_LONG_NAME,
    OUTPUT_FILE_PARAM_SHORT_NAME,
    catalog_validator,
)


def load_core_catalog_arguments(self, _):
    """Load catalog argument for cloud commands."""
    with self.argument_context("") as context:
        context.ignore("skip")
        context.ignore("top")
        context.ignore("filter")
        context.ignore("maxpagesize")
        context.argument(
            "catalog_name",
            type=str,
            options_list=[CATALOG_PARAM_LONG_NAME, CATALOG_PARAM_SHORT_NAME],
            validator=catalog_validator,
            configured_default="sphere.catalog",
            help=(
                "The Azure Sphere Catalog in which to perform this operation. "
                "Specify Azure Sphere Catalog name. You can configure the default "
                "Azure Sphere Catalog using `az config set defaults.sphere.catalog=<name>`.  "
                "Values from: az sphere catalog list."
            ),
        )
        context.argument(
            "resource_group_name",
            type=str,
            options_list=["--resource-group", "-g"],
            configured_default="group",
            help=(
                "Name of the Azure resource group. You can configure the default "
                "group using `az config set defaults.group=<name>`.  Values from: az group list."
            ),
        )
        context.argument(
            "output_file",
            type=str,
            options_list=[OUTPUT_FILE_PARAM_LONG_NAME, OUTPUT_FILE_PARAM_SHORT_NAME],
            required=True,
        )
