"""This module provides client factories for cloud operations."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------
from azext_azure_sphere.sdk.asrm.azure.mgmt.azuresphere._azure_sphere_provider_client import (
    AzureSphereProviderClient,
)
from azure.cli.core.commands.client_factory import get_mgmt_service_client


def cf_azure_sphere(cli_ctx, *_):
    """Return an AzureSphereProviderClient."""
    return get_mgmt_service_client(cli_ctx, AzureSphereProviderClient)


def cf_product(cli_ctx, *_):
    """Return the product operation group."""
    return cf_azure_sphere(cli_ctx).products


def cf_catalog(cli_ctx, *_):
    """Return the catalog operation group."""
    return cf_azure_sphere(cli_ctx).catalogs


def cf_device_group(cli_ctx, *_):
    """Return the device group operation group."""
    return cf_azure_sphere(cli_ctx).device_groups


def cf_image(cli_ctx, *_):
    """Return the image operation group."""
    return cf_azure_sphere(cli_ctx).images


def cf_device(cli_ctx, *_):
    """Return the device operation group."""
    return cf_azure_sphere(cli_ctx).devices


def cf_certificate(cli_ctx, *_):
    """Return the certificate operation group."""
    return cf_azure_sphere(cli_ctx).certificates


def cf_deployment(cli_ctx, *_):
    """Return the deployment operation group."""
    return cf_azure_sphere(cli_ctx).deployments
