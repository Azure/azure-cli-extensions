"""This module provides the device commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere.device.custom import DEFAULT_VALUE
from azext_azure_sphere.devicegroup.params import DG_NAME_PARAM_LONG_NAME, DG_NAME_PARAM_SHORT_NAME
from azext_azure_sphere.helpers.argtypes import custom_boolean
from azext_azure_sphere.product.params import (
    PRODUCT_NAME_PARAM_LONG_NAME,
    PRODUCT_NAME_PARAM_SHORT_NAME,
)

CAPABILITY_FILE_PARAM_LONG_NAME = "--capability"
IMAGES_PARAM_LONG_NAME = "--images"
ENABLE_RT_CORE_DEBUGGING_LONG_NAME = "--enable-rt-core-debugging"
ENABLE_RR_CORE_DEBUGGING_SHORT_NAME = "-r"

DG_TARGET_NAME_PARAM_LONG_NAME = "--target-device-group"
PRODUCT_TARGET_NAME_PARAM_LONG_NAME = "--target-product"


def load_device_arguments(self, _):
    """Load arguments for device related commands."""
    with self.argument_context("") as context:
        context.ignore("cmd")
        context.ignore("cliv2_output")
        context.ignore("cliv2_arguments")
    self.argument_context("sphere device restart").extra("device_ip")
    with self.argument_context("sphere device") as ctx:
        ctx.argument(
            "product_name",
            type=str,
            options_list=[PRODUCT_NAME_PARAM_LONG_NAME, PRODUCT_NAME_PARAM_SHORT_NAME],
            required=True,
        )
        ctx.argument(
            "device_group_name",
            type=str,
            options_list=[DG_NAME_PARAM_LONG_NAME, DG_NAME_PARAM_SHORT_NAME],
            required=True,
        )

    with self.argument_context("sphere device assign") as ctx:
        ctx.argument(
            "product_target",
            type=str,
            options_list=[PRODUCT_TARGET_NAME_PARAM_LONG_NAME],
            required=True,
        )
        ctx.argument(
            "device_group_target",
            type=str,
            options_list=[DG_TARGET_NAME_PARAM_LONG_NAME],
            required=True,
        )

    with self.argument_context("sphere device unassign") as ctx:
        ctx.argument(
            "product_name",
            type=str,
            options_list=[PRODUCT_NAME_PARAM_LONG_NAME, PRODUCT_NAME_PARAM_SHORT_NAME],
            required=True,
        )
        ctx.argument(
            "device_group_name",
            type=str,
            options_list=[DG_NAME_PARAM_LONG_NAME, DG_NAME_PARAM_SHORT_NAME],
            required=True,
        )

    with self.argument_context("sphere device list") as ctx:
        ctx.argument(
            "product_name",
            type=str,
            options_list=[PRODUCT_NAME_PARAM_LONG_NAME, PRODUCT_NAME_PARAM_SHORT_NAME],
            required=False,
        )
        ctx.argument(
            "device_group_name",
            type=str,
            options_list=[DG_NAME_PARAM_LONG_NAME, DG_NAME_PARAM_SHORT_NAME],
            required=False,
        )

    with self.argument_context("sphere device claim") as ctx:
        ctx.argument(
            "product_name",
            type=str,
            options_list=[PRODUCT_NAME_PARAM_LONG_NAME, PRODUCT_NAME_PARAM_SHORT_NAME],
            required=False,
        )
        ctx.argument(
            "device_group_name",
            type=str,
            options_list=[DG_NAME_PARAM_LONG_NAME, DG_NAME_PARAM_SHORT_NAME],
            required=False,
        )

    with self.argument_context("sphere device show-count") as ctx:
        ctx.argument(
            "product_name",
            type=str,
            options_list=[PRODUCT_NAME_PARAM_LONG_NAME, PRODUCT_NAME_PARAM_SHORT_NAME],
            required=False,
        )
        ctx.argument(
            "device_group_name",
            type=str,
            options_list=[DG_NAME_PARAM_LONG_NAME, DG_NAME_PARAM_SHORT_NAME],
            required=False,
        )

    with self.argument_context("sphere device recover") as ctx:
        ctx.argument(
            "capability_file",
            type=str,
            options_list=[CAPABILITY_FILE_PARAM_LONG_NAME],
            required=False,
        )
        ctx.argument(
            "images_folder",
            type=str,
            options_list=[IMAGES_PARAM_LONG_NAME],
            required=False,
        )

    with self.argument_context("sphere device show") as ctx:
        ctx.argument(
            "product_name",
            type=str,
            default=DEFAULT_VALUE,
            options_list=[PRODUCT_NAME_PARAM_LONG_NAME, PRODUCT_NAME_PARAM_SHORT_NAME],
            required=False,
        )
        ctx.argument(
            "device_group_name",
            type=str,
            default=DEFAULT_VALUE,
            options_list=[DG_NAME_PARAM_LONG_NAME, DG_NAME_PARAM_SHORT_NAME],
            required=False,
        )

    with self.argument_context("sphere device enable-development") as ctx:
        ctx.argument(
            "product_name",
            type=str,
            options_list=[PRODUCT_NAME_PARAM_LONG_NAME, PRODUCT_NAME_PARAM_SHORT_NAME],
            required=False,
        )
        ctx.argument(
            "device_group_name",
            type=str,
            options_list=[DG_NAME_PARAM_LONG_NAME, DG_NAME_PARAM_SHORT_NAME],
            required=False,
        )
        ctx.argument(
            "enable_rt_core_debugging",
            arg_type=custom_boolean,
            options_list=[ENABLE_RT_CORE_DEBUGGING_LONG_NAME, ENABLE_RR_CORE_DEBUGGING_SHORT_NAME],
            required=False,
        )

    with self.argument_context("sphere device enable-cloud-test") as ctx:
        ctx.argument(
            "product_name",
            type=str,
            options_list=[PRODUCT_NAME_PARAM_LONG_NAME, PRODUCT_NAME_PARAM_SHORT_NAME],
            required=False,
        )
        ctx.argument(
            "device_group_name",
            type=str,
            options_list=[DG_NAME_PARAM_LONG_NAME, DG_NAME_PARAM_SHORT_NAME],
            required=False,
        )
