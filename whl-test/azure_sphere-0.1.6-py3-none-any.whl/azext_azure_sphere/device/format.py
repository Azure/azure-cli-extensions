"""Provides methods for transforming the format of device commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------
from knack.log import get_logger

logger = get_logger(__name__)


def transform_show_os_version_output(result):
    """Transform the output of show-os-version command."""
    os_versions_count = len(result)
    if os_versions_count == 1:
        result = {"osversion": result[0]}
    elif os_versions_count == 0:
        # If none, report "unknown".
        result = {"osversion": "unknown"}
    else:
        # If multiple, report "partial update".
        result = {"osversion": "partially updated"}
    return result
