"""This module provides the implementation of custom device commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------
import os
import time
from collections import OrderedDict
from typing import List

from azext_azure_sphere._client_factory import cf_catalog, cf_device, cf_device_group, cf_product
from azext_azure_sphere._client_factory_device import (
    cf_device_gatewayd,
    cf_image_gatewayd,
    cf_wifi_gatewayd,
)
from azext_azure_sphere.auto_detection.utils import get_device_id
from azext_azure_sphere.device.capability.custom import (
    download_capability_file_device,
    update_capability,
)
from azext_azure_sphere.device.image.custom import list_targeted_images
from azext_azure_sphere.device.sideload.custom import deploy_sideload_device
from azext_azure_sphere.device_comm.utils import get_count_attached_device, get_device_connections
from azext_azure_sphere.devicegroup.custom import get_device_group
from azext_azure_sphere.helpers.utils import (
    DEFAULT_VALUE,
    azsphere_combo_run,
    azsphere_run,
    check_device_restart_status,
    device_cloud_os_comparison,
    download_images_list,
    get_gdb_server_path,
    get_value_from_arm_id,
    show_os_version,
)
from azext_azure_sphere.helpers.utils_capabilities import check_device_capabilities
from azext_azure_sphere.helpers.utils_images import delete_images, get_all_component_ids_and_iids
from azext_azure_sphere.product.params import PRODUCT_NAME_PARAM_LONG_NAME
from azext_azure_sphere.sdk.asrm.azure.mgmt.azuresphere.models._azure_sphere_provider_client_enums import (
    UpdatePolicy,
)
from azext_azure_sphere.sdk.asrm.azure.mgmt.azuresphere.models._models import Device, DeviceUpdate
from azure.cli.core.commands import AzCliCommand
from azure.cli.core.commands.client_factory import get_subscription_id
from azure.core.exceptions import HttpResponseError, ServiceRequestError, ServiceResponseError
from azure.core.polling import LROPoller
from azuresphere_device_api import device, devices
from azuresphere_device_api.exceptions import DeviceError
from knack.log import get_logger
from knack.util import CLIError
from msrest.exceptions import ClientRequestError
from msrestazure.tools import resource_id
from semantic_version import Version

logger = get_logger(__name__)

DEFAULT_DG_APP_DEV_NAME = "Development"
DEFAULT_DG_CLOUD_TEST_NAME = "Field Test"


def assign_device(
    cmd: AzCliCommand,
    resource_group_name: str,
    catalog_name: str,
    device_name: str,
    device_group_target: str,
    product_target: str,
):
    """Assign a device in another device group (device assign)."""
    # Get device details
    device_product_name, device_device_group_name = get_device_details(
        cmd=cmd,
        resource_group_name=resource_group_name,
        catalog_name=catalog_name,
        device_id=device_name,
    )

    # Get device group id
    device_group_id_targeted = resource_id(
        subscription=get_subscription_id(cmd.cli_ctx),
        resource_group=resource_group_name,
        namespace="Microsoft.AzureSphere",
        type="catalogs",
        name=catalog_name,
        child_type_1="products",
        child_name_1=product_target,
        child_type_2="deviceGroups",
        child_name_2=device_group_target,
    )

    # Assign device
    try:
        properties = DeviceUpdate(device_group_id=device_group_id_targeted)
        device_client = cf_device(cmd.cli_ctx)
        response = device_client.begin_update(
            resource_group_name=resource_group_name,
            catalog_name=catalog_name,
            product_name=device_product_name,
            device_group_name=device_device_group_name,
            device_name=device_name,
            properties=properties,
        )
    except Exception as ex:
        raise CLIError(
            f"Failed to assign device '{device_name}' to the target product '{product_target}' and the target device group '{device_group_target}'. {ex}"
        ) from ex

    # Wait for the asynchronous function to finish executing
    while isinstance(response, LROPoller) and not response.done():
        time.sleep(1)

    # Get device data from the new place
    return device_client.get(
        resource_group_name=resource_group_name,
        catalog_name=catalog_name,
        product_name=product_target,
        device_group_name=device_group_target,
        device_name=device_name,
    )


def unassign_device(
    cmd: AzCliCommand,
    resource_group_name: str,
    catalog_name: str,
    device_name: str,
    product_name: str,
    device_group_name: str,
):
    """Unassign a device in another device group (device unassign)."""
    # unassign device
    device_group_id_targeted = resource_id(
        subscription=get_subscription_id(cmd.cli_ctx),
        resource_group=resource_group_name,
        namespace="Microsoft.AzureSphere",
        type="catalogs",
        name=catalog_name,
        child_type_1="products",
        child_name_1=DEFAULT_VALUE,
        child_type_2="deviceGroups",
        child_name_2=DEFAULT_VALUE,
    )
    properties = DeviceUpdate(device_group_id=device_group_id_targeted)
    device_client = cf_device(cmd.cli_ctx)
    response = device_client.begin_update(
        resource_group_name=resource_group_name,
        catalog_name=catalog_name,
        product_name=product_name,
        device_group_name=device_group_name,
        device_name=device_name,
        properties=properties,
    )

    # Wait for the asynchronous function to finish executing
    while isinstance(response, LROPoller) and not response.done():
        time.sleep(1)

    # Get device data from the new place
    return device_client.get(
        resource_group_name=resource_group_name,
        catalog_name=catalog_name,
        product_name=DEFAULT_VALUE,
        device_group_name=DEFAULT_VALUE,
        device_name=device_name,
    )


def claim_device(
    cmd: AzCliCommand,
    resource_group_name: str,
    catalog_name: str,
    device_name: str,
    product_name=DEFAULT_VALUE,
    device_group_name=DEFAULT_VALUE,
):
    """Claim a device in a catalog (device claim)."""
    resource = Device(device_id=device_name)
    device_client = cf_device(cmd.cli_ctx)
    return device_client.begin_create_or_update(
        resource_group_name,
        catalog_name,
        product_name,
        device_group_name,
        device_name,
        resource=resource,
    )


def list_devices(
    cmd: AzCliCommand,
    resource_group_name: str,
    catalog_name: str,
    product_name=None,
    device_group_name=None,
):
    """List devices from the resources provided by the user (device list)."""
    if not product_name and not device_group_name:
        catalog_client = cf_catalog(cmd.cli_ctx)
        return catalog_client.list_devices(
            resource_group_name,
            catalog_name,
        )

    if product_name and not device_group_name:
        filter_condition = f"product eq '{product_name}'"
        catalog_client = cf_catalog(cmd.cli_ctx)
        return catalog_client.list_devices(
            resource_group_name,
            catalog_name,
            filter=filter_condition,
        )

    if product_name and device_group_name:
        device_client = cf_device(cmd.cli_ctx)
        return device_client.list_by_device_group(
            resource_group_name, catalog_name, product_name, device_group_name
        )


def show_count_devices(
    cmd: AzCliCommand,
    resource_group_name: str,
    catalog_name: str,
    product_name=None,
    device_group_name=None,
):
    """Show count devices from the resources provided by the user (device show-count)."""
    if not product_name and not device_group_name:
        catalog_client = cf_catalog(cmd.cli_ctx)
        return catalog_client.count_devices(resource_group_name, catalog_name)

    if product_name and not device_group_name:
        product_client = cf_product(cmd.cli_ctx)
        return product_client.count_devices(resource_group_name, catalog_name, product_name)

    if product_name and device_group_name:
        device_group_client = cf_device_group(cmd.cli_ctx)
        return device_group_client.count_devices(
            resource_group_name, catalog_name, product_name, device_group_name
        )


def list_attached_devices(cmd: AzCliCommand):
    """Get list of attached devices (device list-attached)."""
    return_response = []

    # Get the list of attached devices.
    device_connections = get_device_connections()
    if len(device_connections) == 0:
        logger.warning("No attached devices.")
        return return_response

    unresponsive_message = "One or more devices are not responding and may be unresponsive if it is applying an Azure Sphere operating system update; please retry in a few minutes."
    is_unresponsive_device_found = False

    # For each device, get the device ID and then format the response.
    for device_connection in device_connections:
        try:
            security_state = {}
            devices.set_active_device_ip_address(device_connection.ip_address)
            security_state = device.get_device_security_state()

            info = OrderedDict()
            # for OS versions < 20.07 device_identifier == deviceIdentityPublicKey
            # device_identifier doesn't exist in the response
            if "deviceIdentifier" in security_state:
                info["deviceIdentifier"] = security_state["deviceIdentifier"]
            else:
                info["deviceIdentifier"] = security_state["deviceIdentityPublicKey"]
            info["isResponsive"] = True
            info["ipAddress"] = device_connection.ip_address
            info["deviceConnectionPath"] = device_connection.device_connection_path
            return_response.append(info)

        except Exception as ex:
            if not isinstance(ex, (DeviceError)):
                raise CLIError(ex) from ex

            is_unresponsive_device_found = True

            info = OrderedDict()
            info["deviceIdentifier"] = "Cannot get device ID"
            info["isResponsive"] = False
            info["ipAddress"] = device_connection.ip_address
            info["deviceConnectionPath"] = device_connection.device_connection_path
            return_response.append(info)

    if is_unresponsive_device_found:
        logger.error(unresponsive_message)

    return return_response


def recover_device(
    cliv2_output: str,
    cliv2_arguments: List[str],
    device_ip: str,
    capability_file: str = None,
    images_folder: str = None,
):
    """Recover device (device recover)."""
    azsphere_run(
        cliv2_arguments, None, device_ip
    )  # no output format provided (no json output available)


def rescan_attached_devices(cmd: AzCliCommand):
    """Get number of attached devices (device rescan-attached)."""
    count = get_count_attached_device()
    result = OrderedDict({"count": count})
    return result


def show_attached_device(cmd: AzCliCommand, device_ip: str):
    """Show-attached device (device show-attached)."""
    # Get the list of attached devices, filter out the device that matches device_ip and then convert
    # the filtered iterators to a list.
    device_connection_iterator_list = list(
        filter(lambda device: device.ip_address == device_ip, get_device_connections())
    )

    device_connection = device_connection_iterator_list[0]

    return_response = []

    security_state = {}
    devices.set_active_device_ip_address(device_connection.ip_address)
    security_state = device.get_device_security_state()

    if "deviceIdentifier" in security_state:
        device_id = security_state["deviceIdentifier"]
    else:
        device_id = security_state["deviceIdentityPublicKey"]

    info = OrderedDict()
    info["deviceIdentifier"] = device_id
    info["ipAddress"] = device_connection.ip_address
    info["deviceConnectionPath"] = device_connection.device_connection_path
    return_response.append(info)

    return return_response


def device_show_os_version(cmd: AzCliCommand, device_ip: str):
    """Show OS version on attached device (device show-os-version)."""
    device_os_versions = show_os_version(cmd=cmd, device_ip=device_ip)
    return device_os_versions


def restart_device(cmd: AzCliCommand, device_ip: str):
    """Restart device (device restart)."""
    client = cf_device_gatewayd(cmd.cli_ctx, device_ip=device_ip, connection_timeout=2)

    logger.warning("Restarting device.")
    try:
        client.device_restart_device()
    except HttpResponseError:
        raise CLIError("Could not restart device.")
    success_message = "Device restarted successfully."

    try:
        check_device_restart_status(client.device_get_device_status, 0.1, success_message, 10)
    except (ClientRequestError, ServiceRequestError, ServiceResponseError):
        raise CLIError("Timed out waiting for device to restart.")


def show_deployment_status_device(
    cmd: AzCliCommand,
    resource_group_name: str,
    catalog_name: str,
    device_ip: str,
):
    """Show deployment status device (device show-deployment-status)."""
    # Download the json file - az config set defaults.sphere.environment=<env>
    downloaded_images_list = download_images_list(cmd)

    # Get os version on the device
    device_os_version = show_os_version(
        cmd=cmd, device_ip=device_ip, downloaded_images_list=downloaded_images_list
    )

    cloud_os_version = "Unknown"
    device_id = get_device_id(device_ip)

    # Get cloud images - Get the targeted OS version
    get_images_response = list_targeted_images(
        cmd, resource_group_name, catalog_name, device_id, all=True
    )
    device_images_component_id_uid_list = get_all_component_ids_and_iids(list(get_images_response))

    # Check for a full match.
    # Find all known versions where every component/image pair has a match in the list of images on the device.
    fully_matched_list = []
    for version in downloaded_images_list["versions"]:
        if all(x in device_images_component_id_uid_list for x in version["images"]):
            fully_matched_list.append(version["name"])

    # If we have any full matches, return only the last one (most recent)
    if len(fully_matched_list) > 0:
        cloud_os_version = fully_matched_list[-1]

    # Wifi status
    client = cf_wifi_gatewayd(cmd.cli_ctx, device_ip=device_ip)
    wifi_status_response = client.wifi_get_wifi_interface_state()

    wifi_status = ""
    if wifi_status_response.connection_state:
        wifi_status = wifi_status_response.connection_state

    if str.lower(wifi_status) == "connected":
        wifi_message = "Your device is connected to Wi-Fi. If the over-the-air update does not begin, reset your device and try again."
    elif str.lower(wifi_status) == "disconnected":
        wifi_message = "Your device is not connected to Wi-Fi. Your device may be connected via Ethernet. If not, please check the Wi-Fi configuration on your device and try again."
    else:
        wifi_message = "Your device's Wi-Fi status could not be checked."

    # Device and cloud comparaison
    if device_os_version and cloud_os_version:
        return device_cloud_os_comparison(device_os_version, cloud_os_version, wifi_message)


def enable_development_device(
    cmd: AzCliCommand,
    resource_group_name: str,
    catalog_name: str,
    device_ip: str,
    product_name=None,
    device_group_name=None,
    enable_rt_core_debugging: bool = False,
):
    """Enable development device (device enable-development)."""
    device_id = get_device_id(device_ip)

    try:
        # get device details (product and device group)
        device_product_name, device_device_group_name = get_device_details(
            cmd=cmd,
            resource_group_name=resource_group_name,
            catalog_name=catalog_name,
            device_id=device_id,
        )
    except Exception as ex:
        logger.error("Could not get device configuration.")
        raise CLIError(
            f"Failed to set up device '{device_id}' for application development. \n{ex}"
        ) from ex

    # if not product provided by the user, the device's product is used
    if not product_name:
        product_name = device_product_name

    # if no device group provided by the user, the default device group is used
    if not device_group_name:
        device_group_name = DEFAULT_DG_APP_DEV_NAME

    # if the device is assigned to a product
    if product_name != DEFAULT_VALUE:
        # DG details and Update Policy
        try:
            device_group_details = get_device_group(
                cmd=cmd,
                resource_group_name=resource_group_name,
                catalog_name=catalog_name,
                product_name=product_name,
                device_group_name=device_group_name,
            )
        except Exception as ex:
            logger.error(
                f"The device group \"{device_group_name}\" does not exist. Run 'az sphere device-group create' to create the device group and then retry."
            )
            raise CLIError(
                f"Failed to set up device '{device_id}' for application development."
            ) from ex

        if device_group_details.update_policy != UpdatePolicy.NO3_RD_PARTY_APP_UPDATES:
            logger.error(
                "The specified device group does not restrict application updates. Please provide a different device group."
            )
            raise CLIError(f"Failed to set up device '{device_id}' for application development.")

        logger.warning(
            f"Setting device group to '{device_group_name}' for product '{product_name}'."
        )

    # Enable RT Core debugging
    # construct azsphere command
    if enable_rt_core_debugging:
        combo_arguments = ["azsphere", "device", "internal-enable-development"]
        combo_arguments.append("--enable-rt-core-debugging")
        azsphere_combo_run(combo_arguments)

    # download capability file with ApplicationDevelopment capability
    try:
        capability_file_path = "appdev_file.cap"
        download_capability_file_device(
            cmd=cmd,
            resource_group_name=resource_group_name,
            catalog_name=catalog_name,
            product_name=device_product_name,
            device_group_name=device_device_group_name,
            device_name=device_id,
            output_file=capability_file_path,
            capabilities_type=["ApplicationDevelopment"],
        )
    except Exception as ex:
        logger.error("Download capability failure.")
        raise CLIError(
            f"Failed to set up device '{device_id}' for application development. {ex}"
        ) from ex

    # DEVICE
    # Check capabilities
    output_capabilities = []
    device_capabilities = show_attached_capability_device(cmd=cmd, device_ip=device_ip)
    is_cap_app_dev, is_internal_cap = check_device_capabilities(device_capabilities)

    if is_cap_app_dev:
        output_capabilities.append("EnableAppDevelopment")
        logger.warning(
            "The device already has the 'EnableAppDevelopment' capability. No changes will be applied to its existing capabilities."
        )
    elif is_internal_cap:
        output_capabilities.append("Internal")
        logger.error(
            "This action cannot be completed because your device does not have the 'EnableAppDevelopment' capability, but it does have one or more internal capabilities enabled, which this command would remove. Please recreate the internal capability for your device to include 'EnableAppDevelopment'."
        )
        raise CLIError(f"Failed to set up device '{device_id}' for application development.")
    else:
        # Apply capability ApplicationDevelopment
        logger.warning("Enabling application development capability on attached device.")
        update_capability(
            cmd=cmd, device_ip=device_ip, capability_file=capability_file_path, header=True
        )
        output_capabilities.append("EnableAppDevelopment")
        logger.warning("Application development capability enabled.")
        logger.warning("The device is rebooting.")

    # CLOUD
    # move device to the targeted product and device group
    if product_name == DEFAULT_VALUE or (
        product_name == device_product_name and device_group_name == device_device_group_name
    ):
        logger.warning("Application updates have already been disabled for this device.")
    else:
        try:
            assign_device(
                cmd=cmd,
                resource_group_name=resource_group_name,
                catalog_name=catalog_name,
                product_target=product_name,
                device_group_target=device_group_name,
                device_name=device_id,
            )
            logger.warning("Successfully disabled application updates.")
        except Exception as ex:
            logger.error("Could not assign device.")
            raise CLIError(
                f"Failed to set up device '{device_id}' for application development. {ex}"
            ) from ex

    # DEVICE
    # Sideload GDB server
    logger.warning("Installing debugging server to device.")
    gdb_server_path = get_gdb_server_path()
    logger.warning(f"Deploying '{gdb_server_path}' to the attached device.")
    deploy_sideload_device(cmd=cmd, image_package=gdb_server_path, device_ip=device_ip)
    logger.warning(f"Image package '{gdb_server_path}' has been deployed to the attached device.")

    # Delete capability file
    if os.path.exists(capability_file_path):
        os.remove(capability_file_path)

    logger.warning(
        f"Successfully set up device for application development, and disabled application updates.\n(Device ID: '{device_id}')"
    )

    item = OrderedDict()
    item["deviceId"] = device_id
    item["productName"] = product_name
    item["deviceGroupName"] = device_group_name
    item["capabilities"] = output_capabilities

    return item


def enable_cloud_test(
    cmd: AzCliCommand,
    resource_group_name: str,
    catalog_name: str,
    device_ip: str,
    product_name=None,
    device_group_name=None,
):
    """Enable cloud test device (device enable-cloud-test)."""
    device_id = get_device_id(device_ip)
    # CLOUD
    try:
        # get device details (product and device group)
        device_product_name, device_device_group_name = get_device_details(
            cmd=cmd,
            resource_group_name=resource_group_name,
            catalog_name=catalog_name,
            device_id=device_id,
        )
    except Exception as ex:
        logger.error("Could not get device configuration.")
        raise CLIError(
            f"Failed to set up device '{device_id}' for application updates. {ex}"
        ) from ex

    # Check Product and Device Group (Default DG "Field Test")
    # if not product provided by the user, the device's product is used
    if not product_name:
        if device_product_name and device_product_name != DEFAULT_VALUE:
            product_name = device_product_name
        elif device_product_name and device_product_name == DEFAULT_VALUE:
            logger.error(
                f"Your device does not belong to a product. Use the parameter '{PRODUCT_NAME_PARAM_LONG_NAME}' to specify the target product name."
            )
            raise CLIError(f"Failed to set up device '{device_id}' for application updates.")

    # if no device group provided by the user, the default device group is used
    if not device_group_name:
        device_group_name = DEFAULT_DG_CLOUD_TEST_NAME

    # Check DG Update Policy
    try:
        device_group_details = get_device_group(
            cmd=cmd,
            resource_group_name=resource_group_name,
            catalog_name=catalog_name,
            product_name=product_name,
            device_group_name=device_group_name,
        )
    except Exception as ex:
        if device_group_name == DEFAULT_DG_CLOUD_TEST_NAME:
            logger.error(
                f"The device group \"{device_group_name}\" does not exist. Run 'az sphere device-group create' to create the device group and then retry."
            )
        raise CLIError(f"Failed to set up device '{device_id}' for application updates.") from ex

    if device_group_details.update_policy != UpdatePolicy.UPDATE_ALL:
        logger.error(
            f"The specified device group '{device_group_name}' does not support application updates. Please provide a different device group."
        )
        raise CLIError(f"Failed to set up device '{device_id}' for application updates.")

    logger.warning(f"Setting device group to '{device_group_name}' for product '{product_name}'.")

    # DEVICE
    # Check capabilities
    device_capabilities = show_attached_capability_device(cmd=cmd, device_ip=device_ip)
    is_cap_app_dev, is_internal_cap = check_device_capabilities(device_capabilities)
    output_capabilities = []
    if is_cap_app_dev:
        output_capabilities.append("EnableAppDevelopment")
    if is_internal_cap:
        output_capabilities.append("Internal")

    # Get images
    images_client = cf_image_gatewayd(cmd.cli_ctx, device_ip=device_ip)
    get_images_response = images_client.images_get_images()

    # Sideload delete Application
    if is_cap_app_dev and not is_internal_cap:
        logger.warning("Removing applications from device.")
        logger.warning("Removing debugging server from device (if installed).")
        delete_images(
            cmd=cmd,
            device_ip=device_ip,
            get_images_response=get_images_response,
            delete_gdb_server_image=True,
        )
        logger.warning("Successfully removed applications from device.")
    else:
        logger.warning("Leaving any existing applications on the device.")

    # Check device capabilities
    if not is_cap_app_dev:
        logger.warning(
            "The device doesn't have the 'EnableAppDevelopment' capability. No changes will be applied to its existing capabilities."
        )
    elif not is_internal_cap:
        # Download capability None
        try:
            # download capability file with None capability
            capability_file_path = "none_file.cap"
            download_capability_file_device(
                cmd,
                resource_group_name=resource_group_name,
                catalog_name=catalog_name,
                product_name=device_product_name,
                device_group_name=device_device_group_name,
                device_name=device_id,
                output_file=capability_file_path,
            )
        except Exception as ex:
            logger.error(f"Capability failure. {ex}")
            raise CLIError(
                f"Failed to set up device '{device_id}' for application updates."
            ) from ex

        # Apply capability None
        logger.warning("Locking device.")
        update_capability(cmd=cmd, device_ip=device_ip, capability_file=capability_file_path)
        output_capabilities = ["None"]
        logger.warning("Successfully locked device.")

        # Delete capability file
        if os.path.exists(capability_file_path):
            os.remove(capability_file_path)

    # CLOUD
    # Move device
    try:
        assign_device(
            cmd=cmd,
            resource_group_name=resource_group_name,
            catalog_name=catalog_name,
            product_target=product_name,
            device_group_target=device_group_name,
            device_name=device_id,
        )
        logger.warning("Successfully updated device's device group.")
    except Exception as ex:
        logger.error("Could not assign device.")
        raise CLIError(ex) from ex

    logger.warning(
        f"Successfully set up device for application updates.\n(Device ID: '{device_id}')"
    )

    item = OrderedDict()
    item["deviceId"] = device_id
    item["productName"] = product_name
    item["deviceGroupName"] = device_group_name
    item["capabilities"] = output_capabilities

    return item


def show_attached_capability_device(cmd, device_ip):
    """Show attached capability device."""
    device_client = cf_device_gatewayd(cmd.cli_ctx, device_ip=device_ip)
    device_capabilities = device_client.device_get_device_capabilities()
    return device_capabilities


def get_device_details(cmd, resource_group_name, catalog_name, device_id):
    """Get device details."""
    filter_condition = f"name eq '{device_id}'"
    catalog_client = cf_catalog(cmd.cli_ctx)
    response_device_details = catalog_client.list_devices(
        resource_group_name, catalog_name, filter=filter_condition
    )
    device_details = list(response_device_details)
    if len(device_details) == 1:
        device_product_name = get_value_from_arm_id(device_details[0].id, "products")
        device_device_group_name = get_value_from_arm_id(device_details[0].id, "deviceGroups")
        return device_product_name, device_device_group_name
    else:
        raise Exception("No devices found.")
