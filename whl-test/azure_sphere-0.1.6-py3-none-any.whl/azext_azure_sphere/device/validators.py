"""This module provides the device validator."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

import os
from argparse import Namespace

from azext_azure_sphere._validators import destination_file_validator
from azext_azure_sphere.auto_detection.params import DEVICE_PARAM_LONG_NAME, DEVICE_PARAM_SHORT_NAME
from azext_azure_sphere.auto_detection.validators import device_ip_validator, device_name_validator
from azext_azure_sphere.devicegroup.params import DG_NAME_PARAM_LONG_NAME, DG_NAME_PARAM_SHORT_NAME
from azext_azure_sphere.helpers.utils import (
    check_minimum_sdk_version_number,
    get_install_doc_link,
    is_cloudshell,
    is_device_id,
    is_sdk_installed,
)
from azext_azure_sphere.product.params import (
    PRODUCT_NAME_PARAM_LONG_NAME,
    PRODUCT_NAME_PARAM_SHORT_NAME,
)
from azure.cli.core.commands import AzCliCommand
from knack.util import CLIError


def cloud_commands_device_validator(namespace: Namespace):
    """Validate that the cloud command can be executed
    To be used for cloud commands that do not have --device/-d as an input argument.
    """

    # Auto-detection feature needs to talk to the Device Communication service. Hence auto-detection
    # of --device/-d does not work when in cloud shell, or if Azure Sphere SDK is not installed.
    # However, cloud commands should always run.
    # Hence if --device/-d is not specified, then raise an error telling the user to manually input
    # the --device/-d.
    if is_cloudshell():
        if namespace.device_name is None:
            raise CLIError(
                f"You must provide a Device ID for {DEVICE_PARAM_LONG_NAME}/{DEVICE_PARAM_SHORT_NAME} when running this command in Cloud Shell."
            )
        elif not is_device_id(namespace.device_name):
            raise CLIError(
                f"The {DEVICE_PARAM_LONG_NAME} '{namespace.device_name}' parameter is invalid. Verify that it is 128 characters long and contains only hexadecimal characters."
            )
    elif not is_sdk_installed():
        if namespace.device_name is None:
            raise CLIError(
                f"Azure Sphere SDK is not installed. You must provide a Device ID for {DEVICE_PARAM_LONG_NAME}/{DEVICE_PARAM_SHORT_NAME}."
            )
        elif not is_device_id(namespace.device_name):
            raise CLIError(
                f"The {DEVICE_PARAM_LONG_NAME} '{namespace.device_name}' parameter is invalid. Verify that it is 128 characters long and contains only hexadecimal characters."
            )
    else:
        device_name_validator(namespace)


def destination_file_cap_validator(namespace: Namespace):
    """Validate the destination parameter."""
    cloud_commands_device_validator(namespace)
    if not namespace.output_file:
        directory = os.getcwd()
        device_id = namespace.device_name

        if not namespace.capabilities_type:
            prefix = "none-"
        else:
            prefix = ""
            for capa in namespace.capabilities_type:
                prefix += capa + "-"

        output_file = prefix + device_id[0:8] + ".cap"
        namespace.output_file = os.path.join(directory, output_file)

    destination_file_validator(namespace, allow_overwrite=True)


def destination_file_zip_validator(cmd: AzCliCommand, namespace: Namespace):
    """Validate the --output-file parameter with .zip extension."""
    device_commands_common_validator(cmd, namespace)
    destination_file_validator(namespace, ".zip", allow_extension_correction=True)


def device_parameters_validator(namespace: Namespace):
    """Validate parameters are provided correctly for device commands (product and device group)."""
    if namespace.product_name and namespace.product_name.isspace():
        namespace.product_name = None

    if namespace.device_group_name and namespace.device_group_name.isspace():
        namespace.device_group_name = None

    if (
        not namespace.product_name or namespace.product_name.isspace()
    ) and namespace.device_group_name:
        raise CLIError(
            f"The parameter {PRODUCT_NAME_PARAM_LONG_NAME}/{PRODUCT_NAME_PARAM_SHORT_NAME}"
            + " must be provided with the parameter "
            + f"{DG_NAME_PARAM_LONG_NAME}/{DG_NAME_PARAM_SHORT_NAME}."
        )


def device_commands_common_validator(cmd: AzCliCommand, namespace: Namespace):
    """Validate that the device command can be executed.
    To be used for device commands that are implemented in the extension CLI and do not have --device/-d as an input argument.
    """

    # Device commands are run via CLIv2. ClIv2 needs the Azure Sphere SDK to be installed. Hence
    # device commands cannot not run if the SDK is not installed or commands are executed in cloud shell.
    if is_cloudshell():
        raise CLIError("Azure Sphere Device commands are not available on Azure Cloud Shell.")

    if not is_sdk_installed():
        aka_ms_link = get_install_doc_link()
        raise CLIError(
            f"Please install the Azure Sphere SDK. See {aka_ms_link} for more information."
        )


def device_commands_device_validator(cmd: AzCliCommand, namespace: Namespace):
    """Validate the device_ip parameter in addition to device_commands_common_validator validation.
    To be used for device commands that re implemented in the extension CLI and have --device/-d as an input argument.
    """
    device_commands_common_validator(cmd, namespace)

    device_ip_validator(cmd, namespace)


def device_commands_cliv2_common_validator(cmd: AzCliCommand, namespace: Namespace):
    """Validate that the device command can be executed, and update the output format for the command
    and save the input CLI arguments.
    To be used for device commands that do not have --device/-d as an input argument.
    """

    # Device commands are run via CLIv2. ClIv2 needs the Azure Sphere SDK to be installed. Hence
    # device commands cannot not run if the SDK is not installed or commands are executed in cloud shell.
    if is_cloudshell():
        raise CLIError("Azure Sphere Device commands are not available on Azure Cloud Shell.")

    aka_ms_link = get_install_doc_link()
    if not is_sdk_installed():
        raise CLIError(
            f"Please install the Azure Sphere SDK. See {aka_ms_link} for more information."
        )
    else:
        result = check_minimum_sdk_version_number()
        if not result:
            raise CLIError(
                f"The Azure Sphere SDK installed doesn't meet the requirement. Please install the latest Azure Sphere SDK (minimum version 23.05). See {aka_ms_link} for more information."
            )

    if namespace._output_format:  # pylint: disable=protected-access
        namespace.cliv2_output = namespace._output_format  # pylint: disable=protected-access
    namespace.cliv2_arguments = cmd.table_transformer


def device_commands_cliv2_device_validator(cmd: AzCliCommand, namespace: Namespace):
    """Validate the device_ip parameter in addition to device_commands_cliv2_common_validator validation.
    To be used for device commands that have --device/-d as an input argument.
    """
    device_commands_cliv2_common_validator(cmd, namespace)

    device_ip_validator(cmd, namespace)
