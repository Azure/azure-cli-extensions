"""This module provides the device commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._client_factory import cf_device
from azext_azure_sphere._exception_handler import (
    cloud_exception_handler,
    combo_commands_exception_handler,
    device_exception_handler,
)
from azext_azure_sphere.device.format import transform_show_os_version_output
from azext_azure_sphere.device.validators import (
    cloud_commands_device_validator,
    device_commands_cliv2_device_validator,
    device_commands_common_validator,
    device_commands_device_validator,
    device_parameters_validator,
)
from azext_azure_sphere.helpers.utils import get_query_param_value
from azure.cli.core.commands import CliCommandType


def load_device_command_table(self, _):
    """List of the device commands and their configurations."""
    device_sdk = CliCommandType(
        operations_tmpl="azext_azure_sphere.sdk.asrm.azure.mgmt.azuresphere.operations#DevicesOperations.{}",  # pylint: disable=line-too-long
        client_factory=cf_device,
        exception_handler=cloud_exception_handler,
    )

    device_custom_type = CliCommandType(
        operations_tmpl="azext_azure_sphere.device.custom#{}",
        exception_handler=cloud_exception_handler,
    )

    with self.command_group(
        "sphere device", command_type=device_sdk, custom_command_type=device_custom_type
    ) as ctx:
        ctx.custom_command("list", "list_devices", validator=device_parameters_validator)
        ctx.custom_command(
            "show-count", "show_count_devices", validator=device_parameters_validator
        )
        ctx.show_command("show", "get", validator=cloud_commands_device_validator)
        ctx.custom_command("assign", "assign_device", validator=cloud_commands_device_validator)
        ctx.custom_command("unassign", "unassign_device", validator=cloud_commands_device_validator)
        ctx.custom_command("claim", "claim_device", validator=cloud_commands_device_validator)

    with self.command_group("sphere device", custom_command_type=device_custom_type) as ctx:
        ctx.custom_command(
            "list-attached",
            "list_attached_devices",
            exception_handler=device_exception_handler,
            validator=device_commands_common_validator,
        )
        ctx.custom_command(
            "recover",
            "recover_device",
            validator=device_commands_cliv2_device_validator,
            table_transformer=get_query_param_value(_),
        )
        ctx.custom_command(
            "rescan-attached",
            "rescan_attached_devices",
            exception_handler=device_exception_handler,
            validator=device_commands_common_validator,
        )
        ctx.custom_command(
            "show-attached",
            "show_attached_device",
            exception_handler=device_exception_handler,
            validator=device_commands_device_validator,
        )
        ctx.custom_command(
            "show-os-version",
            "device_show_os_version",
            exception_handler=device_exception_handler,
            validator=device_commands_device_validator,
            transform=transform_show_os_version_output,
        )
        ctx.custom_command(
            "restart",
            "restart_device",
            validator=device_commands_device_validator,
        )
        ctx.custom_command(
            "show-deployment-status",
            "show_deployment_status_device",
            validator=device_commands_device_validator,
        )
        ctx.custom_command(
            "enable-development",
            "enable_development_device",
            exception_handler=combo_commands_exception_handler,
            validator=device_commands_device_validator,
        )
        ctx.custom_command(
            "enable-cloud-test",
            "enable_cloud_test",
            exception_handler=combo_commands_exception_handler,
            validator=device_commands_device_validator,
        )
