"""This module provides the device network commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

INTERFACE_PARAM_NAME = "--interface"
NETWORK_PARAM_LONG_NAME = "--network"
NETWORK_PARAM_SHORT_NAME = "-n"
HARDWARE_ADDRESS_PARAM_NAME = "--hardware-address"


def load_device_network_arguments(self, _):
    """Load arguments for device network related commands."""
    self.argument_context("sphere device network show-status").extra("device_ip")
    self.argument_context("sphere device network list-firewall-rules").extra("device_ip")
    self.argument_context("sphere device network update-interface").extra("device_ip")
    self.argument_context("sphere device network enable").extra("device_ip")
    self.argument_context("sphere device network disable").extra("device_ip")
    self.argument_context("sphere device network list-interfaces").extra("device_ip")
    self.argument_context("sphere device network show-diagnostics").extra("device_ip")
    with self.argument_context("sphere device network enable") as ctx:
        ctx.argument(
            "interface",
            type=str,
            options_list=[INTERFACE_PARAM_NAME],
            required=True,
        )

    with self.argument_context("sphere device network disable") as ctx:
        ctx.argument(
            "interface",
            type=str,
            options_list=[INTERFACE_PARAM_NAME],
            required=True,
        )

    with self.argument_context("sphere device network show-diagnostics") as ctx:
        ctx.argument(
            "network",
            type=int,
            options_list=[NETWORK_PARAM_LONG_NAME, NETWORK_PARAM_SHORT_NAME],
            required=False,
        )

    with self.argument_context("sphere device network update-interface") as ctx:
        ctx.argument(
            "hardware_address",
            type=str,
            options_list=[HARDWARE_ADDRESS_PARAM_NAME],
            required=True,
        )
        ctx.argument(
            "interface",
            type=str,
            options_list=[INTERFACE_PARAM_NAME],
            required=True,
        )
