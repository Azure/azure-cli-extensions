"""This module provides the implementation of custom device network proxy commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from typing import List

from azext_azure_sphere._client_factory_device import cf_network_gatewayd
from azext_azure_sphere.helpers.utils import set_network_proxy_body
from azure.cli.core.commands import AzCliCommand
from knack.log import get_logger
from knack.util import CLIError

logger = get_logger(__name__)


def apply_network_proxy_device(
    cmd: AzCliCommand,
    device_ip: str,
    address: str = None,
    authentication: str = None,
    port: str = None,
    enable=False,
    no_proxy_addresses: List[str] = [],
    password: str = None,
    username: str = None,
):
    """Configure the network proxy on the attached device."""
    body = set_network_proxy_body(
        authentication=authentication,
        enable=enable,
        address=address,
        port=port,
        no_proxy_addresses=no_proxy_addresses,
        username=username,
        password=password,
    )
    client = cf_network_gatewayd(cmd.cli_ctx, device_ip=device_ip)
    return client.net_config_network_proxy(body)


def disable_network_proxy_device(cmd: AzCliCommand, device_ip: str):
    """Disable the network proxy on the attached device."""
    return enable_disable_proxy(cmd=cmd, device_ip=device_ip, enable=False)


def enable_network_proxy_device(cmd: AzCliCommand, device_ip: str):
    """Enable the network proxy on the attached device."""
    return enable_disable_proxy(cmd=cmd, device_ip=device_ip, enable=True)


def get_network_proxy_details(cmd: AzCliCommand, device_ip: str):
    """Get the network proxy configuration on the attached device."""
    client = cf_network_gatewayd(cmd.cli_ctx, device_ip=device_ip)
    response = client.net_get_net_proxy()

    if not response:
        raise CLIError("No network proxy configured on the attached device.")

    return response


def enable_disable_proxy(cmd, device_ip, enable: bool):
    """Enable or disable the network proxy on the attached device."""
    proxy_details = get_network_proxy_details(cmd=cmd, device_ip=device_ip)

    authentication = proxy_details["authenticationType"]

    # username and password are only required for basic authentication
    # check previously done in validator
    username = proxy_details["username"] if "username" in proxy_details else None
    password = proxy_details["password"] if "password" in proxy_details else None

    body = set_network_proxy_body(
        authentication=authentication,
        enable=enable,
        address=proxy_details["address"],
        port=proxy_details["port"],
        no_proxy_addresses=proxy_details["noProxyAddresses"],
        username=username,
        password=password,
    )
    client = cf_network_gatewayd(cmd.cli_ctx, device_ip=device_ip)
    return client.net_config_network_proxy(body)
