"""This module provides the device network proxy validator."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from argparse import Namespace

from azext_azure_sphere.device.validators import device_commands_device_validator
from azext_azure_sphere.sdk.azure_sphere_gatewayd.azure.sphere.gatewayd.models import (
    NetworkProxyAuthenticationType,
)
from azure.cli.core.commands import AzCliCommand
from knack.cli import CLIError


def device_network_apply_proxy_validator(cmd: AzCliCommand, namespace: Namespace):
    """Validate the device network add-proxy command."""
    device_commands_device_validator(cmd, namespace)

    if namespace.authentication == NetworkProxyAuthenticationType.BASIC:
        if not (namespace.username and namespace.password):
            raise CLIError("Set both --username/-u and --password/-p for basic authentication.")

    elif namespace.authentication == NetworkProxyAuthenticationType.ANONYMOUS:
        if namespace.username or namespace.password:
            raise CLIError(
                "Do not set --username/-u or --password/-p for anonymous authentication."
            )
