"""This module provides the device network proxy commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._client_factory_device import cf_network_gatewayd
from azext_azure_sphere._exception_handler import device_exception_handler
from azext_azure_sphere.device.network.proxy.exception_handler import (
    device_network_apply_proxy_exception_handler,
)
from azext_azure_sphere.device.network.proxy.format import transform_network_proxy_show_output
from azext_azure_sphere.device.network.proxy.validators import device_network_apply_proxy_validator
from azext_azure_sphere.device.validators import device_commands_device_validator
from azure.cli.core.commands import CliCommandType


def load_device_network_proxy_command_table(self, _):
    """List of the device network proxy commands and their configurations."""
    network_sdk = CliCommandType(
        operations_tmpl="azext_azure_sphere.sdk.azure_sphere_gatewayd.azure.sphere.gatewayd.operations#NetOperations.{}",  # pylint: disable=line-too-long
        client_factory=cf_network_gatewayd,
        exception_handler=device_exception_handler,
    )

    device_network_proxy_custom_type = CliCommandType(
        operations_tmpl="azext_azure_sphere.device.network.proxy.custom#{}",
        exception_handler=device_exception_handler,
    )

    with self.command_group(
        "sphere device network proxy",
        command_type=network_sdk,
        custom_command_type=device_network_proxy_custom_type,
    ) as ctx:
        ctx.custom_command(
            "apply",
            "apply_network_proxy_device",
            validator=device_network_apply_proxy_validator,
            exception_handler=device_network_apply_proxy_exception_handler,
        )
        ctx.custom_command(
            "disable",
            "disable_network_proxy_device",
        )
        ctx.custom_command(
            "enable",
            "enable_network_proxy_device",
        )
        ctx.command(
            "delete",
            "net_delete_network_proxy",
            validator=device_commands_device_validator,
        )
        ctx.command(
            "show",
            "net_get_net_proxy",
            validator=device_commands_device_validator,
            transform=transform_network_proxy_show_output,
        )
