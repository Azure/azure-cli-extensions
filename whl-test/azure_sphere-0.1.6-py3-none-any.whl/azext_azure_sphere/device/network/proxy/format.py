"""Provides methods for transforming the format of device network proxy commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

from knack.log import get_logger

logger = get_logger(__name__)


def transform_network_proxy_show_output(result):
    """Transform the device network proxy show command table output."""
    if len(result) == 0:
        logger.warning("No proxy found.")
        return {}
    else:
        return result
