"""Provides methods for transforming the format of device network commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

from collections import OrderedDict
from typing import List

from knack.log import get_logger

logger = get_logger(__name__)


def transform_network_enable_disable_output(result):
    """Transform the network enable disable command table output."""
    message = (
        "Network interface configuration is successfully applied to the device. \n"
        "Run the command 'az sphere device network list-interfaces' to view details "
        "of the network interfaces for the attached device."
    )
    logger.warning(message)
    return []


def transform_network_list_firewall_rules_table_output(result) -> List[OrderedDict]:
    """Transform the network list-firewall-rules command table output."""
    table_output = []

    for item in result["rulesets"]:
        if len(item["rules"]) == 0:
            table_row = OrderedDict()
            table_row["ruleset"] = item["hook"]
            table_row["isValid"] = item["isValid"]
            table_output.append(table_row)
        elif len(item["rules"]) > 0:
            for rule in item["rules"]:
                table_row = OrderedDict()
                table_row["ruleset"] = item["hook"]
                table_row["isValid"] = item["isValid"]
                table_row["sourceIp"] = rule["sourceIp"]
                table_row["sourceMask"] = rule["sourceMask"]
                table_row["destinationIp"] = rule["destinationIp"]
                table_row["destinationMask"] = rule["destinationMask"]
                table_row["UID"] = rule["uid"]
                table_row["action"] = rule["action"]
                table_row["interfaceInName"] = rule["interfaceInName"]
                table_row["interfaceOutName"] = rule["interfaceOutName"]
                table_row["state"] = rule["state"] if rule["state"] != "none" else None
                table_row["tcpMask"] = ",".join(rule["tcpMask"])
                table_row["tcpCmp"] = ",".join(rule["tcpCmp"])
                table_row["tcpInv"] = rule["tcpInv"]
                table_row["protocol"] = rule["protocol"]
                table_row["sourcePortRange"] = (
                    (
                        str(rule["sourcePortRange"]["min"])
                        + "-"
                        + str(rule["sourcePortRange"]["max"])
                    )
                    if rule["sourcePortRange"]
                    else None
                )
                table_row["destinationPortRange"] = (
                    (
                        str(rule["destinationPortRange"]["min"])
                        + "-"
                        + str(rule["destinationPortRange"]["max"])
                    )
                    if rule["destinationPortRange"]
                    else None
                )
                table_row["packets"] = rule["packets"]
                table_row["bytes"] = rule["bytes"]
                table_output.append(table_row)

    return table_output


def transform_network_show_diagnostics_output(result):
    """Transform the device network show-diagnostics command."""
    if isinstance(result, List):
        if len(result) == 0:
            logger.warning("No errors logged.")
        return result
    else:
        return result
