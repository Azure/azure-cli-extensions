"""This module provides the implementation of custom device network commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.

from azext_azure_sphere._client_factory_device import cf_network_gatewayd, cf_wifi_gatewayd
from azext_azure_sphere.sdk.azure_sphere_gatewayd.azure.sphere.gatewayd.models import (
    Paths1Rr83LzNetInterfacesNetworkinterfacenamePatchRequestbodyContentApplicationJsonSchema,
)
from azure.cli.core.commands import AzCliCommand
from knack.cli import CLIError
from knack.log import get_logger

logger = get_logger(__name__)


def enable_device_network(cmd: AzCliCommand, device_ip: str, interface: str):
    """Enable a network's interface (device network enable)."""
    return set_body_update_interface(cmd, device_ip, interface, interface_up=True)


def disable_device_network(cmd: AzCliCommand, device_ip: str, interface: str):
    """Disable a network's interface (device network disable)."""
    return set_body_update_interface(cmd, device_ip, interface, interface_up=False)


def set_body_update_interface(
    cmd: AzCliCommand,
    device_ip: str,
    interface: str,
    hardware_address: str = None,
    interface_up: bool = None,
):
    """Set body parameter for network update interface."""
    body = (
        Paths1Rr83LzNetInterfacesNetworkinterfacenamePatchRequestbodyContentApplicationJsonSchema()
    )
    if hardware_address is not None:
        body.hardware_address = hardware_address
    if interface_up is not None:
        body.interface_up = interface_up

    client = cf_network_gatewayd(cmd.cli_ctx, device_ip=device_ip)
    return client.net_set_network_interface_attributes(network_interface_name=interface, body=body)


def list_interfaces_device_network(cmd: AzCliCommand, device_ip: str):
    """List all network interfaces (device network list-interfaces)."""
    client = cf_network_gatewayd(cmd.cli_ctx, device_ip=device_ip)
    operation_response = client.net_get_all_network_interface_status()
    if len(operation_response.interfaces) > 0:
        return operation_response.interfaces
    else:
        raise CLIError("Unable to list network interfaces.")


def show_diagnostics_device_network(cmd: AzCliCommand, device_ip: str, network: int = None):
    """List one or all network failure logs (device network show-diagnostics)."""
    client = cf_wifi_gatewayd(cmd.cli_ctx, device_ip=device_ip)
    if network is not None:
        return client.wifi_get_a_networks_connection_failure_log(network_id=str(network))
    else:
        operation_response = client.wifi_get_all_network_connection_failure_logs()
        return operation_response.values


def update_interface_device_network(
    cmd: AzCliCommand, device_ip: str, interface: str, hardware_address: str
):
    """Update a network's interface (device network update-interface)."""
    return set_body_update_interface(cmd, device_ip, interface, hardware_address=hardware_address)
