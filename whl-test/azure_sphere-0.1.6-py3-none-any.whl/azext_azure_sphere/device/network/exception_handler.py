"""Provides exception handlers for device network commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._exception_handler import device_exception_handler
from azure.core.exceptions import HttpResponseError, ResourceNotFoundError
from knack.cli import CLIError
from knack.log import get_logger

logger = get_logger(__name__)


def device_network_show_diagnostics_exception_handler(ex: Exception):
    """If the status code of the exception is 404, it means that the network requested doesn't found."""
    message = "Device rejected the request: "

    if isinstance(ex, HttpResponseError):
        if ex.status_code == 404:
            raise CLIError(message + "Network not found.") from ex

    device_exception_handler(ex)


def device_network_update_interface_exception_handler(ex: Exception):
    """If the username or password was too long then tell the user."""
    message = "Failed to update interface. "

    if isinstance(ex, HttpResponseError):
        if ex.status_code == 400:
            message = message + ex.message
            raise CLIError(message) from ex
        if ex.status_code == 415:
            message = message + "Operation not supported for this interface."
            raise CLIError(message) from ex
        if ex.status_code == 500:
            message = message + ex.message
            raise CLIError(message) from ex
    if isinstance(ex, ResourceNotFoundError):
        if ex.status_code == 404:
            message = message + "Interface unavailable."
            raise CLIError(message) from ex

    device_exception_handler(ex)
