"""This module provides the device image commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere.helpers import argtypes


def load_device_image_arguments(self, _):
    """Load arguments for device image related commands."""
    with self.argument_context("sphere device image") as ctx:
        ctx.argument(
            "all",
            arg_type=argtypes.custom_boolean,
            options_list=["--all"],
            required=False,
        )
