"""This module provides the implementation of custom device image commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._client_factory import cf_image
from azext_azure_sphere._client_factory_device import cf_image_gatewayd
from azext_azure_sphere.helpers.image_type_enum import ImageType
from azext_azure_sphere.helpers.utils_images import get_image_type_name
from azure.cli.core.commands import AzCliCommand
from azuresphere_device_api import devices
from knack.log import get_logger

logger = get_logger(__name__)


def image_list_installed(cmd: AzCliCommand, device_ip: str, all: bool = False):

    """List all images (device image list-installed)."""
    images_response = {}
    devices.set_active_device_ip_address(device_ip)

    images_client = cf_image_gatewayd(cmd.cli_ctx, device_ip=device_ip)
    images_response = images_client.images_get_images()

    return_response = []

    for item in images_response.components:

        if not all:
            if (
                item.image_type != ImageType.Applications
                and item.image_type != ImageType.CustomerBoardConfig
            ):
                continue

        item.image_type = get_image_type_name(item.image_type)

        return_response.append(item)

    if not return_response:
        logger.warning("No installed images.")

    return return_response


def list_targeted_images(
    cmd: AzCliCommand,
    resource_group_name: str,
    catalog_name: str,
    device_name: str,
    all=False,
):
    """List images targeted for a device (image list-targeted)."""
    filter_request = f"deviceId eq '{device_name}'"
    image_client = cf_image(cmd.cli_ctx)
    response = image_client.list_by_catalog(
        resource_group_name, catalog_name, filter=filter_request
    )
    if all:
        return response
    else:
        items = list(response)
        allowed_types = [
            "Applications",
            "CustomerBoardConfig",
        ]

        return [item for item in items if item.image_type in allowed_types]
