"""This module provides the implementation of custom device manufacturing commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._client_factory_device import cf_device_gatewayd
from azext_azure_sphere.helpers.utils import check_device_restart_status
from azext_azure_sphere.sdk.azure_sphere_gatewayd.azure.sphere.gatewayd.models import (
    PathsFkel7NDeviceManufacturingStatePutRequestbodyContentApplicationJsonSchema,
)
from azure.cli.core.commands import AzCliCommand
from knack.log import get_logger

logger = get_logger(__name__)


def update_manufacturing_device(
    cmd: AzCliCommand,
    state: str,
    device_ip: str,
):
    """Update manufacturing-state commands (device manufacturing-state update)."""
    logger.warning(f"Updating manufacturing state to {state}.")
    client = cf_device_gatewayd(cmd.cli_ctx, device_ip=device_ip, connection_timeout=2)

    body = PathsFkel7NDeviceManufacturingStatePutRequestbodyContentApplicationJsonSchema(
        manufacturing_state=state
    )

    result = client.device_set_device_manufacturing_state(body=body)
    if result:
        logger.warning(result)

    logger.warning("Restarting device for changes to take effect.")

    result = client.device_restart_device()
    success_message = "The device was successfully restarted."

    check_device_restart_status(
        get_device_status_callback=client.device_get_device_status,
        timeout=0.1,
        success_message=success_message,
        retry=10
    )
