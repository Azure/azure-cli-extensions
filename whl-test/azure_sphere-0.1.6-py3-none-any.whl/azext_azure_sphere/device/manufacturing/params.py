"""This module provides the device manufacturing commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere.helpers.enum import SchemaManufacturingState
from azure.cli.core.commands.parameters import get_enum_type

STATE_PARAM_LONG_NAME = "--state"
STATE_PARAM_SHORT_NAME = "-s"


def load_device_manufacturing_arguments(self, _):
    """Load arguments for device manufacturing related commands."""
    self.argument_context("sphere device manufacturing-state show").extra("device_ip")
    self.argument_context("sphere device manufacturing-state update").extra("device_ip")
    with self.argument_context("sphere device manufacturing-state update") as ctx:
        ctx.argument(
            "state",
            arg_type=get_enum_type(SchemaManufacturingState),
            options_list=[STATE_PARAM_LONG_NAME, STATE_PARAM_SHORT_NAME],
            required=True,
        )
