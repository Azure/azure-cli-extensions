"""This module provides the device manufacturing commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._client_factory_device import cf_device_gatewayd
from azext_azure_sphere._exception_handler import device_exception_handler
from azext_azure_sphere.device.manufacturing.exception_handler import (
    device_manufacturing_update_exception_handler,
)
from azext_azure_sphere.device.validators import device_commands_device_validator
from azure.cli.core.commands import CliCommandType


def load_device_manufacturing_command_table(self, _):
    """List of the device manufacturing commands and their configurations."""
    device_ops = CliCommandType(
        operations_tmpl="azext_azure_sphere.sdk.azure_sphere_gatewayd.azure.sphere.gatewayd.operations#DeviceOperations.{}",
        client_factory=cf_device_gatewayd,
        exception_handler=device_exception_handler,
    )

    device_manufacturing_custom_type = CliCommandType(
        operations_tmpl="azext_azure_sphere.device.manufacturing.custom#{}",
        exception_handler=device_exception_handler,
    )

    with self.command_group(
        "sphere device manufacturing-state",
        command_type=device_ops,
        custom_command_type=device_manufacturing_custom_type,
    ) as ctx:
        ctx.custom_command(
            "update",
            "update_manufacturing_device",
            validator=device_commands_device_validator,
            exception_handler=device_manufacturing_update_exception_handler,
        )
        ctx.command(
            "show",
            "device_get_device_manufacturing_state",
        )
