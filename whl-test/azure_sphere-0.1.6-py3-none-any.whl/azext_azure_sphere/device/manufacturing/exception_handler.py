"""Provides exception handlers for device commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._exception_handler import device_exception_handler
from azure.core.exceptions import HttpResponseError
from knack.cli import CLIError
from knack.log import get_logger

logger = get_logger(__name__)


def device_manufacturing_update_exception_handler(ex: Exception):
    """Updating the device manufacturing state has failed."""
    if isinstance(ex, HttpResponseError):
        if ex.status_code == 404:
            message = (
                "Device does not support this request. This request can only be issued "
                "during manufacturing."
            )
            raise CLIError(message) from ex
    device_exception_handler(ex)
