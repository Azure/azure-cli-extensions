"""This module provides the sideload validator."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from argparse import Namespace

from azext_azure_sphere._validators import input_file_validator
from azext_azure_sphere.device.sideload.params import (
    IMAGE_PACKAGE_PARAM_LONG_NAME,
    IMAGE_PACKAGE_PARAM_SHORT_NAME,
)
from azext_azure_sphere.device.validators import device_commands_device_validator
from azure.cli.core.commands import AzCliCommand


def device_sideload_deploy_validator(cmd: AzCliCommand, namespace: Namespace):
    """Validate the image path / input file parameter."""
    device_commands_device_validator(cmd, namespace)

    namespace.image_package = input_file_validator(
        input_file=namespace.image_package,
        extension=".imagepackage",
        long_param_name=IMAGE_PACKAGE_PARAM_LONG_NAME,
        short_param_name=IMAGE_PACKAGE_PARAM_SHORT_NAME,
    )
