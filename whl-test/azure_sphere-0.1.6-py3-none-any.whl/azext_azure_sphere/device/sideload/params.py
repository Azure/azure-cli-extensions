"""This module provides the device sideload commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere.device.app.params import (
    COMPONENT_ID_PARAM_LONG_NAME,
    COMPONENT_ID_PARAM_SHORT_NAME,
)
from azure.cli.core.commands.parameters import get_three_state_flag

VALUE_PARAM_LONG_NAME = "--value"
VALUE_PARAM_SHORT_NAME = "-v"

IMAGE_PACKAGE_PARAM_LONG_NAME = "--image-package"
IMAGE_PACKAGE_PARAM_SHORT_NAME = "-p"

MANUAL_START_PARAM_LONG_NAME = "--manual-start"
MANUAL_START_PARAM_SHORT_NAME = "-m"

FORCE_PARAM_LONG_NAME = "--force"

EXCEPT_PARAM_LONG_NAME = "--except-component-ids"
EXCEPT_PARAM_SHORT_NAME = "-e"


def load_device_sideload_arguments(self, _):
    """Load arguments for device sideload related commands."""
    self.argument_context("sphere device sideload delete").extra("device_ip")
    self.argument_context("sphere device sideload deploy").extra("device_ip")
    with self.argument_context("sphere device sideload set-deployment-timeout") as ctx:
        ctx.argument(
            "value",
            options_list=[VALUE_PARAM_LONG_NAME, VALUE_PARAM_SHORT_NAME],
            type=int,
            required=True,
        )

    with self.argument_context("sphere device sideload deploy") as ctx:
        ctx.argument(
            "image_package",
            options_list=[IMAGE_PACKAGE_PARAM_LONG_NAME, IMAGE_PACKAGE_PARAM_SHORT_NAME],
            required=True,
        )
        ctx.argument(
            "manual_start",
            options_list=[MANUAL_START_PARAM_LONG_NAME, MANUAL_START_PARAM_SHORT_NAME],
            arg_type=get_three_state_flag(),
            required=False,
        )
        ctx.argument(
            "force",
            options_list=[FORCE_PARAM_LONG_NAME],
            arg_type=get_three_state_flag(),
            required=False,
        )

    with self.argument_context("sphere device sideload delete") as ctx:
        ctx.argument(
            "component_id",
            options_list=[COMPONENT_ID_PARAM_LONG_NAME, COMPONENT_ID_PARAM_SHORT_NAME],
            type=str,
            required=False,
        )
        ctx.argument(
            "except_component_ids",
            options_list=[EXCEPT_PARAM_LONG_NAME, EXCEPT_PARAM_SHORT_NAME],
            nargs="+",
            required=False,
        )
