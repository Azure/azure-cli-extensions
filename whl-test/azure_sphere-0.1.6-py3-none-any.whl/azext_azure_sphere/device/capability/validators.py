"""This module provides the device capability validators."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------
from argparse import Namespace

from azext_azure_sphere._validators import input_file_validator
from azext_azure_sphere.device.capability.params import CAPABILITY_FILE_PARAM_LONG_NAME
from azext_azure_sphere.device.validators import (
    device_commands_common_validator,
    device_commands_device_validator,
)
from azure.cli.core.commands import AzCliCommand
from knack.cli import CLIError


def capability_file_validator(namespace: Namespace):
    """Validate capability file path."""
    if namespace.capability_file:
        namespace.capability_file = input_file_validator(
            input_file=namespace.capability_file,
            long_param_name=CAPABILITY_FILE_PARAM_LONG_NAME,
            short_param_name=None,
        )


def device_capability_file_validator(cmd: AzCliCommand, namespace: Namespace):
    """Validate parameters for capability commands."""
    device_commands_device_validator(cmd=cmd, namespace=namespace)
    capability_file_validator(namespace=namespace)


def device_capability_file_select_validator(cmd: AzCliCommand, namespace: Namespace):
    """Validate that the provided path exists or that the none option was selected."""
    if (not namespace.none and not namespace.capability_file) or (
        namespace.none and namespace.capability_file
    ):
        message = (
            "You must either provide a capability file path or select --none to end the "
            "capability session."
        )
        raise CLIError(message)

    if not namespace.capability_file:
        return

    device_commands_common_validator(cmd=cmd, namespace=namespace)
    capability_file_validator(namespace=namespace)
