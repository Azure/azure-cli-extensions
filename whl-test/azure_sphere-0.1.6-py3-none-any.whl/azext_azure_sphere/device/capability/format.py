"""Provides methods for transforming the format of device capability commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------
from typing import List

from azext_azure_sphere.helpers.capability_types import DeviceCapabilityType
from azext_azure_sphere.sdk.azure_sphere_gatewayd.azure.sphere.gatewayd.models import (
    Paths1Os34ArDeviceCapabilitiesGetResponses200ContentApplicationJsonSchema,
)
from knack.log import get_logger

logger = get_logger(__name__)


def transform_capabilities_list_output(
    result: Paths1Os34ArDeviceCapabilitiesGetResponses200ContentApplicationJsonSchema,
) -> List:
    """Transform the capability show attached command."""
    capability_values = [DeviceCapabilityType[i] for i in result.device_capabilities]

    return capability_values


def transform_capabilities_table_output(result):
    """Transform the capability show attached command table output."""
    if len(result) == 0:
        logger.warning("No device capabilities present.")
        return []
    else:
        return result
