"""This module provides the implementation of custom device capability commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------
import base64
from pathlib import Path

from azext_azure_sphere._client_factory import cf_device
from azext_azure_sphere.helpers.capability_session import CAPABILITY_SESSION, CapabilityFile
from azext_azure_sphere.helpers.utils import DEFAULT_VALUE
from azext_azure_sphere.helpers.utils_capabilities import update_capability
from azext_azure_sphere.sdk.asrm.azure.mgmt.azuresphere.models._models import (
    GenerateCapabilityImageRequest,
)
from azure.cli.core.commands import AzCliCommand
from knack.log import get_logger
from knack.util import CLIError

logger = get_logger(__name__)


def download_capability_file_device(
    cmd: AzCliCommand,
    resource_group_name: str,
    catalog_name: str,
    device_name: str,
    output_file: str,
    product_name=DEFAULT_VALUE,
    device_group_name=DEFAULT_VALUE,
    capabilities_type=None,
):
    """Download capability file from a device (device download-capability)."""
    if capabilities_type:
        parameters = GenerateCapabilityImageRequest(capabilities=capabilities_type)
    else:
        parameters = GenerateCapabilityImageRequest(capabilities=[])
    device_client = cf_device(cmd.cli_ctx)
    response = device_client.generate_capability_image(
        resource_group_name,
        catalog_name,
        product_name,
        device_group_name,
        device_name,
        generate_device_capability_request=parameters,
    )

    if response.image:
        try:
            with open(output_file, "wb") as output_file_writer:
                file_content = base64.b64decode(response.image)
                output_file_writer.write(file_content)
        except:
            raise CLIError("Unable to write capability file.")
    else:
        raise CLIError("Unable to download capability file.")


def select_capability_device(
    capability_file: str = None,
    none: bool = False,
):
    """Select capability device (device capability select)."""
    if none:
        CAPABILITY_SESSION.end_capability_session()
        logger.warning("Capability configuration has been successfully cleared.")
        return

    CAPABILITY_SESSION.start_capability_session(CapabilityFile(capability_file))
    logger.warning(f"The capability session uses {str(capability_file)}.")


def update_capability_device(
    cmd: AzCliCommand,
    device_ip: str,
    capability_file: Path,
):
    """Update capability device (device capability update)."""
    update_capability(cmd, device_ip, capability_file)
