"""This module provides the device capability commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._validators import OUTPUT_FILE_PARAM_LONG_NAME, OUTPUT_FILE_PARAM_SHORT_NAME
from azext_azure_sphere.devicegroup.params import DG_NAME_PARAM_LONG_NAME, DG_NAME_PARAM_SHORT_NAME
from azext_azure_sphere.product.params import (
    PRODUCT_NAME_PARAM_LONG_NAME,
    PRODUCT_NAME_PARAM_SHORT_NAME,
)
from azext_azure_sphere.sdk.asrm.azure.mgmt.azuresphere.models._azure_sphere_provider_client_enums import (  # pylint: disable=line-too-long
    CapabilityType,
)
from azure.cli.core.commands.parameters import get_enum_type, get_three_state_flag

CAPABILITY_FILE_PARAM_LONG_NAME = "--capability-file"
CAPABILITY_TYPE_PARAM_LONG_NAME = "--type"
CAPABILITY_TYPE_PARAM_SHORT_NAME = "-t"
NONE_PARAM_LONG_NAME = "--none"
NONE_PARAM_SHORT_NAME = "-n"


def load_device_capability_arguments(self, _):
    """Load arguments for device capability related commands."""
    self.argument_context("sphere device capability update").extra("device_ip")
    self.argument_context("sphere device capability show-attached").extra("device_ip")
    with self.argument_context("sphere device capability download") as ctx:
        ctx.argument(
            "product_name",
            type=str,
            options_list=[PRODUCT_NAME_PARAM_LONG_NAME, PRODUCT_NAME_PARAM_SHORT_NAME],
            required=False,
        )
        ctx.argument(
            "device_group_name",
            type=str,
            options_list=[DG_NAME_PARAM_LONG_NAME, DG_NAME_PARAM_SHORT_NAME],
            required=False,
        )
        ctx.argument(
            "capabilities_type",
            arg_type=get_enum_type(CapabilityType),
            nargs="+",
            options_list=[CAPABILITY_TYPE_PARAM_LONG_NAME, CAPABILITY_TYPE_PARAM_SHORT_NAME],
            required=False,
        )
        ctx.argument(
            "output_file",
            type=str,
            options_list=[OUTPUT_FILE_PARAM_LONG_NAME, OUTPUT_FILE_PARAM_SHORT_NAME],
            required=False,
        )

    with self.argument_context("sphere device capability select") as ctx:
        ctx.argument(
            "capability_file",
            options_list=[CAPABILITY_FILE_PARAM_LONG_NAME],
            required=False,
        )
        ctx.argument(
            "none",
            arg_type=get_three_state_flag(),
            options_list=[NONE_PARAM_LONG_NAME, NONE_PARAM_SHORT_NAME],
            required=False,
        )

    with self.argument_context("sphere device capability update") as ctx:
        ctx.argument(
            "capability_file",
            options_list=[CAPABILITY_FILE_PARAM_LONG_NAME],
            required=True,
        )
