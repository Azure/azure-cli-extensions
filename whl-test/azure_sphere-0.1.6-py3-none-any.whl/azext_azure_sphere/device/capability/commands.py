"""This module provides the device capability commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._client_factory_device import cf_device_gatewayd
from azext_azure_sphere._exception_handler import cloud_exception_handler, device_exception_handler
from azext_azure_sphere.device.capability.exception_handler import (
    device_capability_update_exception_handler,
)
from azext_azure_sphere.device.capability.format import (
    transform_capabilities_list_output,
    transform_capabilities_table_output,
)
from azext_azure_sphere.device.capability.validators import (
    device_capability_file_select_validator,
    device_capability_file_validator,
)
from azext_azure_sphere.device.validators import (
    destination_file_cap_validator,
    device_commands_device_validator,
)
from azure.cli.core.commands import CliCommandType


def load_device_capability_command_table(self, _):
    """List of the device capability commands and their configurations."""
    device_ops = CliCommandType(
        operations_tmpl="azext_azure_sphere.sdk.azure_sphere_gatewayd.azure.sphere.gatewayd.operations#DeviceOperations.{}",
        client_factory=cf_device_gatewayd,
        exception_handler=device_exception_handler,
    )

    device_capability_custom_type = CliCommandType(
        operations_tmpl="azext_azure_sphere.device.capability.custom#{}",
        exception_handler=device_exception_handler,
    )

    with self.command_group(
        "sphere device capability",
        command_type=device_ops,
        custom_command_type=device_capability_custom_type,
    ) as ctx:
        ctx.custom_command(
            "download",
            "download_capability_file_device",
            validator=destination_file_cap_validator,
            exception_handler=cloud_exception_handler,
        )
        ctx.custom_command(
            "update",
            "update_capability_device",
            validator=device_capability_file_validator,
            exception_handler=device_capability_update_exception_handler,
        )
        ctx.command(
            "show-attached",
            "device_get_device_capabilities",
            validator=device_commands_device_validator,
            transform=transform_capabilities_list_output,
            table_transformer=transform_capabilities_table_output,
        )
        ctx.custom_command(
            "select",
            "select_capability_device",
            validator=device_capability_file_select_validator,
        )
