"""Provides exception handlers for device certificate commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._exception_handler import device_exception_handler
from azext_azure_sphere.helpers.capability_session import CAPABILITY_SESSION
from azure.core.exceptions import HttpResponseError
from knack.cli import CLIError
from knack.log import get_logger

logger = get_logger(__name__)


def device_capability_update_exception_handler(ex: Exception):
    """The device capability update command has failed. If the failure happened because of a forbidden access, the user can take further actions to overcome the problem."""
    if isinstance(ex, HttpResponseError):
        if ex.status_code == 403:
            message = CAPABILITY_SESSION.get_forbidden_access_message()
            raise CLIError(message) from ex
    device_exception_handler(ex)
