"""Provides methods for transforming the format of device app commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

from collections import OrderedDict
from typing import List

from knack.log import get_logger

logger = get_logger(__name__)


def transform_memory_stats_output(result) -> List:
    """Transform the show memory stats command."""
    table_output = []

    if result.get("memoryStats"):
        memory_stats = OrderedDict()
        memory_stats["Name"] = "Total (Kernel + User Mode)"
        memory_stats["Usage (bytes)"] = result["memoryStats"]["currentMemoryUsageInBytes"]
        table_output.append(memory_stats)

        memory_stats = OrderedDict()
        memory_stats["Name"] = "User Mode"
        memory_stats["Usage (bytes)"] = result["memoryStats"]["userModeMemoryUsageInBytes"]
        table_output.append(memory_stats)

        memory_stats = OrderedDict()
        memory_stats["Name"] = "Peak User Mode"
        memory_stats["Usage (bytes)"] = result["memoryStats"]["peakUserModeMemoryUsageInBytes"]
        table_output.append(memory_stats)

    if (
        result.get("apps")
        and result.get("apps")[0].get("processes")
        and result.get("apps")[0].get("processes")[0].get("heapUsageByCaller")
    ):

        # Iterate over the heapUsageByCaller of the first process in the first app
        for heapusage_index in result["apps"][0]["processes"][0]["heapUsageByCaller"]:
            memory_stats = OrderedDict()
            if heapusage_index["name"] == "other":
                memory_stats["Name"] = "Heap: App + Static Libraries"
            else:
                memory_stats["Name"] = f"Heap: {heapusage_index['name']}"
            memory_stats["Usage (bytes)"] = heapusage_index["usageInBytes"]
            table_output.append(memory_stats)

    return table_output
