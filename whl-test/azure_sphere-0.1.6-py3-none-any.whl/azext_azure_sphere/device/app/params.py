"""This module provides the device app commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere.helpers import argtypes

COMPONENT_ID_PARAM_LONG_NAME = "--component-id"
COMPONENT_ID_PARAM_SHORT_NAME = "-i"

DEBUG_MODE_PARAM_LONG_NAME = "--debug-mode"


def load_device_app_arguments(self, _):
    """Load arguments for device app related commands."""
    self.argument_context("sphere device app show-status").extra("device_ip")
    self.argument_context("sphere device app show-quota").extra("device_ip")
    self.argument_context("sphere device app show-memory-stats").extra("device_ip")
    with self.argument_context("sphere device app") as ctx:
        ctx.argument(
            "component_id",
            type=str,
            options_list=[COMPONENT_ID_PARAM_LONG_NAME, COMPONENT_ID_PARAM_SHORT_NAME],
            required=False,
        )

    with self.argument_context("sphere device app start") as ctx:
        ctx.argument(
            "debug_mode",
            arg_type=argtypes.custom_boolean,
            options_list=[DEBUG_MODE_PARAM_LONG_NAME],
            required=False,
        )
