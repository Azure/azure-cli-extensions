"""This module provides the implementation of custom device app commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from collections import OrderedDict

from azext_azure_sphere._client_factory_device import cf_application_gatewayd, cf_image_gatewayd
from azext_azure_sphere.helpers.utils_images import get_component_ids_info
from azext_azure_sphere.sdk.azure_sphere_gatewayd.azure.sphere.gatewayd.models import (
    Paths14Wju22AppStatusComponentidPatchRequestbodyContentApplicationJsonSchema,
)
from azure.cli.core.commands import AzCliCommand
from knack.log import get_logger

logger = get_logger(__name__)


def start_app_device(
    cmd: AzCliCommand, device_ip: str, component_id: str = "", debug_mode: bool = False
):
    """Start an app (device app start)."""
    TRIGGER_START_DEBUG = "startDebug"
    TRIGGER_START = "start"
    return_response = []

    app_client = cf_application_gatewayd(cmd.cli_ctx, device_ip=device_ip)
    images_client = cf_image_gatewayd(cmd.cli_ctx, device_ip=device_ip)

    get_images_response = images_client.images_get_images()
    component_ids_for_start = get_component_ids_info(
        component_id=component_id, get_images_response=get_images_response
    )

    if not component_ids_for_start:
        logger.warning("No applications were found.")
        return return_response

    trigger = Paths14Wju22AppStatusComponentidPatchRequestbodyContentApplicationJsonSchema(
        trigger=TRIGGER_START_DEBUG if debug_mode else TRIGGER_START
    )
    for component_id_for_start in component_ids_for_start:
        response = app_client.app_set_app_status(
            component_id=component_id_for_start["cid"], body=trigger
        )

        state = response.state
        core = (
            "High-level"
            if response.real_time_core is None
            else f"Real-time {response.real_time_core}"
        )

        info = OrderedDict()
        info["componentId"] = component_id_for_start["cid"]
        info["imageId"] = component_id_for_start["iid"]
        info["state"] = state
        info["core"] = core
        if response.state == "debugging":
            info["gdbPort"] = "2345"
            info["outputPort"] = "2342"
        return_response.append(info)

    return return_response


def stop_app_device(cmd: AzCliCommand, device_ip: str, component_id: str = ""):
    """Stop an app (device app stop)."""
    STOP_TRIGGER = "stop"

    return_response = []

    app_client = cf_application_gatewayd(cmd.cli_ctx, device_ip=device_ip)
    images_client = cf_image_gatewayd(cmd.cli_ctx, device_ip=device_ip)

    get_images_response = images_client.images_get_images()
    component_ids_for_stop = get_component_ids_info(
        component_id=component_id, get_images_response=get_images_response
    )

    if not component_ids_for_stop:
        logger.warning("No applications were found.")
        return return_response

    trigger = Paths14Wju22AppStatusComponentidPatchRequestbodyContentApplicationJsonSchema(
        trigger=STOP_TRIGGER
    )
    return_response = []
    for component_id_for_start in component_ids_for_stop:
        response = app_client.app_set_app_status(component_id_for_start["cid"], trigger)

        state = response.state

        info = OrderedDict()
        info["componentId"] = component_id_for_start["cid"]
        info["imageId"] = component_id_for_start["iid"]
        info["state"] = state
        return_response.append(info)

    return return_response


def show_status_device(cmd: AzCliCommand, device_ip: str, component_id: str):
    """Show status of an app (device app show-status)."""
    app_client = cf_application_gatewayd(cmd.cli_ctx, device_ip=device_ip)
    images_client = cf_image_gatewayd(cmd.cli_ctx, device_ip=device_ip)

    return_response = []

    # Get all images from the device.
    get_images_response = images_client.images_get_images()
    component_ids_for_status = get_component_ids_info(
        component_id=component_id, get_images_response=get_images_response
    )

    if not component_ids_for_status:
        logger.warning("No applications were found.")
        return return_response

    for component_id_for_status in component_ids_for_status:
        # Returns string "{'state': app_state}"
        response = app_client.app_get_app_status(component_id_for_status["cid"])
        # Get app_state from string
        response_status = _get_state(response)

        info = OrderedDict()
        info["componentId"] = component_id_for_status["cid"]
        info["imageId"] = component_id_for_status["iid"]
        info["state"] = response_status
        return_response.append(info)

    return return_response


def show_quota_device(cmd: AzCliCommand, device_ip: str, component_id: str = ""):
    """Show quota of an app (device app show-quota)."""
    app_client = cf_application_gatewayd(cmd.cli_ctx, device_ip=device_ip)
    images_client = cf_image_gatewayd(cmd.cli_ctx, device_ip=device_ip)

    return_response = []

    # Get all images from the device.
    get_images_response = images_client.images_get_images()
    component_ids_for_status = get_component_ids_info(
        component_id=component_id, get_images_response=get_images_response
    )

    if not component_ids_for_status:
        logger.warning("No applications were found.")
        return return_response

    for component_id_for_status in component_ids_for_status:
        response = app_client.app_get_app_quota(component_id_for_status["cid"])
        info = OrderedDict()
        info["componentId"] = component_id_for_status["cid"]
        info["imageId"] = component_id_for_status["iid"]
        info["usageKB"] = response.usage_kb
        info["limitKB"] = response.limit_kb
        return_response.append(info)

    return return_response


def _get_state(response: str):
    """Convert string "{'state': app_state}" dict response into dict object and get app_state value."""
    return dict(
        (a.strip()[1:-1], b.strip()[1:-1])
        for a, b in (element.split(":") for element in response[1:-1].split(", "))
    )["state"]
