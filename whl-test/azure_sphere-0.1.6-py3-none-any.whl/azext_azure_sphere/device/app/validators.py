"""This module provides the device app validator."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from argparse import Namespace

from azext_azure_sphere.device.validators import device_commands_device_validator
from azure.cli.core.commands import AzCliCommand
from knack.cli import CLIError


def device_app_start_validator(cmd: AzCliCommand, namespace: Namespace):
    """Validate the device app start command."""
    device_commands_device_validator(cmd, namespace)

    if namespace.debug_mode and not namespace.component_id:
        raise CLIError("You must provide a component ID when starting with debugging enabled.")
