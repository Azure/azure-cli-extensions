"""This module provides the device wifi validators."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

from argparse import Namespace

from azext_azure_sphere._validators import parameter_length_validator
from azext_azure_sphere.device.validators import device_commands_device_validator
from azext_azure_sphere.device.wifi.params import (
    CLIENT_CERT_ID_PARAM_NAME,
    CLIENT_ID_PARAM_NAME,
    CONFIG_NAME_PARAM_NAME,
    PSK_PARAM_LONG_NAME,
    PSK_PARAM_SHORT_NAME,
    ROOT_CA_CERT_PARAM_NAME,
    SSID_PARAM_LONG_NAME,
    SSID_PARAM_SHORT_NAME,
)
from azure.cli.core.commands import AzCliCommand
from knack.cli import CLIError


def device_wifi_add_validator(cmd: AzCliCommand, namespace: Namespace):
    """Validate the device wifi add command."""
    device_commands_device_validator(cmd=cmd, namespace=namespace)

    if namespace.psk is not None and (
        namespace.client_cert_id is not None
        or namespace.client_id is not None
        or namespace.root_ca_cert_id is not None
    ):
        message = (
            "Add network failed. Cannot configure a network for both PSK and EAP-TLS. "
            "Please supply either a PSK or a EAP-TLS configuration."
        )
        raise CLIError(message)

    if namespace.client_cert_id is None and (
        namespace.client_id is not None or namespace.root_ca_cert_id is not None
    ):
        message = (
            "Add network failed. Invalid network properties provided. "
            "See https://aka.ms/AzureSphereEAPTLS/Setup for further information on setting up an EAP-TLS network connection."
        )
        raise CLIError(message)

    parameter_length_validator(
        param=namespace.ssid,
        max_length=32,
        long_param_name=SSID_PARAM_LONG_NAME,
        short_param_name=SSID_PARAM_SHORT_NAME,
    )

    if namespace.psk:
        parameter_length_validator(
            param=namespace.psk,
            min_length=8,
            max_length=63,
            long_param_name=PSK_PARAM_LONG_NAME,
            short_param_name=PSK_PARAM_SHORT_NAME,
        )

    if namespace.config_name:
        parameter_length_validator(
            param=namespace.config_name, max_length=16, long_param_name=CONFIG_NAME_PARAM_NAME
        )

    if namespace.client_id:
        parameter_length_validator(
            param=namespace.client_id, max_length=254, long_param_name=CLIENT_ID_PARAM_NAME
        )

    if namespace.client_cert_id:
        parameter_length_validator(
            param=namespace.client_cert_id, max_length=16, long_param_name=CLIENT_CERT_ID_PARAM_NAME
        )

    if namespace.root_ca_cert_id:
        parameter_length_validator(
            param=namespace.root_ca_cert_id, max_length=16, long_param_name=ROOT_CA_CERT_PARAM_NAME
        )
