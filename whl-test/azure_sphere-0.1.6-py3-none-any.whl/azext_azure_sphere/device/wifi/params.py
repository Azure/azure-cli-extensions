"""This module provides the device wifi commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere.helpers import argtypes

SSID_PARAM_LONG_NAME = "--ssid"
SSID_PARAM_SHORT_NAME = "-s"
CLIENT_CERT_ID_PARAM_NAME = "--client-cert-id"
CLIENT_ID_PARAM_NAME = "--client-id"
CONFIG_NAME_PARAM_NAME = "--config-name"
ROOT_CA_CERT_PARAM_NAME = "--root-ca-cert-id"
TARGETED_SCAN_PARAM_NAME = "--targeted-scan"
PSK_PARAM_LONG_NAME = "--psk"
PSK_PARAM_SHORT_NAME = "-p"
ID_PARAM_LONG_NAME = "--id"
ID_PARAM_SHORT_NAME = "-i"


def load_device_wifi_arguments(self, _):
    """Load arguments for device network related commands."""
    self.argument_context("sphere device wifi add").extra("device_ip")
    self.argument_context("sphere device wifi list").extra("device_ip")
    self.argument_context("sphere device wifi scan").extra("device_ip")
    self.argument_context("sphere device wifi show").extra("device_ip")
    self.argument_context("sphere device wifi forget").extra("device_ip")
    self.argument_context("sphere device wifi disable").extra("device_ip")
    self.argument_context("sphere device wifi enable").extra("device_ip")
    self.argument_context("sphere device wifi reload-config").extra("device_ip")
    self.argument_context("sphere device wifi show-status").extra("device_ip")
    with self.argument_context("sphere device wifi add") as ctx:
        ctx.argument(
            "ssid",
            type=str,
            options_list=[SSID_PARAM_LONG_NAME, SSID_PARAM_SHORT_NAME],
            required=True,
        )
        ctx.argument(
            "client_cert_id",
            type=str,
            options_list=[CLIENT_CERT_ID_PARAM_NAME],
            required=False,
        )
        ctx.argument(
            "client_id",
            type=str,
            options_list=[CLIENT_ID_PARAM_NAME],
            required=False,
        )
        ctx.argument(
            "config_name",
            type=str,
            options_list=[CONFIG_NAME_PARAM_NAME],
            required=False,
        )
        ctx.argument(
            "root_ca_cert_id",
            type=str,
            options_list=[ROOT_CA_CERT_PARAM_NAME],
            required=False,
        )
        ctx.argument(
            "targeted_scan",
            arg_type=argtypes.custom_boolean,
            options_list=[TARGETED_SCAN_PARAM_NAME],
            required=False,
        )
        ctx.argument(
            "psk",
            type=str,
            options_list=[PSK_PARAM_LONG_NAME, PSK_PARAM_SHORT_NAME],
            required=False,
        )

    with self.argument_context("sphere device wifi disable") as ctx:
        ctx.argument(
            "wifi_network_id",
            type=int,
            options_list=[ID_PARAM_LONG_NAME, ID_PARAM_SHORT_NAME],
            required=True,
        )

    with self.argument_context("sphere device wifi enable") as ctx:
        ctx.argument(
            "wifi_network_id",
            type=int,
            options_list=[ID_PARAM_LONG_NAME, ID_PARAM_SHORT_NAME],
            required=True,
        )

    with self.argument_context("sphere device wifi forget") as ctx:
        ctx.argument(
            "wifi_network_id",
            type=int,
            options_list=[ID_PARAM_LONG_NAME, ID_PARAM_SHORT_NAME],
            required=True,
        )

    with self.argument_context("sphere device wifi show") as context:
        context.argument(
            "wifi_network_id",
            options_list=[ID_PARAM_LONG_NAME, ID_PARAM_SHORT_NAME],
            type=int,
            required=True,
        )
