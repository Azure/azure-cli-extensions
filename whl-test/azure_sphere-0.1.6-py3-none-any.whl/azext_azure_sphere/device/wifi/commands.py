"""This module provides the device wifi command structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._client_factory_device import cf_wifi_gatewayd
from azext_azure_sphere._exception_handler import device_exception_handler
from azext_azure_sphere.device.validators import device_commands_device_validator
from azext_azure_sphere.device.wifi.format import (
    transform_wifi_add_table_output,
    transform_wifi_disable_table_output,
    transform_wifi_enable_table_output,
    transform_wifi_forget_table_output,
    transform_wifi_list_output,
    transform_wifi_list_table_output,
    transform_wifi_network_config_response,
    transform_wifi_output,
    transform_wifi_reload_config_table_output,
    transform_wifi_scan_output,
    transform_wifi_scan_table_output,
    transform_wifi_show_status_output,
)
from azext_azure_sphere.device.wifi.validators import device_wifi_add_validator
from azure.cli.core.commands import CliCommandType


def load_device_wifi_command_table(self, _):
    """List of the device wifi commands and their configurations."""
    wifi_sdk = CliCommandType(
        operations_tmpl="azext_azure_sphere.sdk.azure_sphere_gatewayd.azure.sphere.gatewayd.operations#WifiOperations.{}",  # pylint: disable=line-too-long
        client_factory=cf_wifi_gatewayd,
        exception_handler=device_exception_handler,
    )

    device_wifi_custom_type = CliCommandType(
        operations_tmpl="azext_azure_sphere.device.wifi.custom#{}",
        exception_handler=device_exception_handler,
    )

    with self.command_group(
        "sphere device wifi", command_type=wifi_sdk, custom_command_type=device_wifi_custom_type
    ) as ctx:
        ctx.custom_command(
            "add",
            "device_wifi_add",
            validator=device_wifi_add_validator,
            transform=transform_wifi_network_config_response,
            table_transformer=transform_wifi_add_table_output,
        )
        ctx.custom_command(
            "disable",
            "device_wifi_disable",
            validator=device_commands_device_validator,
            transform=transform_wifi_network_config_response,
            table_transformer=transform_wifi_disable_table_output,
        )
        ctx.custom_command(
            "enable",
            "device_wifi_enable",
            validator=device_commands_device_validator,
            transform=transform_wifi_network_config_response,
            table_transformer=transform_wifi_enable_table_output,
        )
        ctx.command(
            "forget",
            "wifi_remove_configured_wifi_network",
            validator=device_commands_device_validator,
            transform=transform_wifi_output,
            table_transformer=transform_wifi_forget_table_output,
        )
        ctx.command(
            "list",
            "wifi_get_configured_wifi_networks",
            validator=device_commands_device_validator,
            transform=transform_wifi_list_output,
            table_transformer=transform_wifi_list_table_output,
        )
        ctx.custom_command(
            "reload-config",
            "device_wifi_reload_config",
            validator=device_commands_device_validator,
            transform=transform_wifi_output,
            table_transformer=transform_wifi_reload_config_table_output,
        )
        ctx.command(
            "scan",
            "wifi_get_wifi_scan_results",
            validator=device_commands_device_validator,
            transform=transform_wifi_scan_output,
            table_transformer=transform_wifi_scan_table_output,
        )
        ctx.command(
            "show",
            "wifi_get_configured_wifi_network",
            validator=device_commands_device_validator,
            transform=transform_wifi_network_config_response,
        )
        ctx.command(
            "show-status",
            "wifi_get_wifi_interface_state",
            validator=device_commands_device_validator,
            transform=transform_wifi_show_status_output,
        )
