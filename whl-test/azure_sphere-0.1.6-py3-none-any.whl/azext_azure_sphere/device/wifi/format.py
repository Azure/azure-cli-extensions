"""Provides methods for transforming the format of device wifi commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

from collections import OrderedDict
from typing import List

from azext_azure_sphere.sdk.azure_sphere_gatewayd.azure.sphere.gatewayd.models import (
    WifiNetworkConfigResponse,
)
from knack.log import get_logger

logger = get_logger(__name__)


def transform_wifi_scan_output(result) -> List[OrderedDict]:
    """Transform the wifi scan command output."""
    if not result:
        return []

    output = []
    for item in result.values:
        row = OrderedDict()

        row["SSID"] = item.ssid
        row["securityState"] = item.security_state
        row["BSSID"] = item.bssid
        row["signalLevel"] = item.signal_level
        row["frequency"] = item.freq
        output.append(row)
    return output


def transform_wifi_scan_table_output(result) -> List[OrderedDict]:
    """Transform the wifi scan command table output."""
    if len(result) == 0:
        logger.warning("No scanned networks found.")
        return []
    return result


def transform_wifi_network_config_response(
    wifi_network_config_response: WifiNetworkConfigResponse,
) -> OrderedDict:
    """Transform a WifiNetworkConfigResponse object for output."""
    row = OrderedDict()
    row["ID"] = wifi_network_config_response.id
    row["SSID"] = wifi_network_config_response.ssid
    row["configurationState"] = wifi_network_config_response.config_state
    row["connectionState"] = wifi_network_config_response.connection_state
    row["securityState"] = wifi_network_config_response.security_state
    row["targetedScan"] = wifi_network_config_response.targeted_scan
    row["configurationName"] = wifi_network_config_response.config_name
    row["CACertId"] = wifi_network_config_response.root_ca_cert_store_identifier
    row["clientCertId"] = wifi_network_config_response.client_cert_store_identifier
    row["clientIdentity"] = wifi_network_config_response.client_identity

    return row


def transform_wifi_list_output(result) -> List[OrderedDict]:
    """Transform the wifi list command output."""
    if not result:
        return []
    return [transform_wifi_network_config_response(item) for item in result.values]


def transform_wifi_list_table_output(result) -> List[OrderedDict]:
    """Transform the wifi list command table output."""
    if len(result) == 0:
        logger.warning("No networks found.")
        return []
    return result


def transform_wifi_output(result) -> List[OrderedDict]:
    """Transform the wifi forget command output."""
    return []


def transform_wifi_forget_table_output(result) -> List[OrderedDict]:
    """Transform the wifi forget command table output."""
    message = "Successfully forgotten network."
    logger.warning(message)
    return []


def transform_wifi_disable_table_output(result) -> List[OrderedDict]:
    """Transform the wifi disable command table output."""
    message = "Successfully disabled network:"
    logger.warning(message)
    return result


def transform_wifi_enable_table_output(result) -> List[OrderedDict]:
    """Transform the wifi enable command table output."""
    message = "Successfully enabled network:"
    logger.warning(message)
    return result


def transform_wifi_reload_config_table_output(result):
    """Transform the wifi reload config command table output."""
    message = "Wi-Fi configuration was successfully reloaded."
    logger.warning(message)
    return []


def transform_wifi_add_table_output(result) -> List[OrderedDict]:
    """Transform the wifi add command table output."""
    message = "Successfully added network:"
    logger.warning(message)
    return result


def transform_wifi_show_status_output(result) -> OrderedDict:
    """Transform the wifi show-status command."""
    row = OrderedDict()
    row["SSID"] = result.ssid
    row["configurationState"] = result.config_state
    row["connectionState"] = result.connection_state
    row["securityState"] = result.security_state
    row["frequency"] = result.freq
    row["mode"] = result.mode
    row["keyManagement"] = result.key_mgmt
    row["wpaState"] = result.wpa_state
    row["ipAddress"] = result.ip_address
    row["macAddress"] = result.address

    return row
