"""This module provides the device certificate validators."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------
from argparse import Namespace

from azext_azure_sphere._validators import input_file_validator, parameter_length_validator
from azext_azure_sphere.device.certificate.params import (
    CERTIFICATE_ID_PARAM_LONG_NAME,
    CERTIFICATE_ID_PARAM_SHORT_NAME,
    CERTIFICATE_TYPE_PARAM_LONG_NAME,
    CLIENT_CERT_TYPE,
    PRIVATE_KEY_FILE_PARAM_LONG_NAME,
    PUBLIC_KEY_FILE_PARAM_LONG_NAME,
    PUBLIC_KEY_FILE_PARAM_SHORT_NAME,
)
from azext_azure_sphere.device.validators import device_commands_device_validator
from azure.cli.core.commands import AzCliCommand
from knack.cli import CLIError


def device_certificate_add_parameters_validator(cmd: AzCliCommand, namespace: Namespace):
    """Validate parameters for certificate add command."""
    # Check if the certificate type is valid (client or rootca)
    device_commands_device_validator(cmd=cmd, namespace=namespace)

    # Check if the certificate name is not too long
    parameter_length_validator(
        param=namespace.identifier,
        max_length=16,
        long_param_name=CERTIFICATE_ID_PARAM_LONG_NAME,
        short_param_name=CERTIFICATE_ID_PARAM_SHORT_NAME,
    )

    # PrivateKey is required if certype is Client
    if (
        namespace.cert_type
        and namespace.cert_type == CLIENT_CERT_TYPE
        and not namespace.private_key_filepath
        or (namespace.private_key_filepath and namespace.private_key_filepath.isspace())
    ):
        raise CLIError(
            f"With the {CERTIFICATE_TYPE_PARAM_LONG_NAME} '{CLIENT_CERT_TYPE}', the Private key certificate is required."
        )

    # Validate Public Cert path
    if namespace.public_key_filepath:
        namespace.public_key_filepath = input_file_validator(
            input_file=namespace.public_key_filepath,
            long_param_name=PUBLIC_KEY_FILE_PARAM_LONG_NAME,
            short_param_name=PUBLIC_KEY_FILE_PARAM_SHORT_NAME,
            extension=".pem",
        )

    # Validate Private key path
    if namespace.private_key_filepath:
        namespace.private_key_filepath = input_file_validator(
            input_file=namespace.private_key_filepath,
            long_param_name=PRIVATE_KEY_FILE_PARAM_LONG_NAME,
            short_param_name=None,
        )
