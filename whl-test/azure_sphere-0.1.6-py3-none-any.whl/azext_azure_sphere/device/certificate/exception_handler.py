"""Provides exception handlers for device certificate commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._exception_handler import device_exception_handler
from azure.core.exceptions import HttpResponseError, ResourceNotFoundError
from knack.cli import CLIError
from knack.log import get_logger
from msrest.exceptions import ValidationError

logger = get_logger(__name__)


def device_certificate_add_exception_handler(ex: Exception):
    """Raise exception when device certificate add command failed."""
    message = "Unable to add certificate to the device. "
    certificate_exception_handler(message, ex)


def device_certificate_delete_exception_handler(ex: Exception):
    """Raise exception when device certificate delete command failed."""
    message = "Unable to delete certificate from the device. "
    certificate_exception_handler(message, ex)


def device_certificate_show_exception_handler(ex: Exception):
    """Raise exception when device certificate show command failed."""
    message = "Unable to display certificate's details from the device. "
    certificate_exception_handler(message, ex)


def certificate_exception_handler(message: str, ex: Exception):
    """Raise exception when device certificate commands failed."""
    if isinstance(ex, HttpResponseError) and ex.status_code in (400, 500):
        message = message + ex.message
        raise CLIError(message) from ex
    if isinstance(ex, ResourceNotFoundError):
        if ex.status_code == 404:
            message = message + "Certificate unavailable."
            raise CLIError(message) from ex
    if isinstance(ex, ValidationError):
        for msg in ex.args:
            message = message + msg
        raise CLIError(message) from ex

    device_exception_handler(ex)
