"""This module provides the device certificate commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azure.cli.core.commands.parameters import get_enum_type

CERTIFICATE_ID_PARAM_LONG_NAME = "--certificate"
CERTIFICATE_ID_PARAM_SHORT_NAME = "-c"

CERTIFICATE_TYPE_PARAM_LONG_NAME = "--cert-type"
CERTIFICATE_TYPE_PARAM_SHORT_NAME = "-t"

PUBLIC_KEY_FILE_PARAM_LONG_NAME = "--public-key-file"
PUBLIC_KEY_FILE_PARAM_SHORT_NAME = "-p"

PRIVATE_KEY_FILE_PARAM_LONG_NAME = "--private-key-file"

PRIVATE_KEY_PASSWORD_PARAM_LONG_NAME = "--private-key-password"
PRIVATE_KEY_PASSWORD_PARAM_SHORT_NAME = "-w"

CLIENT_CERT_TYPE = "client"
ROOT_CA_CERT_TYPE = "rootca"


def load_device_certificate_arguments(self, _):
    """Load arguments for device certificate related commands."""
    self.argument_context("sphere device certificate list").extra("device_ip")
    self.argument_context("sphere device certificate show-quota").extra("device_ip")
    self.argument_context("sphere device certificate show").extra("device_ip")
    self.argument_context("sphere device certificate delete").extra("device_ip")

    with self.argument_context("sphere device certificate show") as ctx:
        ctx.argument(
            "identifier",
            type=str,
            options_list=[CERTIFICATE_ID_PARAM_LONG_NAME, CERTIFICATE_ID_PARAM_SHORT_NAME],
            required=True,
        )

    with self.argument_context("sphere device certificate delete") as ctx:
        ctx.argument(
            "identifier",
            type=str,
            options_list=[CERTIFICATE_ID_PARAM_LONG_NAME, CERTIFICATE_ID_PARAM_SHORT_NAME],
            required=True,
        )

    with self.argument_context("sphere device certificate add") as ctx:
        ctx.argument(
            "identifier",
            type=str,
            options_list=[CERTIFICATE_ID_PARAM_LONG_NAME, CERTIFICATE_ID_PARAM_SHORT_NAME],
            required=True,
        )
        ctx.argument(
            "cert_type",
            type=str,
            arg_type=get_enum_type([ROOT_CA_CERT_TYPE, CLIENT_CERT_TYPE]),
            options_list=[CERTIFICATE_TYPE_PARAM_LONG_NAME, CERTIFICATE_TYPE_PARAM_SHORT_NAME],
            required=True,
        )
        ctx.argument(
            "public_key_filepath",
            type=str,
            options_list=[PUBLIC_KEY_FILE_PARAM_LONG_NAME, PUBLIC_KEY_FILE_PARAM_SHORT_NAME],
            required=True,
        )
        ctx.argument(
            "private_key_filepath",
            type=str,
            options_list=[PRIVATE_KEY_FILE_PARAM_LONG_NAME],
            required=False,
        )
        ctx.argument(
            "private_key_password",
            type=str,
            options_list=[
                PRIVATE_KEY_PASSWORD_PARAM_LONG_NAME,
                PRIVATE_KEY_PASSWORD_PARAM_SHORT_NAME,
            ],
            required=False,
        )
