"""This module provides the implementation of custom device certificate commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._client_factory_device import cf_certificate_gatewayd
from azext_azure_sphere.helpers.utils import open_certificate
from azext_azure_sphere.sdk.azure_sphere_gatewayd.azure.sphere.gatewayd.models import (
    Paths7Yreq7CertstoreCertsIdentifierPostRequestbodyContentApplicationJsonSchema,
)
from azure.cli.core.commands import AzCliCommand
from knack.log import get_logger
from knack.util import CLIError

logger = get_logger(__name__)


def add_certificate_device(
    cmd: AzCliCommand,
    device_ip: str,
    identifier: str,
    cert_type: str,
    public_key_filepath: str,
    private_key_filepath: str,
    private_key_password: str,
):
    """Add a specific device's certificate (device certificate add)."""
    body = Paths7Yreq7CertstoreCertsIdentifierPostRequestbodyContentApplicationJsonSchema(
        cert_type=cert_type,
    )

    if private_key_password:
        body.password = private_key_password

    if public_key_filepath:
        try:
            body.public_cert = open_certificate(public_key_filepath)
        except:
            raise CLIError("Unable to parse public key certificate file.")

    if private_key_filepath:
        try:
            body.private_key = open_certificate(private_key_filepath)
        except:
            raise CLIError("Unable to parse private key file.")

    client = cf_certificate_gatewayd(cmd.cli_ctx, device_ip=device_ip)
    client.cert_add_cert(identifier=identifier, body=body)

    logger.warning(f"Certificate '{identifier}' successfully added.\n")
