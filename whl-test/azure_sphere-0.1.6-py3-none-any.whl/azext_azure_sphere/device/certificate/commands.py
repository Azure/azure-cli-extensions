"""This module provides the device certificate commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._client_factory_device import cf_certificate_gatewayd
from azext_azure_sphere._exception_handler import device_exception_handler
from azext_azure_sphere.device.certificate.exception_handler import (
    device_certificate_add_exception_handler,
    device_certificate_delete_exception_handler,
    device_certificate_show_exception_handler,
)
from azext_azure_sphere.device.certificate.format import (
    transform_certificate_list_output,
    transform_certificate_show_output,
    transform_certificate_show_quota_output,
    transform_certificate_show_quota_table_output,
)
from azext_azure_sphere.device.certificate.validators import (
    device_certificate_add_parameters_validator,
)
from azext_azure_sphere.device.validators import device_commands_device_validator
from azure.cli.core.commands import CliCommandType


def load_device_certificate_command_table(self, _):
    """List of the device certificate commands and their configurations."""
    certificate_ops = CliCommandType(
        operations_tmpl="azext_azure_sphere.sdk.azure_sphere_gatewayd.azure.sphere.gatewayd.operations#CertOperations.{}",
        client_factory=cf_certificate_gatewayd,
        exception_handler=device_exception_handler,
    )

    device_certificate_custom_type = CliCommandType(
        operations_tmpl="azext_azure_sphere.device.certificate.custom#{}",
        exception_handler=device_exception_handler,
    )

    with self.command_group(
        "sphere device certificate",
        command_type=certificate_ops,
        custom_command_type=device_certificate_custom_type,
    ) as ctx:
        ctx.custom_command(
            "add",
            "add_certificate_device",
            validator=device_certificate_add_parameters_validator,
            exception_handler=device_certificate_add_exception_handler,
        )
        ctx.command(
            "delete",
            "cert_remove_cert",
            exception_handler=device_certificate_delete_exception_handler,
        )
        ctx.command(
            "show",
            "cert_get_cert_information",
            validator=device_commands_device_validator,
            transform=transform_certificate_show_output,
            exception_handler=device_certificate_show_exception_handler,
        )
        ctx.command(
            "list",
            "cert_get_cert_identifiers",
            validator=device_commands_device_validator,
            transform=transform_certificate_list_output,
        )
        ctx.command(
            "show-quota",
            "cert_get_cert_available_space",
            validator=device_commands_device_validator,
            transform=transform_certificate_show_quota_output,
            table_transformer=transform_certificate_show_quota_table_output,
        )
