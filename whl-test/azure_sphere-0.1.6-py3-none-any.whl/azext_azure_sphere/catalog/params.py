"""This module provides the catalog commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------
# pylint: disable=line-too-long

from azext_azure_sphere._validators import OUTPUT_FILE_PARAM_LONG_NAME, OUTPUT_FILE_PARAM_SHORT_NAME
from azext_azure_sphere.helpers import argtypes

CATALOG_NAME_LONG_PARAM = "--name"
CATALOG_NAME_SHORT_PARAM = "-n"


def load_catalog_arguments(self, _):
    """Load arguments for catalog related commands."""
    with self.argument_context("sphere catalog create") as ctx:
        ctx.argument(
            "catalog_name",
            type=str,
            options_list=[CATALOG_NAME_LONG_PARAM, CATALOG_NAME_SHORT_PARAM],
            required=True,
        )
    with self.argument_context("sphere catalog download-error-report") as ctx:
        ctx.argument(
            "output_file",
            type=str,
            options_list=[OUTPUT_FILE_PARAM_LONG_NAME, OUTPUT_FILE_PARAM_SHORT_NAME],
            required=False,
        )
    with self.argument_context("sphere catalog list") as ctx:
        ctx.argument(
            "all",
            arg_type=argtypes.custom_boolean,
            options_list=["--all"],
            required=False,
        )
