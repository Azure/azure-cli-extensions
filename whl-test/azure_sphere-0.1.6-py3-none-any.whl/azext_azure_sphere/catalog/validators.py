"""This module provides the catalog validator."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from argparse import Namespace
from datetime import datetime

from azext_azure_sphere._validators import (
    destination_file_validator,
    parameter_length_validator,
    parameter_regex_validator,
)
from azext_azure_sphere.catalog.params import CATALOG_NAME_LONG_PARAM, CATALOG_NAME_SHORT_PARAM
from knack.util import CLIError

CATALOG_REGEX = "^[A-Za-z0-9_-]{1,30}$"


def destination_file_error_report_validator(namespace: Namespace):
    """Validate the destination parameter."""
    if not namespace.output_file:
        today = datetime.today()
        today_format = today.strftime("%Y%m%d_%H%M%S")
        namespace.output_file = f"error-report_{namespace.catalog_name}_{today_format}.csv"

    destination_file_validator(namespace, extension=".csv", allow_overwrite=True)


def catalog_list_validator(namespace: Namespace):
    """Validate the catalog list command."""
    if not namespace.all and not namespace.resource_group_name:
        # Same error message displayed by Azure CLI when a parameter is missing
        message = "the following arguments are required: --resource-group/-g or --all"
        raise CLIError(message)


def catalog_create_validator(namespace: Namespace):
    """Validate the catalog create command."""
    parameter_regex_validator(
        param=namespace.catalog_name,
        regex=CATALOG_REGEX,
        error_msg="The catalog name must be between 1 and 30 characters long and can only contain letters, numbers, underscores, and hyphens",
        long_param_name=CATALOG_NAME_LONG_PARAM,
        short_param_name=CATALOG_NAME_SHORT_PARAM,
    )
