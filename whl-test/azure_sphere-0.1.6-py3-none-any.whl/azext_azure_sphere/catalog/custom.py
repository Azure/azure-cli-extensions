"""This module provides the implementation of custom catalog commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------
import csv

from azext_azure_sphere._client_factory import cf_catalog
from azext_azure_sphere.sdk.asrm.azure.mgmt.azuresphere.models._models import Catalog
from azure.cli.core.commands import AzCliCommand
from knack.cli import CLIError
from knack.log import get_logger

logger = get_logger(__name__)


def create_catalog(cmd: AzCliCommand, resource_group_name: str, catalog_name: str):
    """Create a new catalog in your Resource Group (catalog create)."""
    resource = Catalog(location="global")
    catalog_client = cf_catalog(cmd.cli_ctx)
    return catalog_client.begin_create_or_update(resource_group_name, catalog_name, resource)


def download_error_report_catalog(
    cmd: AzCliCommand, resource_group_name: str, catalog_name: str, output_file=None
):
    """Download the available error reports for the selected Azure Sphere Catalog (catalog download-error-report)."""
    catalog_client = cf_catalog(cmd.cli_ctx)
    list_insights = catalog_client.list_device_insights(
        resource_group_name=resource_group_name, catalog_name=catalog_name
    )
    header = [
        "TIMESTAMP",
        "DEVICE ID",
        "EVENT CLASS",
        "EVENT CATEGORY",
        "EVENT TYPE",
        "DESCRIPTION",
    ]

    try:
        first = next(list_insights)
        data_first = device_insights_data(first)
    except StopIteration:
        logger.warning(
            f"There are no device insights registered for the Azure Sphere Catalog '{catalog_name}'."
        )
        return

    with open(output_file, "w", encoding="UTF8", newline="") as report_file:
        writer = csv.writer(report_file)
        writer.writerow(header)
        writer.writerow(data_first)

        try:
            for i, insights in enumerate(list_insights):
                data = device_insights_data(insights)
                writer.writerow(data)
        except:
            pass

    logger.warning(
        f"The error reports for the selected catalog '{catalog_name}' have been exported to '{output_file}'."
    )


def device_insights_data(insights):
    """Extract insights data."""
    timestamp_insight = insights.start_timestamp_utc.strftime("%Y-%m-%dT%H:%M:%SZ")
    data = [
        timestamp_insight,
        insights.device_id,
        insights.event_class,
        insights.event_category,
        insights.event_type,
        insights.description,
    ]

    return data


def list_catalog(cmd: AzCliCommand, resource_group_name=None, all=False):
    """List catalogs in your Resource Group or Subscription (catalog list)."""
    catalog_client = cf_catalog(cmd.cli_ctx)
    if all:
        # List catalogs in subscription
        return catalog_client.list_by_subscription()
    else:
        # List catalogs in resource group
        return catalog_client.list_by_resource_group(resource_group_name)
