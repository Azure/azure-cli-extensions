"""This module provides the implementation of custom device group commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._client_factory import cf_catalog, cf_device_group
from azext_azure_sphere.sdk.asrm.azure.mgmt.azuresphere.models._models import (
    DeviceGroup,
    DeviceGroupUpdate,
    ListDeviceGroupsRequest,
)
from azure.cli.core.commands import AzCliCommand
from knack.log import get_logger
from knack.util import CLIError

logger = get_logger(__name__)


def create_device_group(
    cmd: AzCliCommand,
    resource_group_name: str,
    catalog_name: str,
    product_name: str,
    device_group_name: str,
    device_group_description: str,
    device_group_applicationupdate=None,
    device_group_osfeed=None,
    device_group_allowcrashdumps=None,
    device_group_regionaldataboundary=None,
):
    """Create a new device group in your Product (device-group create)."""
    device_group_client = cf_device_group(cmd.cli_ctx)
    device_group = None

    try:
        device_group = get_device_group(
            cmd=cmd,
            resource_group_name=resource_group_name,
            catalog_name=catalog_name,
            product_name=product_name,
            device_group_name=device_group_name,
        )
    except:
        pass

    if device_group:
        raise CLIError(f"The device group '{device_group_name}' already exists.")

    resource = DeviceGroup(
        description=device_group_description,
        update_policy=device_group_applicationupdate,
        os_feed_type=device_group_osfeed,
        allow_crash_dumps_collection=device_group_allowcrashdumps,
        regional_data_boundary=device_group_regionaldataboundary,
    )

    return device_group_client.begin_create_or_update(
        resource_group_name, catalog_name, product_name, device_group_name, resource
    )


def update_device_group(
    cmd: AzCliCommand,
    resource_group_name: str,
    catalog_name: str,
    product_name: str,
    device_group_name: str,
    device_group_description=None,
    device_group_applicationupdate=None,
    device_group_osfeed=None,
    device_group_allowcrashdumps=None,
    device_group_regionaldataboundary=None,
):
    """Update a device group in your Product (device-group update)."""
    parameters = DeviceGroupUpdate()

    if device_group_description:
        parameters.description = device_group_description
    if device_group_applicationupdate:
        parameters.update_policy = device_group_applicationupdate
    if device_group_osfeed:
        parameters.os_feed_type = device_group_osfeed
    if device_group_allowcrashdumps is not None:
        parameters.allow_crash_dumps_collection = device_group_allowcrashdumps
    if device_group_regionaldataboundary is not None:
        parameters.regional_data_boundary = device_group_regionaldataboundary

    device_group_client = cf_device_group(cmd.cli_ctx)
    return device_group_client.begin_update(
        resource_group_name, catalog_name, product_name, device_group_name, properties=parameters
    )


def get_device_group(
    cmd: AzCliCommand,
    resource_group_name: str,
    catalog_name: str,
    product_name: str,
    device_group_name: str,
):
    """Get a device group in your Product (device-group show)."""
    device_group_client = cf_device_group(cmd.cli_ctx)
    return device_group_client.get(
        resource_group_name, catalog_name, product_name, device_group_name
    )


def list_device_group(
    cmd: AzCliCommand,
    resource_group_name: str,
    catalog_name: str,
    product_name=None,
    device_group_name=None,
):
    """List device groups in your Catalog or your Product (device-group list)."""
    if product_name:  # in Product
        device_group_client = cf_device_group(cmd.cli_ctx)
        return device_group_client.list_by_product(resource_group_name, catalog_name, product_name)
    else:  # in Catalog (possility to filter with device group name)
        parameters = ListDeviceGroupsRequest()
        parameters.device_group_name = device_group_name
        catalog_client = cf_catalog(cmd.cli_ctx)
        return catalog_client.list_device_groups(
            resource_group_name, catalog_name, list_device_groups_request=parameters
        )
