"""This module provides the implementation of custom product commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._client_factory import cf_product
from azext_azure_sphere.sdk.asrm.azure.mgmt.azuresphere.models._models import Product, ProductUpdate
from azure.cli.core.commands import AzCliCommand
from knack.log import get_logger
from knack.util import CLIError

logger = get_logger(__name__)


def create_product(
    cmd: AzCliCommand,
    resource_group_name: str,
    catalog_name: str,
    product_name: str,
    product_description: str,
):
    """Create a new product in your Catalog (product create)."""
    product_client = cf_product(cmd.cli_ctx)
    product = None
    try:
        product = get_product(
            cmd=cmd,
            resource_group_name=resource_group_name,
            catalog_name=catalog_name,
            product_name=product_name,
        )
    except:
        pass

    if product:
        raise CLIError(f"The product '{product_name}' already exists.")

    resource = Product(name=product_name, description=product_description)
    return product_client.begin_create_or_update(
        resource_group_name, catalog_name, product_name, resource
    )


def update_product(
    cmd: AzCliCommand,
    resource_group_name: str,
    catalog_name: str,
    product_name: str,
    product_description: str,
):
    """Update a product in your Catalog (product update)."""
    properties = ProductUpdate()
    properties.description = product_description
    product_client = cf_product(cmd.cli_ctx)
    return product_client.begin_update(
        resource_group_name, catalog_name, product_name, properties=properties
    )


def get_product(cmd: AzCliCommand, resource_group_name: str, catalog_name: str, product_name: str):
    """Get a product in your Catalog (product show)."""
    product_client = cf_product(cmd.cli_ctx)
    return product_client.get(resource_group_name, catalog_name, product_name)
