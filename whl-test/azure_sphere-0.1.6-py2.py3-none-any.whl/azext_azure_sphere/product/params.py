"""This module provides the product commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

PRODUCT_NAME_PARAM_LONG_NAME = "--product"
PRODUCT_DESC_PARAM_LONG_NAME = "--description"

PRODUCT_NAME_PARAM_SHORT_NAME = "-p"
PRODUCT_DESC_PARAM_SHORT_NAME = "-d"


def load_product_arguments(self, _):
    """Load arguments for product related commands."""
    with self.argument_context("sphere product") as ctx:
        ctx.argument(
            "product_name",
            type=str,
            options_list=[PRODUCT_NAME_PARAM_LONG_NAME, PRODUCT_NAME_PARAM_SHORT_NAME],
            required=True,
        )

    with self.argument_context("sphere product create") as ctx:
        ctx.argument(
            "product_name",
            type=str,
            options_list=["--name", "-n"],
            required=True,
        )
        ctx.argument(
            "product_description",
            type=str,
            options_list=[PRODUCT_DESC_PARAM_LONG_NAME, PRODUCT_DESC_PARAM_SHORT_NAME],
        )

    with self.argument_context("sphere product update") as ctx:
        ctx.argument(
            "product_description",
            type=str,
            options_list=[PRODUCT_DESC_PARAM_LONG_NAME, PRODUCT_DESC_PARAM_SHORT_NAME],
            required=True,
        )
