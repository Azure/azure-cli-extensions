"""This module provides the hardware definition validator."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

from argparse import Namespace

from azext_azure_sphere._validators import input_file_validator
from azext_azure_sphere.hardwaredefinition.params import HW_FILE_PARAM_LONG_NAME


def hardware_definition_file_path_validator(namespace: Namespace):
    """Validate that the hardware definition path exists."""
    namespace.hardware_definition_file = input_file_validator(
        input_file=namespace.hardware_definition_file,
        long_param_name=HW_FILE_PARAM_LONG_NAME,
        short_param_name=None,
    )
