"""This module provides the catalog commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._client_factory import cf_catalog
from azext_azure_sphere._exception_handler import cloud_exception_handler
from azext_azure_sphere.catalog.validators import (
    catalog_create_validator,
    catalog_list_validator,
    destination_file_error_report_validator,
)
from azure.cli.core.commands import CliCommandType


def load_catalog_command_table(self, _):
    """List of the catalog commands and their configurations."""
    catalog_sdk = CliCommandType(
        operations_tmpl="azext_azure_sphere.sdk.asrm.azure.mgmt.azuresphere.operations#CatalogsOperations.{}",  # pylint: disable=line-too-long
        client_factory=cf_catalog,
        exception_handler=cloud_exception_handler,
    )

    catalog_custom_type = CliCommandType(
        operations_tmpl="azext_azure_sphere.catalog.custom#{}",
        exception_handler=cloud_exception_handler,
    )

    with self.command_group(
        "sphere catalog", command_type=catalog_sdk, custom_command_type=catalog_custom_type
    ) as ctx:
        ctx.custom_command("list", "list_catalog", validator=catalog_list_validator)
        ctx.show_command("show", "get")
        ctx.command("delete", "begin_delete")
        ctx.custom_command("create", "create_catalog", validator=catalog_create_validator)
        ctx.custom_command(
            "download-error-report",
            "download_error_report_catalog",
            validator=destination_file_error_report_validator,
        )
