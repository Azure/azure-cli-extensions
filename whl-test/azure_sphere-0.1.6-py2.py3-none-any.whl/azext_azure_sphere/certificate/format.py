"""Provides methods for transforming the format of certificate commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------
from azext_azure_sphere.helpers.utils import encode_bytes
from knack.log import get_logger

logger = get_logger(__name__)


def tranform_certificate_item(item):
    """Transform the output of the certificate item."""
    item.certificate = encode_bytes(item.certificate)
    return item


def transform_certificate_list(result):
    """Transform the output of the certificate list."""
    return [tranform_certificate_item(item) for item in result] if result else None
