"""This module provides the device app commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._client_factory_device import cf_diag_gatewayd
from azext_azure_sphere._exception_handler import device_exception_handler
from azext_azure_sphere.device.app.format import transform_memory_stats_output
from azext_azure_sphere.device.app.validators import device_app_start_validator
from azext_azure_sphere.device.validators import device_commands_device_validator
from azure.cli.core.commands import CliCommandType


def load_device_app_command_table(self, _):
    """List of the device app commands and their configurations."""
    app_ops = CliCommandType(
        operations_tmpl="azext_azure_sphere.sdk.azure_sphere_gatewayd.azure.sphere.gatewayd.operations#DiagOperations.{}",
        client_factory=cf_diag_gatewayd,
        exception_handler=device_exception_handler,
    )

    device_app_custom_type = CliCommandType(
        operations_tmpl="azext_azure_sphere.device.app.custom#{}",
        exception_handler=device_exception_handler,
    )

    with self.command_group(
        "sphere device app", command_type=app_ops, custom_command_type=device_app_custom_type
    ) as ctx:
        ctx.custom_command(
            "show-status",
            "show_status_device",
            validator=device_commands_device_validator,
        )
        ctx.custom_command(
            "show-quota",
            "show_quota_device",
            validator=device_commands_device_validator,
        )
        ctx.command(
            "show-memory-stats",
            "diag_get_memory_stats",
            validator=device_commands_device_validator,
            table_transformer=transform_memory_stats_output,
        )
        ctx.custom_command(
            "start",
            "start_app_device",
            validator=device_app_start_validator,
        )
        ctx.custom_command(
            "stop",
            "stop_app_device",
            validator=device_commands_device_validator,
        )
