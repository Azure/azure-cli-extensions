"""This module provides the implementation of custom device wifi commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.

from azext_azure_sphere._client_factory_device import cf_wifi_gatewayd
from azext_azure_sphere.sdk.azure_sphere_gatewayd.azure.sphere.gatewayd.models import (
    EapTlsNetworkRequest,
    OpenNetworkRequest,
    PathsGudpawWifiInterfacePatchRequestbodyContentApplicationJsonSchema,
    PathsK7NvwoWifiConfigNetworksWifinetworkidPatchRequestbodyContentApplicationJsonSchema,
    PskNetworkRequest,
    WifiConfigState,
)
from azure.cli.core.commands import AzCliCommand
from knack.log import get_logger

logger = get_logger(__name__)


def device_wifi_add(
    cmd: AzCliCommand,
    ssid: str,
    client_cert_id: str,
    client_id: str,
    config_name: str,
    psk: str,
    root_ca_cert_id: str,
    device_ip: str,
    targeted_scan: bool = False,
):
    """Add a new wifi configuration."""
    if psk is not None:
        body = PskNetworkRequest(
            psk=psk,
            ssid=ssid,
        )
    elif client_cert_id is not None:
        body = EapTlsNetworkRequest(
            ssid=ssid,
            client_cert_store_identifier=client_cert_id,
            client_identity=client_id,
            root_ca_cert_store_identifier=root_ca_cert_id,
        )
    else:
        body = OpenNetworkRequest(
            ssid=ssid,
        )

    body.config_name = config_name
    body.config_state = WifiConfigState.ENABLED
    body.targeted_scan = targeted_scan

    client = cf_wifi_gatewayd(cmd.cli_ctx, device_ip=device_ip)
    return client.wifi_add_configured_wifi_network(body)


def device_wifi_reload_config(cmd: AzCliCommand, device_ip: str):
    """Reload the Wi-Fi network configuration for the device."""
    client = cf_wifi_gatewayd(cmd.cli_ctx, device_ip=device_ip)
    body = PathsGudpawWifiInterfacePatchRequestbodyContentApplicationJsonSchema()
    body.reload_config = True

    return client.wifi_change_wifi_interface_status(body)


def device_wifi_disable(cmd: AzCliCommand, wifi_network_id: int, device_ip: str):
    """Disable configured wifi network on device."""
    return _device_wifi_enable_or_disable(
        cmd=cmd, wifi_network_id=wifi_network_id, device_ip=device_ip, enable=False, disable=True
    )


def device_wifi_enable(cmd: AzCliCommand, wifi_network_id: int, device_ip: str):
    """Enable configured wifi network on device."""
    return _device_wifi_enable_or_disable(
        cmd=cmd, wifi_network_id=wifi_network_id, device_ip=device_ip, enable=True, disable=False
    )


def _device_wifi_enable_or_disable(
    cmd: AzCliCommand, wifi_network_id: int, device_ip: str, enable: bool, disable: bool
):
    """Enable or disable configured wifi network on device."""
    client = cf_wifi_gatewayd(cmd.cli_ctx, device_ip=device_ip)
    body = PathsK7NvwoWifiConfigNetworksWifinetworkidPatchRequestbodyContentApplicationJsonSchema()

    if enable and not disable:
        body.config_state = WifiConfigState.ENABLED
    elif not enable and disable:
        body.config_state = WifiConfigState.DISABLED

    return client.wifi_change_configured_wifi_network(wifi_network_id, body)
