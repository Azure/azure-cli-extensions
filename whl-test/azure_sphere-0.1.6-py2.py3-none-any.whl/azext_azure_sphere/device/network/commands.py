"""This module provides the device network command structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._client_factory_device import cf_network_gatewayd
from azext_azure_sphere._exception_handler import device_exception_handler
from azext_azure_sphere.device.network.exception_handler import (
    device_network_show_diagnostics_exception_handler,
    device_network_update_interface_exception_handler,
)
from azext_azure_sphere.device.network.format import (
    transform_network_enable_disable_output,
    transform_network_list_firewall_rules_table_output,
    transform_network_show_diagnostics_output,
)
from azext_azure_sphere.device.validators import device_commands_device_validator
from azure.cli.core.commands import CliCommandType


def load_device_network_command_table(self, _):
    """List of the device network commands and their configurations."""
    network_sdk = CliCommandType(
        operations_tmpl="azext_azure_sphere.sdk.azure_sphere_gatewayd.azure.sphere.gatewayd.operations#NetOperations.{}",  # pylint: disable=line-too-long
        client_factory=cf_network_gatewayd,
        exception_handler=device_exception_handler,
    )

    device_network_custom_type = CliCommandType(
        operations_tmpl="azext_azure_sphere.device.network.custom#{}",
        exception_handler=device_exception_handler,
    )

    with self.command_group(
        "sphere device network",
        command_type=network_sdk,
        custom_command_type=device_network_custom_type,
    ) as ctx:
        ctx.custom_command(
            "enable",
            "enable_device_network",
            validator=device_commands_device_validator,
            transform=transform_network_enable_disable_output,
        )
        ctx.custom_command(
            "disable",
            "disable_device_network",
            validator=device_commands_device_validator,
            transform=transform_network_enable_disable_output,
        )
        ctx.command(
            "list-firewall-rules",
            "net_get_all_network_firewall_rulesets",
            validator=device_commands_device_validator,
            table_transformer=transform_network_list_firewall_rules_table_output,
        )
        ctx.custom_command(
            "list-interfaces",
            "list_interfaces_device_network",
            validator=device_commands_device_validator,
        )
        ctx.custom_command(
            "show-diagnostics",
            "show_diagnostics_device_network",
            validator=device_commands_device_validator,
            transform=transform_network_show_diagnostics_output,
            exception_handler=device_network_show_diagnostics_exception_handler,
        )
        ctx.command(
            "show-status",
            "net_get_network_status",
            validator=device_commands_device_validator,
        )
        ctx.custom_command(
            "update-interface",
            "update_interface_device_network",
            validator=device_commands_device_validator,
            transform=transform_network_enable_disable_output,
            exception_handler=device_network_update_interface_exception_handler,
        )
