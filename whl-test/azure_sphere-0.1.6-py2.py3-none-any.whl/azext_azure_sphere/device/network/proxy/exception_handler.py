"""Provides exception handlers for device network proxy commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._exception_handler import device_exception_handler
from knack.cli import CLIError
from knack.log import get_logger
from msrest.exceptions import ValidationError

logger = get_logger(__name__)


def device_network_apply_proxy_exception_handler(ex: Exception):
    """If the username or password was too long then tell the user."""
    if isinstance(ex, ValidationError):
        if ex.rule == "max_length" and ex.target == "NetworkProxyBasic.username":
            raise CLIError("username is too long") from ex
        if ex.rule == "max_length" and ex.target == "NetworkProxyBasic.password":
            raise CLIError("password is too long") from ex

    device_exception_handler(ex)
