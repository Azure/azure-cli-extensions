"""This module provides the device network proxy commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere.helpers.argtypes import custom_boolean

ADDRESS_PARAM_LONG_NAME = "--address"
ADDRESS_PARAM_SHORT_NAME = "-a"
AUTHENTICATION_PARAM_LONG_NAME = "--authentication"
AUTHENTICATION_PARAM_SHORT_NAME = "-t"
PORT_PARAM_LONG_NAME = "--port"
PORT_PARAM_SHORT_NAME = "-r"

DISABLE_PARAM_LONG_NAME = "--disable"
ENABLE_PARAM_LONG_NAME = "--enable"
NO_PROXY_ADDRESSES_PARAM_LONG_NAME = "--no-proxy-addresses"
NO_PROXY_ADDRESSES_PARAM_SHORT_NAME = "-n"
PASSWORD_PARAM_LONG_NAME = "--password"
PASSWORD_PARAM_SHORT_NAME = "-p"
USERNAME_PARAM_LONG_NAME = "--username"
USERNAME_PARAM_SHORT_NAME = "-u"


def load_device_network_proxy_arguments(self, _):
    """Load arguments for device app related commands."""
    self.argument_context("sphere device network proxy delete").extra("device_ip")
    self.argument_context("sphere device network proxy apply").extra("device_ip")
    self.argument_context("sphere device network proxy show").extra("device_ip")
    with self.argument_context("sphere device network proxy apply") as ctx:
        ctx.argument(
            "address",
            type=str,
            options_list=[ADDRESS_PARAM_LONG_NAME, ADDRESS_PARAM_SHORT_NAME],
            required=True,
        )
        ctx.argument(
            "authentication",
            type=str,
            options_list=[AUTHENTICATION_PARAM_LONG_NAME, AUTHENTICATION_PARAM_SHORT_NAME],
            required=True,
        )
        ctx.argument(
            "port",
            type=str,
            options_list=[PORT_PARAM_LONG_NAME, PORT_PARAM_SHORT_NAME],
            required=True,
        )
        ctx.argument(
            "enable",
            arg_type=custom_boolean,
            options_list=[ENABLE_PARAM_LONG_NAME],
            required=False,
        )
        ctx.argument(
            "no_proxy_addresses",
            nargs="+",
            options_list=[NO_PROXY_ADDRESSES_PARAM_LONG_NAME, NO_PROXY_ADDRESSES_PARAM_SHORT_NAME],
            required=False,
        )
        ctx.argument(
            "password",
            type=str,
            options_list=[PASSWORD_PARAM_LONG_NAME, PASSWORD_PARAM_SHORT_NAME],
            required=False,
        )
        ctx.argument(
            "username",
            type=str,
            options_list=[USERNAME_PARAM_LONG_NAME, USERNAME_PARAM_SHORT_NAME],
            required=False,
        )
