"""Provides methods for transforming the format of device certificate commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

from collections import OrderedDict
from typing import List

from azext_azure_sphere.helpers.utils import format_datetime
from azext_azure_sphere.sdk.azure_sphere_gatewayd.azure.sphere.gatewayd.models import (
    CertIdentifierList,
)
from knack.log import get_logger

logger = get_logger(__name__)


def transform_certificate_list_output(result: CertIdentifierList) -> List[OrderedDict]:
    """Transform the certificate list command table output."""
    if len(result.identifiers) == 0:
        logger.warning("No certificates found.")
        return []

    return transform_list_to_output(result, "identifiers")


def transform_list_to_output(result: CertIdentifierList, header: str) -> List[OrderedDict]:
    """Transform a list to a table output (able to display more than 6 items)."""
    table_output = []
    for item in result.identifiers:
        table_row = OrderedDict()
        table_row[header] = item
        table_output.append(table_row)
    return table_output


def transform_certificate_show_quota_output(result) -> OrderedDict:
    """Transform the certificate show-quota command."""
    show_quota = OrderedDict()
    show_quota["availableSpaceInBytes"] = result.available_space
    return show_quota


def transform_certificate_show_quota_table_output(result) -> OrderedDict:
    """Transform the certificate show-quota command table output."""
    show_quota = OrderedDict()
    show_quota["Available space (bytes)"] = [result["availableSpaceInBytes"]]
    return show_quota


def transform_certificate_show_output(result) -> OrderedDict:
    """Transform the certificate show command."""
    row = OrderedDict()
    row["id"] = result.id
    row["startDate"] = format_datetime(result.not_before)
    row["endDate"] = format_datetime(result.not_after)
    row["subjectName"] = result.subject_name
    row["issuerName"] = result.issuer_name

    return row
