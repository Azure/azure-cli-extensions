"""This module provides the device sideload commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._exception_handler import device_exception_handler
from azext_azure_sphere.device.sideload.validators import device_sideload_deploy_validator
from azext_azure_sphere.device.validators import (
    device_commands_common_validator,
    device_commands_device_validator,
)
from azure.cli.core.commands import CliCommandType


def load_device_sideload_command_table(self, _):
    """List of the device sideload commands and their configurations."""

    device_sideload_custom_type = CliCommandType(
        operations_tmpl="azext_azure_sphere.device.sideload.custom#{}",
        exception_handler=device_exception_handler,
    )

    with self.command_group(
        "sphere device sideload",
        custom_command_type=device_sideload_custom_type,
    ) as ctx:
        ctx.custom_command(
            "set-deployment-timeout",
            "set_deployment_timeout_device",
            validator=device_commands_common_validator,
        )
        ctx.custom_command(
            "show-deployment-timeout",
            "show_deployment_timeout_device",
            validator=device_commands_common_validator,
        )
        ctx.custom_command(
            "deploy",
            "deploy_sideload_device",
            validator=device_sideload_deploy_validator,
        )
        ctx.custom_command(
            "delete",
            "delete_sideload_device",
            validator=device_commands_device_validator,
        )
