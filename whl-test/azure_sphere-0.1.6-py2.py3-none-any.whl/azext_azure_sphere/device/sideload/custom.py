"""This module provides the implementation of custom device sideload commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------
from collections import OrderedDict
from pathlib import Path
from typing import List

from azext_azure_sphere._client_factory_device import (
    cf_application_gatewayd,
    cf_device_gatewayd,
    cf_image_gatewayd,
)
from azext_azure_sphere.device.sideload.params import FORCE_PARAM_LONG_NAME
from azext_azure_sphere.helpers.image_type_enum import ImageType
from azext_azure_sphere.helpers.utils import (
    get_config_value,
    get_gatewayd_version,
    set_config_value,
    throw_if_api_not_yet_supported,
)
from azext_azure_sphere.helpers.utils_images import (
    delete_images,
    get_all_images_info,
    get_image_info,
    get_image_package_type,
)
from azext_azure_sphere.helpers.utils_metadata import (
    check_valid_beta_use,
    ensure_requirements_are_statisfied,
    get_image_package_requirements,
)
from azext_azure_sphere.sdk.azure_sphere_gatewayd.azure.sphere.gatewayd.models import (
    PathsWnx2AfUpdateInstallPostRequestbodyContentApplicationJsonSchema,
)
from azure.cli.core.commands import AzCliCommand
from knack.log import get_logger
from knack.util import CLIError

logger = get_logger(__name__)


def set_deployment_timeout_device(
    cmd: AzCliCommand,
    value: int,
):
    """Set deployment tineout sideload device (device sideload set-deployment-timeout)."""
    set_config_value(cmd, "defaults", "sphere.deployment-timeout", str(value))
    return show_deployment_timeout_device(cmd)


def show_deployment_timeout_device(
    cmd: AzCliCommand,
):
    """Show deployment timeout sideload device (device sideload show-deployment-timeout)."""
    timeout_value = get_config_value(cmd, "defaults", "sphere.deployment-timeout", "30")
    return {"Deployment timeout": str(timeout_value)}


def deploy_sideload_device(
    cmd: AzCliCommand,
    image_package: Path,
    device_ip: str,
    manual_start: bool = False,
    force: bool = False,
):
    """Deploy sideload device (device sideload deploy)."""
    timeout_value = int(get_config_value(cmd, "defaults", "sphere.deployment-timeout", "30"))
    images_client = cf_image_gatewayd(cmd.cli_ctx, device_ip=device_ip, read_timeout=timeout_value)
    device_client = cf_device_gatewayd(cmd.cli_ctx, device_ip=device_ip)

    gatewayd_version = device_client.device_get_device_status(cls=get_gatewayd_version)
    throw_if_api_not_yet_supported(gatewayd_version=gatewayd_version)

    # Ensure image package is compatible with device.
    image_package_type = get_image_package_type(input_file=image_package)
    if image_package_type == ImageType.Other:
        raise CLIError("This image package can't be deployed on this board. Type unsupported.")

    image_package_requirements = get_image_package_requirements(image_package)

    # get_abi_versions()
    abi_versions_response = images_client.images_get_abi_versions()

    # Loop through all image requirements to ensure image package is compatible with device.
    ensure_requirements_are_statisfied(
        image_pkg_reqmnts=image_package_requirements, abi_versions=abi_versions_response
    )

    # Applications - Check valid beta use
    if image_package_type == ImageType.Applications and not check_valid_beta_use(
        abi_versions=abi_versions_response, image_package=image_package, force_beta=force
    ):
        raise CLIError(f"Use {FORCE_PARAM_LONG_NAME} flag to force this operation.")

    # All good. Deploy the image.
    image_package_file_content = image_package.read_bytes()

    response = images_client.images_stage_image(image_package_file_content)

    body = (
        PathsWnx2AfUpdateInstallPostRequestbodyContentApplicationJsonSchema()
        if manual_start
        else None
    )
    response = images_client.images_install_staged_images(body)

    # Format output response
    return_response = {}
    return_response["imagePackageDeployed"] = image_package.as_posix()
    return_response["appStatus"] = "Stopped" if manual_start else "Running"
    return_response["restartingSystem"] = True if response.restarting_system else False
    if manual_start:
        error_msg = "The application was not automatically started. Use 'az sphere device app start' to start it."
        logger.warning(error_msg)

    return return_response


def delete_sideload_device(
    cmd: AzCliCommand,
    device_ip: str,
    component_id: str = None,
    except_component_ids: List[str] = None,
):
    """Delete sideload device (device sideload delete)."""
    # Change all except component ids to lowercase.
    return delete_images(
        cmd=cmd,
        device_ip=device_ip,
        component_id=component_id,
        except_component_ids=except_component_ids,
    )
