"""This module provides the device image commands structure."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from azext_azure_sphere._exception_handler import cloud_exception_handler, device_exception_handler
from azext_azure_sphere.device.validators import (
    cloud_commands_device_validator,
    device_commands_device_validator,
)
from azure.cli.core.commands import CliCommandType


def load_device_image_command_table(self, _):
    """List of the device image commands and their configurations."""

    device_image_custom_type = CliCommandType(
        operations_tmpl="azext_azure_sphere.device.image.custom#{}",
        exception_handler=cloud_exception_handler,
    )

    with self.command_group(
        "sphere device image", custom_command_type=device_image_custom_type
    ) as ctx:
        ctx.custom_command(
            "list-installed",
            "image_list_installed",
            exception_handler=device_exception_handler,
            validator=device_commands_device_validator,
        )
        ctx.custom_command(
            "list-targeted", "list_targeted_images", validator=cloud_commands_device_validator
        )
