"""This module provides Azure Sphere specific exceptions."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from knack.cli import CLIError


class AzureSphereError(CLIError):
    """Base exception for all errors raised by Azure Sphere."""

    pass  # pylint: disable=unnecessary-pass


# pylint: disable=too-many-ancestors
class OperationError(AzureSphereError):
    """Error when an operation's error field is not empty."""

    def __init__(self, message, code=None):
        """Create an exception from the error response."""
        AzureSphereError.__init__(self, message)
        self.code = code
        self.message = message
