"""Provides helper functions for commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------
import base64
import json
import locale
import os
import re
import subprocess
import sys
import time
import uuid
from datetime import datetime
from pathlib import Path
from sys import platform
from typing import List, Optional
from uuid import UUID

import requests
from azext_azure_sphere._client_factory_device import cf_image_gatewayd
from azext_azure_sphere.helpers.utils_images import get_component_ids_from_device_response
from azext_azure_sphere.sdk.azure_sphere_gatewayd.azure.sphere.gatewayd.models import (
    NetworkProxyAnonymous,
    NetworkProxyAuthenticationType,
    NetworkProxyBasic,
    Paths9HlxulStatusGetResponses200ContentApplicationJsonSchema,
)
from azure.cli.core.commands import AzCliCommand
from azure.core.exceptions import ServiceRequestError, ServiceResponseError
from azure.core.pipeline import PipelineResponse
from azure.core.pipeline.transport import HttpRequest, HttpResponse
from knack.log import get_logger
from knack.util import CLIError
from msrest import Deserializer
from msrest.exceptions import ClientRequestError
from msrestazure.tools import parse_resource_id
from packaging import version
from requests.exceptions import RequestException
from semantic_version import Version

logger = get_logger(__name__)

DEFAULT_VALUE = ".default"

AKA_MS_LINK_INSTALL_SDK_WINDOWS = "https://aka.ms/InstallAzureSphereSDKWindows"
AKA_MS_LINK_INSTALL_SDK_LINUX = "https://aka.ms/InstallAzureSphereSDKLinux"

AZSPHERE_SDK_ENV = "AzureSphereDefaultSDKDir"
MINIMUM_GATEWAYD_VERSION = "1.2.0"


def get_install_doc_link():
    """Get documentation link regarding platform."""
    if platform == "linux":
        return AKA_MS_LINK_INSTALL_SDK_LINUX
    if platform == "win32":
        return AKA_MS_LINK_INSTALL_SDK_WINDOWS


def encode_bytes(value):
    """Encode bytes."""
    if isinstance(value, (bytes, bytearray)):
        return base64.b64encode(value).decode("utf-8")
    return value


def get_config_value(cmd, section, key, default):
    """Get value from config."""
    logger.info("Try to get %s %s value from config file.", section, key)
    return cmd.cli_ctx.config.get(section, key, default)


def set_config_value(cmd, section, key, value):
    """Set value from config."""
    logger.info("Try to set %s %s value from config file.", section, key)
    return cmd.cli_ctx.config.set_value(section, key, value)


def is_uuid(uuid: str) -> bool:
    """Check if a string is a valid UUID of any version."""
    try:
        _ = UUID(uuid).version
        return True
    except (ValueError, TypeError):
        return False


def is_device_id(device_id: str) -> bool:
    """Check if a string is a valid device id."""
    pattern = re.compile(r"^[0-9a-fA-F]{128}$")
    if pattern.match(device_id) is None:
        return False
    return True


def open_certificate(filepath: str):
    """Open certificate file and return content."""
    with open(filepath, "rb") as file:
        return file.read().decode("utf-8")


def save_certificate(base64_certificate: str, output_file: Path) -> int:
    """Download certificate with destination file."""
    base64_certificate = encode_bytes(base64_certificate)
    with open(output_file, "wb") as file:
        return file.write(Deserializer.deserialize_base64(base64_certificate))


def requests_get(url: str):
    """Make a GET requests call using the specified URL."""
    try:
        result = requests.get(url)
    except ConnectionError as err:
        raise CLIError(
            "Please ensure you have network connection. Error detail: " + str(err)
        ) from err
    except RequestException as err:
        raise CLIError("Get request failed. Error detail: " + str(err)) from err

    return result


def device_cloud_os_comparison(device_os_versions, cloud_os_version, wifi_message):
    """Compare device and cloud os version."""
    return_response = {}
    if device_os_versions:
        return_response["deviceOsVersion"] = str(device_os_versions[0])
    else:
        return_response["deviceOsVersion"] = "Unknown"
    return_response["targetedOsVersion"] = str(cloud_os_version)

    # Check if the device has the expected version
    if len(device_os_versions) == 1 and str.lower(device_os_versions[0]) == str.lower(
        cloud_os_version
    ):
        # Device has the expected version
        logger.warning(
            f"Your device has the expected version of the Azure Sphere OS {cloud_os_version}."
        )
    else:
        # Device does not have the expected version.
        # If the device is running only out of date OSs, warn and continue.
        if cloud_os_version not in device_os_versions:
            # Get a version if possible
            if len(device_os_versions) == 1:
                logger.warning(
                    f"Your device is running Azure Sphere OS version {device_os_versions[0]}. "
                    + f"The targeted OS version is {cloud_os_version}."
                )

        elif cloud_os_version in device_os_versions:
            # If 2 or more known OSs are installed the device is partially updated.
            if len(device_os_versions) > 1:
                logger.warning(
                    f"Your device is being updated to Azure Sphere OS version {cloud_os_version}."
                )
            # Update return response as device os version cannot be determined
            return_response["deviceOsVersion"] = "Updating"

    logger.warning(wifi_message)
    logger.warning(
        "Go to https://aka.ms/AzureSphereUpgradeGuidance for further advice and support."
    )

    return return_response


def is_sdk_installed():
    """Validate if the Azure Sphere SDK is installed."""
    try:
        azsphere_dir = os.getenv(AZSPHERE_SDK_ENV)
        if platform == "linux":
            azsphere_filepath = azsphere_dir + "/Links/azsphere_v2"
            sdk_path = Path(os.path.join(azsphere_filepath))
            if not sdk_path.exists():
                return False

        if platform == "win32":
            azsphere_filepath = azsphere_dir + "Tools_v2\\wbin\\azsphere.cmd"
            sdk_path = Path(os.path.join(azsphere_filepath))
            if not sdk_path.exists():
                return False
    except:
        return False

    return True


def is_cloudshell():
    """Validate if the extension is run on Azure Cloud Shell."""
    powershell_distribution_channel = os.environ.get("POWERSHELL_DISTRIBUTION_CHANNEL")
    if powershell_distribution_channel and powershell_distribution_channel.lower() == "cloudshell":
        return True

    return False


def check_minimum_sdk_version_number():
    """Check is the Azure Sphere SDK minimum version is installed."""
    sdk_version = get_sdk_version()
    return version.parse(sdk_version) >= version.parse("23.05.0")


def get_gdb_server_path():
    """Get gdb server path from Windows or Linux system."""
    try:
        azsphere_dir = os.getenv(AZSPHERE_SDK_ENV)
        if platform == "linux":
            gdb_server_filepath = azsphere_dir + "/DebugTools/gdbserver.imagepackage"
            return Path(os.path.join(gdb_server_filepath))
        if platform == "win32":
            gdb_server_filepath = azsphere_dir + "DebugTools\\gdbserver.imagepackage"
            return Path(os.path.join(gdb_server_filepath))

        if not gdb_server_filepath.exists():
            raise CLIError("The file gdbserver.imagepackage does not exist.")
    except:
        aka_ms_link = get_install_doc_link()
        raise CLIError(
            f"Please review your installation of the Azure Sphere SDK. See {aka_ms_link} for more information."
        )


def get_azsphere_command():
    """Get azsphere command from Windows or Linux system."""
    try:
        azsphere_dir = os.getenv(AZSPHERE_SDK_ENV)
        if platform == "linux":
            azsphere_filepath = azsphere_dir + "/Links/azsphere_v2"
            return os.path.join(azsphere_filepath)
        if platform == "win32":
            azsphere_filepath = azsphere_dir + "Tools_v2\\wbin\\azsphere.cmd"
            return os.path.join(azsphere_filepath)
    except:
        aka_ms_link = get_install_doc_link()
        raise CLIError(
            f"Please review your installation of the Azure Sphere SDK. See {aka_ms_link} for more information."
        )


def azsphere_run(arguments, output, device_ip=None):
    """Call azsphere CLI."""
    arguments[0] = get_azsphere_command()
    if output:
        arguments.append("--output")
        arguments.append(output)

    # Appending argument '--extension-cli-call' to let CLIv2 know that the call is made from
    # extension CLI. This is done so that the correct commands are displayed in the error
    # messages returned by CLIv2.
    arguments.append("--extension-cli-call")

    if device_ip:
        arguments = update_device_ip_in_cliv2_args(arguments, device_ip)

    args = " ".join([f'"{arg}"' for arg in arguments])

    try:
        subprocess.run(
            args=args,
            shell=True,
            check=True,
        )
    except:
        pass


def azsphere_combo_run(arguments):
    """Call azsphere CLI (combo commands)."""
    # Appending argument '--extension-cli-call' to let CLIv2 know that the call is made from
    # extension CLI. This is done so that the correct commands are displayed in the error
    # messages returned by CLIv2.
    arguments[0] = get_azsphere_command()
    arguments.append("--extension-cli-call")
    args = " ".join([f'"{arg}"' for arg in arguments])

    try:
        subprocess.run(
            args=args,
            shell=True,
            check=True,
        )
    except:
        pass


def azsphere_combo_add_global_args(cliv2_arguments, combo_arguments):
    """Add global arguments (combo commands)."""
    if "--debug" in cliv2_arguments:
        combo_arguments.append("--debug")
    if "--verbose" in cliv2_arguments:
        combo_arguments.append("--verbose")
    if "--only-show-errors" in cliv2_arguments:
        combo_arguments.append("--only-show-errors")
    return combo_arguments


def get_query_param_value(args):
    """Return command parameters."""
    return args


def update_device_ip_in_cliv2_args(cliv2_arguments, device_ip):
    """Return command parameters."""
    # If --device/-d is not specified in the args, add the auto-detected device_ip value into the
    # CLI arguments.
    if "--device" not in cliv2_arguments and "-d" not in cliv2_arguments:
        cliv2_arguments.append("--device")
        cliv2_arguments.append(device_ip)
    else:
        # If --device/-d is specified in the args, replace with the auto-detected device_ip value into the
        # CLI arguments. This is because the -device/-d that is specified in the args could be the
        # device connection path or location.
        device_index = (
            cliv2_arguments.index("--device")
            if "--device" in cliv2_arguments
            else cliv2_arguments.index("-d")
        )
        cliv2_arguments = (
            cliv2_arguments[: device_index + 1] + [device_ip] + cliv2_arguments[device_index + 2 :]
        )

    return cliv2_arguments


def azsphere_run_return_output(arguments, output):
    """Call azsphere CLI."""
    try:
        arguments[0] = get_azsphere_command()
        if output:
            arguments.append("--output")
            arguments.append(output)
        # Appending argument '--extension-cli-call' to let CLIv2 know that the call is made from
        # extension CLI. This is done so that the correct commands are displayed in the error
        # messages returned by CLIv2.
        arguments.append("--extension-cli-call")
        args = " ".join([f'"{arg}"' for arg in arguments])
        result = subprocess.run(
            args=args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True, check=True
        )

        if result.stdout and result.stdout != "":
            return json.loads(result.stdout)
        if result.stderr and result.stderr != "":
            warn_message = result.stderr.decode("utf-8").replace("WARNING: ", "")
            return warn_message
    except subprocess.CalledProcessError as ex:
        if ex.stderr:
            err_message = ex.stderr.decode("utf-8").replace("ERROR: ", "")
            raise CLIError(err_message) from ex
        else:
            raise CLIError(
                "An unexpected error occurred while calling the command. " + ex.output
            ) from ex


def download_images_list(cmd):
    """Download the mt3620an.json file for the correct environment."""
    environment = get_config_value(cmd, "defaults", "sphere.environment", "prod")
    downloaded_images_list = requests_get(
        f"https://{environment}.releases.sphere.azure.net/versions/mt3620an.json"
    ).json()

    return downloaded_images_list


def get_value_from_arm_id(rid: str, key: str):
    """Return value related to key in ARN resource id."""
    values = parse_resource_id(rid)
    values_iter = iter(values)
    for item in values_iter:
        if item == key:
            return values[item]
        if values[item] == key:
            return values[next(values_iter)]

    raise CLIError(f"Cannot get value for '{key}'")


def format_datetime(value) -> str:
    """Change the format of a datetime depending of the local time zone."""
    locale.setlocale(locale.LC_ALL, "")  # use user's preferred locale
    return datetime.strptime(value, "%Y-%m-%dT%H:%M:%S").strftime("%x %X")


def check_device_restart_status(
    get_device_status_callback, timeout: float, success_message: str, retry: int = 3
):
    """Check the device restart status."""
    attempt = 0
    while True:
        try:
            get_device_status_callback()
        except (ClientRequestError, ServiceRequestError, ServiceResponseError) as ex:
            if attempt < retry:
                time.sleep(timeout)
                attempt += 1
            else:
                raise ex
        else:
            logger.warning(success_message)
            return


def get_sdk_version() -> Optional[str]:
    """Return the SDK version in the VERSION file in the sdk folder."""
    if AZSPHERE_SDK_ENV in os.environ:
        azsphere_dir = os.getenv(AZSPHERE_SDK_ENV)
        version_file = Path(azsphere_dir, "VERSION")
        if version_file.is_file():
            version = open(version_file, "r").read()
            version = version.strip() if version else None
            return version
    elif sys.prefix != sys.base_prefix:  # Run in virtual environment -> Development
        return "Development"

    return "Unknown"


def throw_if_api_not_yet_supported(gatewayd_version: str):
    # Use the semantic_version package from pypi
    support_threshold = Version(MINIMUM_GATEWAYD_VERSION)
    api_version = Version(gatewayd_version)

    # Check if support threshold is newer than gatewayd version
    if support_threshold > api_version:
        raise CLIError(
            f"This request is only supported from GatewayD API version {support_threshold}; current version is {api_version}."
        )


def get_gatewayd_version(
    response: PipelineResponse[HttpRequest, HttpResponse],
    deserialized: Paths9HlxulStatusGetResponses200ContentApplicationJsonSchema,
    dict: {},
):
    """Return the gatewayD version."""
    headers = response.http_response.headers
    gatewayd_version = headers["REST-API-Version"]
    return gatewayd_version


def show_os_version(cmd: AzCliCommand, device_ip: str, downloaded_images_list=None):
    """Show OS version on attached device (device show-os-version)."""
    images_client = cf_image_gatewayd(cmd.cli_ctx, device_ip=device_ip)

    # Getting os version prior to 4.5.0
    # Download the json file if not already downloaded
    if not downloaded_images_list:
        downloaded_images_list = download_images_list(cmd=cmd)

    # Get images from the device
    get_images_response = images_client.images_get_images()

    # Extract the component ids and uids from the get_images response
    device_images_component_id_uid_list = get_component_ids_from_device_response(
        get_images_response
    )

    # Compare the component ids and uids from the device with the downloaded json file and get the
    # os version(s) of the device
    device_os_versions = compare_and_get_os_versions(
        device_images_component_id_uid_list, downloaded_images_list
    )

    return device_os_versions


def compare_and_get_os_versions(component_id_uid_list, downloaded_images_list) -> List[str]:
    """Check for a full match."""
    # Find all known versions where every component/image pair has a match in the list of images on the device.
    fully_matched_list = []
    for version in downloaded_images_list["versions"]:
        if all(x in component_id_uid_list for x in version["images"]):
            fully_matched_list.append(version["name"])

    # If we have any full matches, return only the last one (most recent)
    if len(fully_matched_list) > 0:
        return [fully_matched_list[-1]]

    # Don't have a full match. Look for partial matches.

    # Using a set to dedup the resulting version list
    versions_set = set()
    for cid_uid_pair in component_id_uid_list:
        for version in downloaded_images_list["versions"]:
            if cid_uid_pair in version["images"]:
                versions_set.add(version["name"])

    # If just one version matches, then it is still only a partial match
    # or else we would have returned the full match above, however we can't determine a name for the non-matching images
    if len(versions_set) == 1:
        versions_set.add("Unknown")

    return list(versions_set)


def set_network_proxy_body(
    authentication: str,
    enable: bool,
    address: str,
    port: str,
    no_proxy_addresses: str,
    username: str = None,
    password: str = None,
):
    """Configure the network proxy."""
    if authentication == NetworkProxyAuthenticationType.BASIC:
        body = NetworkProxyBasic(
            enabled=enable,
            address=address,
            port=port,
            no_proxy_addresses=no_proxy_addresses,
            authentication_type=NetworkProxyAuthenticationType.BASIC,
            username=username,
            password=password,
        )
    elif authentication == NetworkProxyAuthenticationType.ANONYMOUS:
        body = NetworkProxyAnonymous(
            enabled=enable,
            address=address,
            port=port,
            no_proxy_addresses=no_proxy_addresses,
            authentication_type=NetworkProxyAuthenticationType.ANONYMOUS,
        )
    else:
        assert False, "Unrecognized authentication type."
    return body
