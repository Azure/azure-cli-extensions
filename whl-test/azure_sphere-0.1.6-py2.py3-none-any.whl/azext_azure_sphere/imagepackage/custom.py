"""This module provides the implementation of custom image-package commands."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.

from typing import List

from azext_azure_sphere.helpers.utils import azsphere_run
from knack.log import get_logger

logger = get_logger(__name__)


def image_package_show(
    cliv2_output: str,
    cliv2_arguments: List[str],
    image_package: str,
):
    """Show image package details."""
    azsphere_run(cliv2_arguments, cliv2_output)
