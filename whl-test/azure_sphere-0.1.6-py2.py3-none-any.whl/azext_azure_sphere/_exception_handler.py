"""Provides the main exception handler for AS3 ARM/ARP endpoints."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in the project root for license information.
# --------------------------------------------------------------------------------------------

from sys import platform
from typing import Optional

from azext_azure_sphere.helpers._gatewayd_error_parser import get_error_message
from azext_azure_sphere.helpers._gatewayd_version_checker import version_checked_error
from azext_azure_sphere.sdk.azure_sphere_gatewayd.azure.sphere.gatewayd.models import Error
from azure.core.exceptions import (
    ClientAuthenticationError,
    DecodeError,
    HttpResponseError,
    ServiceRequestError,
    ServiceResponseError,
)
from azuresphere_device_api.exceptions import AzureSphereDeviceApiException, DeviceError
from knack.cli import CLIError
from msrest.exceptions import (
    AuthenticationError,
    ClientRequestError,
    DeserializationError,
    SerializationError,
    TokenExpiredError,
    ValidationError,
)

SUGGEST_AKAMS_LINK_MESSAGE = (
    "\nIf the issue persists, please refer to https://aka.ms/AzureSphereSDKHelp/Cloud "
    "for troubleshooting suggestions and support."
)

AS3_REASON_MESSAGE = "\nThe Azure Sphere Security Service sent the following message: {}"

UNAUTHORIZED_MESSAGE = "does not have authorization to perform action"


def get_as3_reason(message: Optional[str], reason: Optional[str]) -> str:
    """Return the error message and attribute it to AS3.

    :param reason: An error string sent by AS3.
    :type reason: Optional[str]
    :return: The error message.
    :rtype: str
    """
    if reason:
        if message:
            msg = message.split("Message: ")
            if len(msg) == 2:
                return msg[1]
        return AS3_REASON_MESSAGE.format(reason)
    else:
        return ""


def cloud_exception_handler(ex: Exception):
    """Handle generic cloud exceptions.

    Should be used as the default exception handler for cloud commands.
    Any custom cloud exception handlers, should call this after.

    :param ex: The exception to be handled.
    :type ex: Exception
    :raises CLIError: ARM/ARP API cannot be reached.
    :raises CLIError: ARM/ARP API does not respond.
    :raises CLIError: Error decoding the response from ARM/ARP API.
    :raises CLIError: Bad Request Error (400).
    :raises CLIError: Authentication Error (401, 403).
    :raises CLIError: Resource Not Found Error (404, 412).
    :raises CLIError: Resource Exists Error (409).
    :raises CLIError: Resource Gone Error (410).
    :raises CLIError: Unknown HTTP Error (-).
    :raises ex: Any other exception.
    """
    if isinstance(ex, (ClientRequestError, ServiceRequestError)):
        message = (
            "Could not access the Azure Sphere Security Service. Check your network connection."
        )
        raise CLIError(message) from ex

    if isinstance(ex, ServiceResponseError):
        message = "The Azure Sphere Security Service is not responding, please try again later."
        raise CLIError(message) from ex

    if isinstance(ex, (DecodeError, DeserializationError)):
        message = (
            "This Azure Sphere Extension is not compatible with the current "
            "Azure Sphere Security Service. Please update the Extension and try again."
        )
        raise CLIError(message) from ex

    if isinstance(ex, HttpResponseError):
        raise CLIError(ex.message) from ex

    raise ex


def device_exception_handler(ex: Exception, not_combo_command: bool = True):
    """Handle generic device exceptions.

    Should be used as the default exception handler for device commands.
    Any custom device exception handlers, should call this after.

    :param ex: The exception to be handled.
    :type ex: Exception
    :raises CLIError: Device has stopped responding.
    :raises CLIError: Errors raised by AzureSphereDeviceApiException.
    :raises ex: An unexpected error was caught.
    """
    if isinstance(ex, (DeviceError, ClientRequestError, ServiceRequestError, ServiceResponseError)):
        raise CLIError(
            "The device has stopped responding. The device may be unresponsive, if "
            "it is applying an Azure Sphere operating system update. "
            "Please try again in a few minutes. If the issue persists, please refer to "
            "https://aka.ms/AzureSphereSDKHelp/Device for troubleshooting "
            "suggestions and support."
        ) from ex

    if isinstance(ex, (AzureSphereDeviceApiException)):
        raise CLIError(ex)

    if isinstance(ex, (ClientAuthenticationError, TokenExpiredError, AuthenticationError)):
        message = "You do not have permission to perform this operation on this device. " + str(ex)
        raise CLIError(message) from ex

    if isinstance(ex, DecodeError):
        message = "The device returned a response which could not be parsed."
        invalid_response_error = CLIError(message)
        raise version_checked_error(invalid_response_error, ex.response, check_minor=False) from ex

    if isinstance(ex, DeserializationError):
        message = "The device returned a response which could not be parsed."
        raise CLIError(message)

    if isinstance(ex, SerializationError):
        message = "An error occurred while constructing this request."
        raise CLIError(message) from ex

    if isinstance(ex, HttpResponseError):

        if ex.model:
            if isinstance(ex.model, Error):
                inner_error = CLIError(get_error_message(ex.model))
            else:
                inner_error = CLIError(
                    f"The device returned a value with an invalid type: {type(ex.model)}"
                )
            raise version_checked_error(inner_error, ex.response, check_minor=False) from ex

        if ex.status_code == 400:
            message = "An invalid request was made to the device. " + str(ex)
            bad_request_error = CLIError(message)
            raise version_checked_error(bad_request_error, ex.response, check_minor=False) from ex

        if ex.status_code == 403:
            message = "You do not have permission to perform this operation on this device. Run 'az sphere device enable-development' or use 'az sphere device capability' to download and select a capability file for this device. For further information, please refer to https://aka.ms/AzureSphereSDKHelp/Device."
            raise CLIError(message) from ex

        if ex.status_code in [404, 412]:
            message = "This resource is unavailable on this device. " + str(ex)
            invalid_request_error = CLIError(message)
            raise version_checked_error(
                invalid_request_error, ex.response, check_minor=False
            ) from ex

        if ex.status_code == 409:
            message = (
                "The device could not perform this request due to the resource being in "
                "a conflicting state. " + str(ex)
            )
            raise CLIError(message) from ex

        if ex.status_code == 415:
            message = "The media type provided for this operation is unsupported. " + str(ex)
            raise CLIError(message) from ex

        if ex.status_code == 500:
            message = "An internal device error occurred. " + str(ex)
            raise CLIError(message) from ex

        message = (
            f"This command failed due to an unexpected HTTP error, with status code "
            f"'{ex.status_code}', from the device. " + str(ex)
        )

        if not_combo_command:
            raise CLIError(message) from ex

    if isinstance(ex, ValidationError):
        message = "Invalid argument(s) specified. Try again with a different value."
        raise CLIError(message) from ex

    # Raise error only for non-combo commands. For combo commands, return as cloud error will need
    # to be checked.
    if not_combo_command:
        raise ex


def combo_commands_exception_handler(ex: Exception):
    """Handle generic exceptions for combo commands.

    Should be used as the default exception handler for combo commands.

    :param ex: The exception to be handled.
    :type ex: Exception
    """
    # Call the device exception handler.
    device_exception_handler(ex, False)

    # Call the cloud exception handler.
    cloud_exception_handler(ex)
