"""This module provides validators for auto detection arguments."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

from argparse import Namespace

from azext_azure_sphere.auto_detection.params import DEVICE_PARAM_LONG_NAME
from azext_azure_sphere.auto_detection.utils import (
    get_device_id,
    is_device_id,
    is_device_ip,
    is_device_location,
)
from azext_azure_sphere.device_comm.utils import (
    get_device_satisfying_condition,
    get_single_attached_device,
)
from azure.cli.core.commands import AzCliCommand
from knack.util import CLIError


def device_ip_validator(cmd: AzCliCommand, namespace: Namespace):
    """Validate the --device parameter.

    Return the IP address of the selected device. This validator is
    invoked by specifying the 'device_ip' parameter in a command.
    The device_ip should be used when calls need to be made to the
    device as it is required to instantiate a GatewayD Client.

    :param cmd: The current command instance, which allows access to the
        CLI context and numerous helper methods.
    :type cmd: AzCliCommand
    :param namespace: An object for storing attributes which are passed
        as parameters to the individual commands e.g. 'device_ip'.
    :type namespace: Namespace
    """
    device_param = namespace.device_ip
    if not device_param:
        namespace.device_ip = get_single_attached_device().ip_address
    elif is_device_location(device_param):
        namespace.device_ip = get_device_satisfying_condition(
            condition=lambda device: device.device_connection_path == device_param,
            specifying_method="location",
        ).ip_address
    elif is_device_ip(device_param):
        namespace.device_ip = get_device_satisfying_condition(
            condition=lambda device: device.ip_address == device_param,
            specifying_method="IP",
        ).ip_address
    elif is_device_id(device_param):
        namespace.device_ip = get_device_satisfying_condition(
            condition=lambda device: get_device_id(device.ip_address) == device_param.lower(),
            specifying_method="ID",
        ).ip_address
    else:
        raise CLIError(
            f"The {DEVICE_PARAM_LONG_NAME} '{namespace.device_ip}' parameter is invalid. "
        )


def device_id_validator(namespace: Namespace):
    """Validate the --device parameter.

    Return the device ID of the selected device. This validator is
    invoked by specifying the 'device_id' parameter in a command.
    The device_id should be used when calls do not need to be made to
    the physical device, but a device ID is required for an AS3 call

    :param cmd: The current command instance, which allows access to the
        CLI context and numerous helper methods.
    :type cmd: AzCliCommand
    :param namespace: An object for storing attributes which are passed
        as parameters to the individual commands e.g. 'device_id'.
    :type namespace: Namespace
    """

    device_param = namespace.device_id

    if not device_param:
        namespace.device_id = get_device_id(get_single_attached_device().ip_address)

    elif is_device_location(device_param):
        device_ip = get_device_satisfying_condition(
            condition=lambda device: device.device_connection_path == device_param,
            specifying_method="location",
        ).ip_address
        namespace.device_id = get_device_id(device_ip)

    elif is_device_ip(device_param):
        device_ip = get_device_satisfying_condition(
            condition=lambda device: device.ip_address == device_param,
            specifying_method="IP",
        ).ip_address
        namespace.device_id = get_device_id(device_ip)

    elif is_device_id(device_param):
        namespace.device_id = device_param
    else:
        raise CLIError(
            f"The {DEVICE_PARAM_LONG_NAME} '{namespace.device_id}' parameter is invalid. Verify that it is 128 characters long and contains only hexadecimal characters."
        )


def device_name_validator(namespace: Namespace):
    """Validate the --device parameter.

    Return the device ID of the selected device. This validator is
    invoked by specifying the 'device_name' parameter in a command.
    The device_id should be used when calls do not need to be made to
    the physical device, but a device ID is required for an AS3 call

    :param cmd: The current command instance, which allows access to the
        CLI context and numerous helper methods.
    :type cmd: AzCliCommand
    :param namespace: An object for storing attributes which are passed
        as parameters to the individual commands e.g. 'device_name'.
    :type namespace: Namespace
    """

    device_param = namespace.device_name

    if not device_param:
        namespace.device_name = get_device_id(get_single_attached_device().ip_address)

    elif is_device_location(device_param):
        device_ip = get_device_satisfying_condition(
            condition=lambda device: device.device_connection_path == device_param,
            specifying_method="location",
        ).ip_address
        namespace.device_name = get_device_id(device_ip)

    elif is_device_ip(device_param):
        device_ip = get_device_satisfying_condition(
            condition=lambda device: device.ip_address == device_param,
            specifying_method="IP",
        ).ip_address
        namespace.device_name = get_device_id(device_ip)

    elif is_device_id(device_param):
        namespace.device_name = device_param
    else:
        raise CLIError(
            f"The {DEVICE_PARAM_LONG_NAME} '{namespace.device_name}' parameter is invalid. Verify that it is 128 characters long and contains only hexadecimal characters."
        )
