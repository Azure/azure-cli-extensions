Microsoft Azure CLI 'azure-sphere' Extension
==========================================

This package is for the 'azure-sphere' extension.
i.e. 'az sphere'
