Microsoft Azure CLI 'fidalgo' Extension
==========================================

This package is for the 'fidalgo' extension.
i.e. 'az fidalgo'