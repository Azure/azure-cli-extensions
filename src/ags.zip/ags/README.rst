Microsoft Azure CLI 'ags' Extension
==========================================

This package is for the 'ags' extension.
i.e. 'az ags'