# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

# pylint: disable=line-too-long
from azure.cli.core.commands import CliCommandType
from azext_ags._client_factory import cf_ags


def load_command_table(self, _):

    # TODO: Add command type here
    # ags_sdk = CliCommandType(
    #    operations_tmpl='<PATH>.operations#None.{}',
    #    client_factory=cf_ags)


    with self.command_group('ags') as g:
        g.custom_command('create', 'create_ags')
        g.custom_command('delete', 'delete_ags')
        g.custom_command('list', 'list_ags')
        g.custom_command('show', 'show_ags')
        # g.generic_update_command('update', setter_name='update', custom_func_name='update_ags')

    with self.command_group('ags dashboard') as g:
        # g.custom_command('create', "create_dashboard")
        # g.custom_command('delete', "delete_dashboard")
        # g.custom_command('list', "list_dashboard")
        g.custom_command('show', "show_dashboard")

    with self.command_group('ags', is_preview=True):
        pass

