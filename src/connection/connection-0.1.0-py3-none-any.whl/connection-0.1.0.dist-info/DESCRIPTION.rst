# Azure CLI connection Extension #


