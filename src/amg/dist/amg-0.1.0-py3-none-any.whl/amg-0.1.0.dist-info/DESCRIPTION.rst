# Microsoft Azure CLI 'amg' Extension


