Azure CLI AKS Preview Extension


