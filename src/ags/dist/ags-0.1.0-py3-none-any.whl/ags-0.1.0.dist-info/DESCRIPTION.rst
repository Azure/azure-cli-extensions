Microsoft Azure CLI 'ags' Extension


