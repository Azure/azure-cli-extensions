Microsoft Azure CLI 'k8s-extension' Extension
=============================================

This package is for the 'k8s-extension' extension.
i.e. 'az k8s-extension'

### How to use ###
Install this extension using the below CLI command
```
az extension add --name k8s-extension
```

### Included Features
#### Kubernetes Extensions:
Kubernetes Extensions: [more info](https://docs.microsoft.com/en-us/azure/kubernetessconfiguration/)\
*Examples:*

##### Create a KubernetesExtension
```
az k8s-extension create \
    --resource-group groupName \
    --cluster-name clusterName \
    --cluster-type clusterType \
    --name extensionName \
    --extension-type extensionType \
    --scope scopeType \
    --release-train releaseTrain \
    --version versionNumber \
    --auto-upgrade-minor-version autoUpgrade \
    --configuration-settings exampleSetting=exampleValue \
```

##### Get a KubernetesExtension
```
az k8s-extension show \
    --resource-group groupName \
    --cluster-name clusterName \
    --cluster-type clusterType \
    --name extensionName
```

##### Delete a KubernetesExtension
```
az k8s-extension delete \
    --resource-group groupName \
    --cluster-name clusterName \
    --cluster-type clusterType \
    --name extensionName
```

##### List all KubernetesExtension of a cluster
```
az k8s-extension list \
    --resource-group groupName \
    --cluster-name clusterName \
    --cluster-type clusterType
```

If you have issues, please give feedback by opening an issue at https://github.com/Azure/azure-cli-extensions/issues.

.. :changelog:

Release History
===============

0.3.0
++++++++++++++++++

* Release customization for microsoft.azureml.kubernetes

0.2.1
++++++++++++++++++

* Remove `k8s-extension update` until PATCH is supported
* Improved logging for overwriting extension name with default 

0.2.0
++++++++++++++++++

* Refactor for clear separation of extension-type specific customizations
* OpenServiceMesh customization.
* Fix clusterType of Microsoft.ResourceConnector resource
* Update clusterType validation to allow 'appliances'
* Update identity creation to use the appropriate parent resource's type and api-version
* Throw error if cluster type is not one of the 3 supported types
* Rename azuremonitor-containers extension type to microsoft.azuremonitor.containers
* Move CLI errors to non-deprecated error types
* Remove support for update

0.1.3
++++++++++++++++++

* Customization for microsoft.openservicemesh

0.1.2
++++++++++++++++++

* Add support for Arc Appliance cluster type

0.1.1
++++++++++++++++++
* Add support for microsoft-azure-defender extension type

0.1.0
++++++++++++++++++
* Initial release.


