# Azure CLI Connected Kubernetes Extension #
This package is for the 'connectedk8s' extension, i.e. 'az connectedk8s'.

### How to use ###
Install this extension using the below CLI command
```
az extension add --name connectedk8s
```

### Included Features
#### Connected Kubernetes Management:
*Examples:*

##### Create a connected kubernetes cluster
```
az connectedk8s connect \
    --subscription subscription_id \
    --resource-group my-rg \
    --name my-cluster \
    --location eastus
```

##### Show connected kubernetes cluster
```
az connectedk8s show \
    --subscription subscription_id \
    --resource-group my-rg \
    --name my-cluster \
```
or
```
az connectedk8s show \
    --ids "/subscriptions/subscription_id/resourceGroups/my-rg/providers/Microsoft.Kubernetes/connectedClusters/my-cluster" \
```

##### List connected kubernetes cluster in resource group
```
az connectedk8s list \
    --resource-group my-rg
```

##### Delete connected kubernetes cluster
```
az connectedk8s delete \
    --subscription subscription_id \
    --resource-group my-rg \
    --name my-cluster \
```
or
```
az connectedk8s delete \
    --ids "/subscriptions/subscription_id/resourceGroups/my-rg/providers/Microsoft.Kubernetes/connectedClusters/my-cluster" \
    -y
```

.. :changelog:

Release History
===============

1.0.0
++++++
* Moving to GA API version

0.2.9
++++++
* `az connectedk8s connect`: Added support for disabling auto upgrade of agents
* `az connectedk8s update`: Added support for switching on/off the auto-upgrade
* `az connectedk8s upgrade`: Added support for manual upgrading of agents

0.2.8
++++++
* Added checks for proxy and added disable-proxy
* Updated config dataplane endpoint to support other clouds
* `az connectedk8s connect`: Added support for kubernetes distro/infra parameters and heuristics

0.2.7
++++++
* Fixed dependency version in setup file

0.2.6
++++++
* `az connectedk8s connect`: Added support for proxy cert
* `az connectedk8s update`: Added support for proxy cert

0.2.5
++++++
* `az connectedk8s connect`: Added support for Dogfood cloud
* `az connectedk8s update`: Added support for Dogfood cloud

0.2.4
++++++
* `az connectedk8s connect`: Bug fixes and updated telemetry
* `az connectedk8s delete`: Bug fixes and updated telemetry
* `az connectedk8s update`: Bug fixes and updated telemetry

0.2.3
++++++
* `az connectedk8s connect`: Modified CLI params for proxy
* `az connectedk8s update`: Added update command

0.2.2
++++++
* `az connectedk8s connect`: Added CLI params to support proxy.

0.2.1
++++++
* `az connectedk8s connect`: Added kubernetes distribution.

0.2.0
++++++
* `az connectedk8s connect`: Added telemetry.
* `az connectedk8s delete`: Added telemetry.

0.1.5
++++++
* Initial release.


